#!/usr/bin/python

################################################################################
# Author     : Olivier Tissot                                                  #
# Date       : 2016/08/19                                                      #
# Description: Plot graphs using parbcg output file                            #
################################################################################

################################################################################
#                                 IMPORT                                       #
################################################################################

import numpy as np
import matplotlib.pyplot as plt
from cpalamem_utils import cpalamem_output_parser as cop

################################################################################
#                                   CODE                                       #
################################################################################

prefix = '/Users/otissot/Documents/Numerical Results/ParBCG/MeSU/parbcg_exec_'
job_ids = ['767975.mesu0_','767938.mesu0_','767931.mesu0_','767932.mesu0_']
suffixes = ['4.log','8.log','12.log','16.log','20.log','24.log']

# /!\ Don't forget the ':' at the end of the function /!\
functions = {"main:":-1}

################################################################################

# Create a list of outputs
# outputs = []
# for suffix in suffixes:
#     outputs.append(cop.cpalamem_output(prefix+job_ids[3]+suffix,functions))

# tot_t =[]
# tot_t.append(outputs[0].steps['KSPSolve'])
# for i in range(0,len(outputs)):
#     tot_t[0] = min(tot_t[0],outputs[i].steps['KSPSolve'])
#     tot_t.append(outputs[i].steps['BCGSolve'])

# x = range(len(tot_t))
# xticks = ['PETSc','ECG(4)','ECG(8)','ECG(12)','ECG(16)','ECG(20)','ECG(24)']
# plt.figure()
# width = 0.8
# plt.title('Ela400, nproc = 48')
# ax = plt.axes()
# ax.yaxis.grid(zorder=0)
# barlist = plt.bar(x, tot_t, width, linewidth=0, alpha=1.0, color='steelblue', zorder=3, align='center')
# barlist[0].set_color('darkblue')
# plt.xticks(x, xticks)
# plt.ylabel('Time (s)')
# plt.ylim(0,max(tot_t)+0.05*max(tot_t))
# plt.show()

################################################################################

# Create a list of outputs
outputs2 = []
for id in job_ids:
    outputs2.append(cop.cpalamem_output(prefix+id+suffixes[2],functions))

t_petsc = []
t_bcg   = []

for i in range(0,len(outputs2)):
    t_petsc.append(outputs2[i].steps['KSPSolve'])
    t_bcg.append(outputs2[i].steps['BCGSolve'])

x = np.arange(len(t_petsc))
xticks = ['24','48','96','192']
width = 0.4
plt.figure()
plt.title('Ela400')
ax = plt.axes()
ax.yaxis.grid(zorder=0)
rect1 = ax.bar(x+width*0.5, t_bcg, width, linewidth=0, alpha=1.0, color='steelblue', zorder=3, align='center', label='ECG(12)')
rect2 = ax.bar(x-width*0.5, t_petsc, width, linewidth=0, alpha=1.0, color='darkblue', zorder=3, align='center', label='PETSc')
plt.xticks(x, xticks)
plt.xlabel('nproc')
plt.ylabel('Time (s)')
plt.ylim(0,max(t_petsc)+0.05*max(t_petsc))
plt.legend()
plt.show()
