#!/usr/bin/python

################################################################################
#                                 IMPORT                                       #
################################################################################

import numpy as np
import sys
import cpalamem_output_parser as cop

################################################################################
#                                   CODE                                       #
################################################################################
USAGE='Usage {0} [ -f <fileName>...] [ -fun <funName>...] [ -step <stepName>...]'
functions = []
steps = []
files = []
blocks= [0] #By default working on block 0

argc = len(sys.argv)
if argc > 1:
    if '-h' in sys.argv:
        print(USAGE.format(sys.argv[0]))
        sys.exit(0)

    i = 1
    while i < argc:
        if sys.argv[i] == '-fun':
            for f in range(i+1,argc):
                if sys.argv[f][0] != '-':
                    functions.append(sys.argv[f])
                else:
                    f = f - 1
                    break
            i = f + 1
        elif sys.argv[i] == '-step':
            for f in range(i+1,argc):
                if sys.argv[f][0] != '-':
                    steps.append(sys.argv[f])
                else:
                    f = f - 1
                    break
            i = f + 1
        elif sys.argv[i] == '-f':
            for f in range(i+1,argc):
                if sys.argv[f][0] != '-':
                    files.append(sys.argv[f])
                else:
                    f = f - 1
                    break
            i = f + 1
        else:
            print 'ERROR, param {}'.format(sys.argv[i])
            print(USAGE.format(sys.argv[0]))
            sys.exit(1)
    print('Operate search of files {0}'.format(files))
    print('=>Functions requested {0}'.format(functions))
    print('=>Steps requested {0}'.format(steps))

timings = {}
if len(files) > 0:
    for f in files:
      timings[f] = cop.cpalamem_output(f)
else:
  timings['stdin'] = cop.cpalamem_output()

for time in timings.values():
    for fun in functions:
      print('%%%%%%%%%%%%%%%%%%%%\n')
      print('{0}\n\{1}\n'.format(time.param, fun))
      found = time.findMaxTime(fun)
      print('The maximum time is {0:.2f} for proc {1}'.\
          format(found[1][0], found[0]))
      #print('Resume time:\n{0}'.format(time.getTime(fun)))
    for step in steps:
        print('~~~~~~~~~~~~~~~~~~~~\n')
        print('\{0}\n{1}'.format(time.param, step))
        found = time.findMaxTime(step)
        print('The maximum time is {0:.2f} for proc {1}'.\
            format(found[1][0], found[0]))
        print('\n')
        #print('Resume time:\n{0}'.format(time.getTime(step)))

