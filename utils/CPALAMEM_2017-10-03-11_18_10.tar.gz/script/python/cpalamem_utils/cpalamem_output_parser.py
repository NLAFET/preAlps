#!/usr/bin/python

################################################################################
# Load and parse cpalamem output                                  
#
# Authors : Sebastien Cayrols
#         : Olivier Tissot
# Email   : sebastien.cayrols@[(gmail.com) | (inria.fr)]
#         : olivier.tissot@inria.fr
# Date    : 2017/01/24                                                      
################################################################################

################################################################################
#                                 IMPORT                                       #
################################################################################

import re
import numpy as np
import sys

################################################################################
#                                   CODE                                       #
################################################################################

class cpalamem_output:
    pWord=r'\w\+-_\*\^=\(\)\{\}\[\]'
    pStep=r'\t{3}(?P<stepName>['+pWord+r' ]+\w+) *:\s(?P<stepTime>[\d\.]+) s'
    pFun=r'\[Proc: (?P<numProc>\d+)\] \t(?P<funName>[\w_]+): (?P<funTime>[\d\.]+) s'
    pNcall=r'\(ncall (?P<nCall>\d+)\)'
    pRange=r'\t\[(?P<minTime>[\d\.]+),(?P<maxTime>[\d\.]+)\]'
    pCPALAMEMInit=r'CPALAMEM Initialize:\t-np (?P<maxProc>\d+)'
    pParam=r'^Params: \t(?P<params>[\./\w -]+)$'

    # Constructor from file and dictionnary
    def __init__(self, filename=None, maxProc=128):
        self.filename   = filename
        self.funs       = {}
        self.param      = ""
        self.maxProc    = maxProc
        banner          = 0
        param           = 0

        if filename != None:
            ifile = open(filename,"r")
        else:
            ifile = sys.stdin

        # Read line by Line to find the maxProc
        for line in ifile:

            if banner == 0:
              #Search banner
              match = re.search(self.pCPALAMEMInit, line)
              if match:
                self.maxProc = int(match.group('maxProc'))
                banner = 1
                continue

            if param == 0:
               match = re.search(self.pParam, line)
               if match:
                  self.param = match.group('params')
                  param = 1
                  continue

            match = re.search(self.pFun, line)
            if match:
                rank    = int(match.group('numProc'))
                time    = float(match.group('funTime'))
                fun     = match.group('funName')

                if fun in self.funs.keys():
                    info = self.funs[fun]
                    data = info['data']
                else:
                    data =  {'val' : np.array(\
                                    [ None for i in range(self.maxProc) ]),\
                            'nval' : 0}
                    info  = {'steps' : {}, 'data' : data}
                    self.funs[fun] = info

                matchNcall = re.search(self.pNcall, line)
                ncallF   = int(matchNcall.group('nCall'))

                tmp     = (time, ncallF)

                matchRange = re.search(self.pRange, line)
                if matchRange:
                    tmp = tmp +\
                            (float(matchRange.group('minTime')),\
                            float(matchRange.group('maxTime')))

                data['val'][rank] = tmp
                data['nval'] = data['nval'] + 1

                continue

            match = re.search(self.pStep, line)
            if match:
                steps = info['steps']
                matchNcall = re.search(self.pNcall, line)
                if matchNcall:
                    ncall = int(matchNcall.group('nCall'))
                else:
                    ncall = ncallF

                tmp = (float(match.group('stepTime')), ncall)

                matchRange = re.search(self.pRange, line)
                if matchRange:
                    tmp = tmp + (float(matchRange.group('minTime')),\
                            float(matchRange.group('maxTime')))

                if match.group('stepName') in steps.keys():
                    data = steps[match.group('stepName')]
                else:
                    data = {'val' : np.array(\
                            [ None for i in range(self.maxProc) ]),\
                            'nval' : 0}
                    steps[match.group('stepName')] = data

                data['val'][rank] = tmp
                data['nval'] = data['nval'] + 1

                continue
           #print('"{0}"'.format(line))


    # In order to print
    def __str__(self):
        stro  = self.param + ' with -np ' + str(self.maxProc) +'\n'
        for i in range(self.maxProc):
            stro += self.strInfoProc(i)
        return stro





    def maxFunTime(self, fun):
        """
        This function computes the maximum over all processors of the function
        given in parameter
        """

        if fun in self.funs:
            val = self.funs[fun]['data']['val']
            return val.max(axis=0)[0]





    def __getData(self, name):
        """
        This function returns the data of the function/step given in param
        """
        if name in self.funs:
            data = self.funs[name]['data']
        else:
            for fun in self.funs.values():
                if name in fun['steps']:
                    data = fun['steps'][name]
                    break
        return data





    def getTime(self, name):
        """
        This function returns a string containing informations of the
        function/step given in parameter
        """

        #Get data of the function/step name
        data = self.__getData(name)

        j = 0
        stro = 'Details '+ name + ':\n'
        for i in range(self.maxProc):
            if data['val'][i] != None:
                j = j + 1
                stro += '\tProc: ' + str(i) + '\t' + str(data['val'][i][0]) +\
                        '\t(ncall ' + str(data['val'][i][1]) +')'
                if len(data['val'][i]) > 2:
                    stro += '\t[' + str(data['val'][i][2]) + ',' +\
                            str(data['val'][i][3]) + ']'

                stro += '\n'

                if j == data['nval']:
                    break

        return stro





    def getSteps(self, funName):
        """
        This function returns a list of the steps of the function
        given in param
        """
        steps = []
        if funName in self.funs.keys():
            steps = self.funs[funName]['steps'].keys()
        return steps





    def findMaxTime(self, name):
        """
        This function computes the maximum over all processors of the function
        given in parameter and returns the couple (rank,maxVal)
        """
        res  = None

        data = self.__getData(name)

        if data != None:
            val = data['val']
            rank = val.argmax(axis=0)
            res = (rank, val[rank])

        return res





    def getMaxTimeInfo(self, name):
        """
        Returns a dictionary containing info of the functions and steps
        called by proc numProc
        """

        numProc = self.findMaxTime(name)[0]
        out = {}
        data = self.funs[name]['data']['val']
        if data[numProc] != None:
            out['ftime'] = (data[numProc][0])
            if len(data[numProc]) > 2:
                out['ncall'] = data[numProc][1]
                out['min']   = data[numProc][2]
                out['max']   = data[numProc][3]
            for stepName, dataStep in self.funs[name]['steps'].iteritems():
                if dataStep['val'][numProc] != None:
                    out[stepName] = dataStep['val'][numProc][0]
                    if len(dataStep['val'][numProc]) > 2:
                        out['ncall '+stepName] = dataStep['val'][numProc][1]
                        out['min('+stepName+')'] = dataStep['val'][numProc][2]
                        out['max('+stepName+')'] = dataStep['val'][numProc][3]

        return out





    def strInfoProc(self, numProc):
        """
        Returns a string containing info of the functions and steps
        called by proc numProc
        """

        stro = '=============\n[Proc: ' + str(numProc) + ']\n'
        for funName, info in self.funs.iteritems():
            data = info['data']['val']
            if data[numProc] != None:
                stro += '\t' + funName + ' : ' + str(data[numProc][0]) + ' s'\
                  + ' (' + str(data[numProc][1]) + ')'
                if len(data[numProc]) > 2:
                    stro += '\t[' + str(data[numProc][2]) + ',' +\
                            str(data[numProc][3]) + ']'
                stro += '\n'
                for stepName, dataStep in info['steps'].iteritems():
                    if dataStep['val'][numProc] != None:
                        stro += '\t\t' + stepName + ' : '+\
                            str(dataStep['val'][numProc][0]) + ' s\n'
                        if len(dataStep['val'][numProc]) > 2:
                            stro += '\t[' + str(dataStep['val'][numProc][2]) +\
                                    ',' + str(dataStep['val'][numProc][3]) + ']'
        return stro
