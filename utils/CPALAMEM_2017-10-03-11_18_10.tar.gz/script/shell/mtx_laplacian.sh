N=$1;
echo "%%MatrixMarket matrix coordinate real symmetric";
echo "%S.Cayrols LAPLACIAN 1D";echo "$N $N $((N*2-1))";
for i in `seq $((N-1))`;
do echo $i $i 2; echo $i $((i+1))-1;
done;
echo "$N $N 2"
