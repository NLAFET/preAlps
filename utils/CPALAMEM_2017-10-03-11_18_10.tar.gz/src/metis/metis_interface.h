/*
* This file contains functions used for tracking symbolic pointer in a workspace
*
* Authors : Sebastien Cayrols
* Email   : sebastien.cayrols@[(gmail.com) | (inria.fr)]
*/
#ifndef METIS_INTERFACE_H
#define METIS_INTERFACE_H

#ifdef METISACTIVATE
  #include <metis.h>

  #include <ivector.h>
  #include <mat_csr.h>
  #include <metis_utils.h>

  idx_t* callKway(CPLM_Mat_CSR_t *matCSR, idx_t nbparts);
  
  int CPLM_metisKwayOrdering(CPLM_Mat_CSR_t *m1, CPLM_IVector_t *perm, int nblock, CPLM_IVector_t *posB);
#endif

#endif
