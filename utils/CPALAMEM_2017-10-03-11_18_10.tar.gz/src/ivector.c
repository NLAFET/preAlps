/*
* This file contains functions used to manipulate ivector
*
* Authors : Sebastien Cayrols
* Email   : sebastien.cayrols@[(gmail.com) | (inria.fr)]
*/
/**
 * \file ivector.c
 * \brief Structure to store an Integer Vector with an array of values and its size
 * \author Sebastien Cayrols
 * \version 0.1
 * \date 21 june 2013
 *
 *  For any question, email :  sebastien.cayrols@[(gmail.com) | (inria.fr)]
 *  DO NOT DISTRIBUTE
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>

#include "cpalamem_macro.h"
#include "ivector.h"
#include "QS.h"
#include "MPIutils.h"
#include "cpalamem_instrumentation.h"

#define handleMalloc(v_,l_) ((v_)->val == NULL) ?\
    CPLM_IVectorMalloc((v_), (l_)) : ierr
#define handleCalloc(v_,l_) ((v_)->val == NULL) ?\
     CPLM_IVectorCalloc((v_), (l_)) : ierr
#define handleRealloc(v_,l_) ((v_)->val == NULL) ?\
    CPLM_IVectorRealloc((v_), (l_)) : ierr
#define handleMRealloc(v_,l_) ((v_)->val == NULL) ?\
    CPLM_IVectorMalloc((v_), (l_)) : \
      ((v_)->size < (l_)) ? CPLM_IVectorRealloc((v_), (l_)) : ierr
//#define handleCRealloc(v_,l_) ((v_)->val == NULL) ?\
//    CPLM_IVectorCalloc((v_), (l_)) : \
//      ((v_)->size < (l_)) ? CPLM_IVectorRealloc((v_), (l_)) : ierr

/**
 * \fn CPLM_IVector_t permuteIVector(CPLM_IVector_t *v, CPLM_IVector_t *perm)
 * \brief This function permutes the CPLM_IVector_t v following the perm IVector. i -> perm(i)
 * \param *v The CPLM_IVector_t that has to be permuted. It contains a set of vertices
 * \param *perm The permutation IVector
 * \return The permuted IVector
 * Note : Values of v need to be in perm IVector
 * Computation complexity : size of v.
 * Memory complexity : size of v * size of int
 */
int CPLM_IVectorPermute(CPLM_IVector_t *v_in, CPLM_IVector_t *perm, CPLM_IVector_t *v_out)
{
CPLM_PUSH
CPLM_BEGIN_TIME

  int ierr = 0;

  CPLM_ASSERT(v_out->val == NULL);
  ierr = CPLM_IVectorMalloc(v_out, v_in->nval);CPLM_CHKERR(ierr);

  for(int i = 0; i < v_in->nval; i++)
  {
    v_out->val[i] = v_in->val[perm->val[i]];
  }

CPLM_END_TIME
CPLM_POP
  return ierr;
}





/**
 * \fn CPLM_IVector_t invertIVector(CPLM_IVector_t *v,int size)
 * \brief Function which inverts a IVector
 * \param *v The IVector
 * \return The inverted IVector
 */
/*Function which inverts a IVector*/
int CPLM_IVectorInvert(CPLM_IVector_t *v_in, CPLM_IVector_t *v_out)
{
CPLM_PUSH
CPLM_BEGIN_TIME
  int ierr = 0;

  ierr = handleMRealloc(v_out, v_in->nval);CPLM_CHKERR(ierr);

	for(int i = 0; i < v_in->nval; i++)
  {
		v_out->val[v_in->val[i]] = i;
  }

CPLM_END_TIME
CPLM_POP
	return ierr;
}


/**
 * \fn void CPLM_IVectorPrintPartial(CPLM_IVector_t *v)
 * \brief Method which prints partially a CPLM_IVector_t when the number of
 * values is greater than IVECTOR_MAXVAL_PRINT macro
 * and otherwise the IVectorPrint routine is called instead
 * \param *v The CPLM_IVector_t to print
 */
/*Function prints a CPLM_IVector_t*/
void CPLM_IVectorPrintPartial(CPLM_IVector_t *v)
{
CPLM_PUSH
CPLM_BEGIN_TIME

  if(v->nval > 2 * IVECTOR_MAXVAL_PRINT)
  {
    //Print the first part
    for(int i = 0; i < IVECTOR_MAXVAL_PRINT; i++)
    {
      printf("%d ",v->val[i]);
    }
    printf("... ");
    //Print the last part
    for(int i = v->nval - IVECTOR_MAXVAL_PRINT; i < v->nval; i++)
    {
      printf("%d ",v->val[i]);
    }
    printf("\n");
  }
  else
  {
    CPLM_IVectorPrint(v);
  }

CPLM_END_TIME
CPLM_POP
}





/**
 * \fn void CPLM_IVectorPrintPartial(CPLM_IVector_t *v)
 * \brief This method prints a CPLM_IVector_t 
 * \param *v The CPLM_IVector_t to print
 */
/*Function prints a CPLM_IVector_t*/
void CPLM_IVectorPrint(CPLM_IVector_t *v)
{
CPLM_PUSH
CPLM_BEGIN_TIME

	for(int i = 0; i < v->nval; i++)
  {
    printf("%d ",v->val[i]);
  }
	printf("\n");

CPLM_END_TIME
CPLM_POP
}





void CPLM_IVectorPrintWork(CPLM_IVector_t *v)
{
CPLM_PUSH
CPLM_BEGIN_TIME

	for(int i = 0; i < v->size; i++)
  {
    printf("%d ",v->val[i]);
  }
	printf("\n");

CPLM_END_TIME
CPLM_POP
}





/**
 * \fn void print_IVector(CPLM_IVector_t *v, const char *name)
 * \brief Method which prints a CPLM_IVector_t with its name
 * Note : This method is enable only if DEBUG is defined
 * \param *v The CPLM_IVector_t which has to be printed
 * \param *name The name of the IVector
 */
/*Function prints a CPLM_IVector_t called name*/
void CPLM_IVectorPrintWorkPartial(CPLM_IVector_t *v)
{
CPLM_PUSH
CPLM_BEGIN_TIME

  if(v->size > 2 * IVECTOR_MAXVAL_PRINT)
  {
    //Print the first part
    for(int i = 0; i < IVECTOR_MAXVAL_PRINT; i++)
    {
      printf("%d ",v->val[i]);
    }
    printf("... ");
    //Print the last part
    for(int i = v->size - IVECTOR_MAXVAL_PRINT; i < v->size; i++)
    {
      printf("%d ",v->val[i]);
    }
    printf("\n");
  }
  else
  {
    CPLM_IVectorPrintWork(v);
  }

CPLM_END_TIME
CPLM_POP
}


/**
 * \fn void send_IVector(CPLM_IVector_t *vec, int dest, int tag, MPI_Comm comm)
 * \brief Method which sends a CPLM_IVector_t to a process
 * \param *vec    The CPLM_IVector_t sent to dest
 * \param dest    The number of the process which will receive the IVector
 * \param tag     The tag of the communication
 * \param comm    The communicator for MPI
 * \return        0 if the CPLM_IVector_t is sent
 */
/*Function sends a CPLM_IVector_t to send_to*/
#ifdef MPIACTIVATE
int CPLM_IVectorSend(CPLM_IVector_t *v, int dest, int tag, MPI_Comm comm)
{
CPLM_PUSH
CPLM_BEGIN_TIME
	int ierr=0;
	//send length of the IVector
	ierr = MPI_Send(&v->nval,
      1,
      MPI_INT,
      dest,
      tag,
      comm);CPLM_checkMPIERR(ierr,"send_length");
	//send data of the IVector
	ierr = MPI_Send(v->val,
      v->nval,
      MPI_INT,
      dest,
      tag,
      comm);CPLM_checkMPIERR(ierr,"send_vec");
CPLM_END_TIME
CPLM_POP
  return ierr;
}
#endif




/**
 * \fn int CPLM_IVectorISend(CPLM_IVector_t *vec, int dest, int tag, MPI_Comm comm)
 * \brief Method which sends a CPLM_IVector_t to a process
 * \param *vec    The CPLM_IVector_t sent to dest
 * \param dest    The number of the process which will receive the IVector
 * \param tag     The tag of the communication
 * \param comm    The communicator for MPI
 * \return        0 if the CPLM_IVector_t is sent
 */
/*Function sends a CPLM_IVector_t to send_to*/
#ifdef MPIACTIVATE
int CPLM_IVectorISend( CPLM_IVector_t   *v,
                  int         dest,
                  int         tag,
                  MPI_Comm    comm,
                  MPI_Request **request)
{
CPLM_PUSH
CPLM_BEGIN_TIME

	int ierr = 0;

  if(*request == NULL)
  {
    *request = (MPI_Request *)malloc(2 * sizeof(MPI_Request));
  }

	//send length of the IVector
	ierr = MPI_Isend(&v->nval,
      1,
      MPI_INT,
      dest,
      tag,
      comm,
      &(*request[0]));CPLM_checkMPIERR(ierr,"send_length");

	//send data of the IVector
	ierr = MPI_Isend(v->val,
      v->nval,
      MPI_INT,
      dest,
      tag,
      comm,
      &(*request[1]));CPLM_checkMPIERR(ierr,"send_vec");

CPLM_END_TIME
CPLM_POP
  return ierr;
}
#endif



/**
 * \fn bCast_Vect(int *vec, int length, MPI_Comm comm, int root)
 * \brief Method which sends a CPLM_IVector_t to all processes
 * \param *vec The value array of the IVector
 * \param length The size of the IVector
 * \param comm The communicator for MPI
 * \param root The rank of the process which wants to send the IVector
 */
/*Function sends a CPLM_IVector_t to send_to*/
#ifdef MPIACTIVATE
int CPLM_IVectorBcast(CPLM_IVector_t *v, MPI_Comm comm, int root)
{
CPLM_PUSH
CPLM_BEGIN_TIME

	int ierr = 0;
	int rank = 0;

  MPI_Comm_rank(MPI_COMM_WORLD, &rank);

	ierr = MPI_Bcast(&v->nval,
      1,
      MPI_INT,
      root,
      comm);CPLM_checkMPIERR(ierr,"bcast_length");
	//send length of the IVector

	if(rank != root && v->val == NULL)
  {
    ierr = CPLM_IVectorMalloc(v, v->nval);CPLM_CHKERR(ierr);
  }

	//send data of the IVector
	ierr = MPI_Bcast(v->val,
      v->nval,
      MPI_INT,
      root,
      comm);CPLM_checkMPIERR(ierr,"bcast_vec");

CPLM_END_TIME
CPLM_POP
  return ierr;
}
#endif

/**
 * \fn CPLM_IVector_t recv_Vect(int recv_from, int tag, MPI_Comm comm)
 * \brief Function which manage the reception of a CPLM_IVector_t and return it
 * \param recv_from The number of the process sending the IVector
 * \param tag The tag of the communication
 * \param comm The communicator for MPI
 * \return The CPLM_IVector_t received
 */
/*Function returns a CPLM_IVector_t received from recv_from*/
#ifdef MPIACTIVATE
int CPLM_IVectorRecv(CPLM_IVector_t *v, int source, int tag, MPI_Comm comm)
{
CPLM_PUSH
CPLM_BEGIN_TIME

	MPI_Status status;
	int ierr    = 0;
  int length  = 0;

	//receive length of the IVector
	ierr = MPI_Recv(&length,
                  1,
                  MPI_INT,
                  source,
                  tag,
                  comm,
                  &status);CPLM_checkMPIERR(ierr,"recv_length");

  ierr = handleMRealloc(v, length);CPLM_CHKERR(ierr);

	//receive data of the IVector
	ierr = MPI_Recv(v->val,
                  v->size,
                  MPI_INT,
                  source,
                  tag,
                  comm,
                  &status);CPLM_checkMPIERR(ierr,"recv_vec");

  MPI_Get_count(&status, MPI_INT, &v->nval);

CPLM_END_TIME
CPLM_POP
	return ierr;
}
#endif



/**
 * \fn int CPLM_IVectorIRecv(CPLM_IVector_t *v, int source, int tag, MPI_Comm comm)
 * \brief Function which manage the reception of a CPLM_IVector_t and return it
 * \param v       The pointer of the CPLM_IVector_t to recv
 * \param source  The number of the process sending the IVector
 * \param tag     The tag of the communication
 * \param comm    The communicator for MPI
 * \return Error code
 */
/*Function returns a CPLM_IVector_t received from recv_from*/
#ifdef MPIACTIVATE
int CPLM_IVectorIRecv( CPLM_IVector_t   *v,
                  int         source,
                  int         tag,
                  MPI_Comm    comm,
                  MPI_Request *request)
{
CPLM_PUSH
CPLM_BEGIN_TIME

	MPI_Status status;
	int ierr = 0;
  int length = 0;

	//receive length of the IVector
	ierr = MPI_Irecv(&length,
      1,
      MPI_INT,
      source,
      tag,
      comm,
      request);CPLM_checkMPIERR(ierr,"recv_length");

  MPI_Wait(request,&status);

	ierr = CPLM_IVectorMalloc(v, length);CPLM_CHKERR(ierr);
  CPLM_ASSERT(v->val != NULL);

	//receive data of the IVector
	ierr = MPI_Irecv(v->val,
      v->size,
      MPI_INT,
      source,
      tag,
      comm,
      request);CPLM_checkMPIERR(ierr,"recv_vec");

CPLM_END_TIME
CPLM_POP
	return ierr;
}
#endif





#ifdef MPIACTIVATE
int CPLM_IVectorWait(  CPLM_IVector_t   *v,
                  MPI_Request *request,
                  MPI_Status  *status)
{
CPLM_PUSH
CPLM_BEGIN_TIME

  int ierr = 0;

  MPI_Wait(request, status);
  
  MPI_Get_count(status, MPI_INT, &v->nval);

CPLM_END_TIME
CPLM_POP
	return ierr;
}
#endif





int CPLM_IVectorAddSpace(CPLM_IVector_t *v, int length)
{
CPLM_PUSH
CPLM_BEGIN_TIME

  int ierr = 0;
  int nval = 0;

  nval = v->nval;

  if(v->val == NULL)
  {
    ierr = CPLM_IVectorMalloc(v, length);CPLM_CHKERR(ierr);
  }
  else
  {
    CPLM_debug("Extends of %d\n", length);
    ierr = CPLM_IVectorRealloc(v, v->size + length);CPLM_CHKERR(ierr);
  }

  v->nval = nval;

CPLM_END_TIME
CPLM_POP
  return ierr;
}




int CPLM_IVectorCreate(CPLM_IVector_t *v, int length, int *values)
{
CPLM_PUSH
CPLM_BEGIN_TIME

  int ierr = 0;

  ierr = CPLM_IVectorMalloc(v,length);CPLM_CHKERR(ierr);

  if (values != NULL)
  {
    memcpy(v->val, values, v->nval * sizeof(int));
  }

CPLM_END_TIME
CPLM_POP
  return ierr;
}




/*Function returns True if v1 and v2 contain the same values*/
int CPLM_IVectorIsSame(CPLM_IVector_t *v1, CPLM_IVector_t *v2)
{
CPLM_PUSH
CPLM_BEGIN_TIME

  int ok  = CPLM_TRUE;
  int sum = 0;

  if(v1->nval != v2->nval)
  {
    fprintf(stderr,"Error of data size\n%d != %d\n", v1->nval, v2->nval);
CPLM_END_TIME
CPLM_POP
    return !ok;
  }

#ifdef DEBUG
  for(int i = 0; i <v1->nval; i++)
  {
    if(v1->val[i] !=  v2->val[i])
    {
      fprintf(stderr,"Error of value\n%d != %d\n", v1->val[i], v2->val[i]);
CPLM_END_TIME
CPLM_POP
      return !ok;
    }
  }
#else
  for(int i = 0; i < v1->nval; i++)
    sum += abs(v1->val[i]-v2->val[i]);
#endif
CPLM_END_TIME
CPLM_POP
  return (sum > 0) ? !ok : ok ;
}





int CPLM_IVectorShiftValues(CPLM_IVector_t *v, int shift)
{
CPLM_PUSH
CPLM_BEGIN_TIME

  int ierr = 0;

  for(int i = 0; i < v->nval; i++)
  {
    v->val[i] +=  shift;
  }

CPLM_END_TIME
CPLM_POP
  return ierr;
}


/**
 * \fn int IVectorOffSetCopy(CPLM_IVector_t *v1, CPLM_IVector_t *v2, int offset)
 * \brief This function copies data of v2 in v1 starting at position offset. If the size of v1 is not enough, an additional memory size will be added
 * \param *v1     (in/out)  The CPLM_IVector_t where the data will be added
 * \param *v2     (in)      The CPLM_IVector_t whose data will be copied into v1
 * \param offset  (int)     The shift from the begin of the CPLM_IVector_t v1 where to copy data of v2. It could be negative. If so, the offset is seen as a looking backward from the end of v1.
 * \return Error code
 * Note : two bounds. It depends if the data of v2 added into v1 starting at offset, does not exceed the v1 size. Otherwise, There is a realloc needed
 * Computation complexity : o(size of v2) O(size of v1 + size of v2)
 * Memory complexity : o(size of v1) O(size of v2 + offset - size of v1)
 */
int CPLM_IVectorOffsetCopy(CPLM_IVector_t *v_io, CPLM_IVector_t *v_in, int offset)
{
CPLM_PUSH
CPLM_BEGIN_TIME
  int ierr = 0;

  if (offset < 0)
  {
    offset = v_io->size + offset;
    CPLM_ASSERT(offset >= 0);
  }

//if((offset + v_in->nval) > v_io->size)
//{
//  CPLM_debug("offset %d + v_in->nval %d ?> v_io->nval %d/%d\n", 
//      offset, v_in->nval, v_io->nval, v_io->size);
//  ierr = CPLM_IVectorAddSpace(v_io, offset + v_in->nval - v_io->size);CPLM_CHKERR(ierr);
//}
  
  CPLM_ASSERT(v_in->nval + offset <= v_io->size);
  memcpy(v_io->val + offset,
      v_in->val,
      v_in->nval * sizeof(int));
  
  v_io->nval += v_in->nval;

CPLM_END_TIME
CPLM_POP
  return ierr;
}


/**
 * \fn int CPLM_IVectorCopyData(CPLM_IVector_t *v1, CPLM_IVector_t *v2)
 * \brief This function copies data of v1 in v2. Condition v2 memory space is already allocated and have the same size as v1
 * \param *v1     (in)        The CPLM_IVector_t whose data will be copied into v2
 * \param *v2     (in/out)    The CPLM_IVector_t where the data will be copied
 * \return Error code
 * Computation complexity : O(size of v2)
 * Memory complexity : 0
 */
int CPLM_IVectorCopyData(CPLM_IVector_t *v1, CPLM_IVector_t *v2)
{
CPLM_PUSH
CPLM_BEGIN_TIME

  int ierr = 0;

  CPLM_ASSERT(v2->nval <= v1->size);
  CPLM_ASSERT(v1->val != NULL);
  CPLM_ASSERT(v2->val != NULL);

  memcpy(v1->val, v2->val, v2->nval * sizeof(int));

CPLM_END_TIME
CPLM_POP
  return ierr;

}







int CPLM_IVectorConcatInPlace(CPLM_IVector_t *v_io, CPLM_IVector_t *v_in, const char c)
{
CPLM_PUSH
CPLM_BEGIN_TIME
  int ierr = 0;

  CPLM_ASSERT(v_io != NULL);
  CPLM_ASSERT(v_in != NULL);
  CPLM_ASSERT(v_in->val != NULL);

  if(v_io->nval + v_in->nval > v_io->size)
  {
    ierr = CPLM_IVectorAddSpace(v_io, v_in->nval);CPLM_CHKERR(ierr);
    CPLM_ASSERT(v_io->val != NULL);
  }

  if(c == 'R')//Concat at right
  {
    memcpy(v_io->val + v_io->nval, v_in->val, v_in->nval * sizeof(int));
  }
  else if(c == 'L')//concat at left
  {
    memmove(v_io->val + v_in->nval,  v_io->val, v_io->nval * sizeof(int));
    memcpy(v_io->val, v_in->val, v_in->nval * sizeof(int));
  }
  else
  {
    CPLM_Abort("Unknown side to concat where");
  }


  v_io->nval += v_in->nval;

CPLM_END_TIME
CPLM_POP
  return ierr;
}




/*Function returns an union of two IVectors*/
/*Note: Constraint v1 inter v2 = NULL*/
int CPLM_IVectorFusion(CPLM_IVector_t *v1, CPLM_IVector_t *v2, CPLM_IVector_t *v3)
{
CPLM_PUSH
CPLM_BEGIN_TIME

  int ierr  = 0;
  int cpt   = 0;
  int i     = 0;
  int j     = 0;

  ierr = CPLM_IVectorMalloc(v3, v1->nval + v2->nval);CPLM_CHKERR(ierr);

  for(i = 0, j = 0; i < v1->nval && j < v2->nval; )
  {
    if(v1->val[i] < v2->val[j])
    {
      v3->val[cpt] = v1->val[i];
      i++;
      cpt++;
      continue;
    }
    if(v1->val[i] > v2->val[j])
    {
      v3->val[cpt] = v2->val[j];
      j++;
      cpt++;
      continue;
    }
  }

  if(i == v1->nval)
  {
    for(int i = j; i < v2->nval; i++)
    {
      v3->val[cpt] = v2->val[i];
      cpt++;
    }
  }
  else
  {
    for(int j = i; j < v1->nval; j++)
    {
      v3->val[cpt] = v1->val[j];
      cpt++;
    }
  }

CPLM_END_TIME
CPLM_POP
  return ierr;
}





/*Function returns a copy of v1*/
int CPLM_IVectorCopy(CPLM_IVector_t *v1, CPLM_IVector_t *v2)
{
CPLM_PUSH
CPLM_BEGIN_TIME

  int ierr = 0;

  ierr = CPLM_IVectorMalloc(v2, v1->nval);CPLM_CHKERR(ierr);

  memcpy(v2->val, v1->val, v2->nval * sizeof(int));

CPLM_END_TIME
CPLM_POP
  return ierr;
}





//compute the sum of all elements of v
int CPLM_IVectorReduce(CPLM_IVector_t *v, int *sum)
{
CPLM_PUSH
CPLM_BEGIN_TIME

  int ierr  = 0;
  int lsum  = 0;

  for(int i = 0; i < v->nval; i++)
  {
    lsum += v->val[i];
  }

  *sum = lsum;

CPLM_END_TIME
CPLM_POP
  return ierr;
}





//Count how many nnz inside
int CPLM_IVectorCountNNZ(CPLM_IVector_t *v, int *sum)
{
CPLM_PUSH
CPLM_BEGIN_TIME

  int ierr  = 0;
  int lsum  = 0;

  for(int i = 0; i < v->size; i++)
  {
    if(v->val[i])
    {
      lsum++;
    }
  }

  *sum = lsum;

CPLM_END_TIME
CPLM_POP
  return ierr;
}





int CPLM_IVectorSum(CPLM_IVector_t *u_in, CPLM_IVector_t *v_in, CPLM_IVector_t *w_out, int op)
{
CPLM_PUSH
CPLM_BEGIN_TIME
  int ierr = 0;

  if(u_in->nval != v_in->nval)
  {
    CPLM_Abort("Size of u %d/%d is not equal to size of v %d/%d",
        u_in->nval,
        u_in->size,
        v_in->nval,
        v_in->size);
  }

  if(w_out->size < u_in->nval)
  {
    if(w_out->val == NULL)
    {
      ierr = CPLM_IVectorMalloc(w_out, u_in->nval);CPLM_CHKERR(ierr);
    }
    else
    {
      ierr = CPLM_IVectorCalloc(w_out, u_in->nval);CPLM_CHKERR(ierr);
    }
  }

  switch(op)
  {
    case 0: //i.e. sum
      for(int i = 0; i < u_in->nval; i++)
      {
        w_out->val[i] = u_in->val[i] + v_in->val[i];
      }
      break;

    case 1:
      for(int i = 0; i < u_in->nval; i++)
      {
        w_out->val[i] = u_in->val[i] - v_in->val[i];
      }
      break;

    default:
      CPLM_Abort("op %d is unknown",op);
  }
CPLM_END_TIME
CPLM_POP
  return ierr;
}





/*Function returns a subset of v1*/
int CPLM_IVectorSub(CPLM_IVector_t *v_in, int begin, int size, CPLM_IVector_t *v_io)
{
CPLM_PUSH
CPLM_BEGIN_TIME

  int ierr = 0;

  ierr = handleMRealloc(v_io, size);CPLM_CHKERR(ierr);

  memcpy(v_io->val, &v_in->val[begin], v_io->nval * sizeof(int));

  v_io->nval = size;

CPLM_END_TIME
CPLM_POP
  return ierr;
}





//ASSUMING v is sorted
int CPLM_IVectorGetPos(CPLM_IVector_t *v, int a, int *pos)
{
CPLM_PUSH
CPLM_BEGIN_TIME
  int not_found = 0;
  int begin     = 0;
  int end       = 0;
  int curPos    = 0;
  int ierr      = 0;

  end   = v->nval;
  *pos  = -1;

  while(!not_found)
  {
    curPos  = (end + begin) / 2;

    if(a < v->val[curPos])
    {
      end = curPos;
    }
    else if(a > v->val[curPos])
    {
      begin = curPos;
    }
    else
    {
      *pos      = curPos;
      not_found = 1;
    }

    if(begin == end)
    {
      //*pos      = begin + 1;//DO not understand why...
      //not_found = 1;
      break;
    }
  }

  if(*pos == -1)
    ierr = 1;

CPLM_END_TIME
CPLM_POP
  return ierr;

}





/**
  *
  *
  * Computation complexity : 2 * number of lines in fileName
  * Memory complexity      : length of tmp + size of CPLM_IVector_t * size of int
**/
int CPLM_IVectorLoad(const char *fileName, CPLM_IVector_t *buf, int size)
{
CPLM_PUSH
CPLM_BEGIN_TIME
  FILE *fd = NULL;
  int ierr    = 0;
  int length  = 512;
  int nbLine  = size;
  int cpt     = 0;
  int nread   = 0;
  int v       = 0;
  int t       = 0;
  int begin   = 0;
  char *tmp = NULL;

  tmp = (char*)malloc(length * sizeof(char));
  CPLM_ASSERT(tmp != NULL);

  fd=fopen(fileName,"r");
  if(!fd)
  {
    CPLM_Abort("Error, impossible to load %s\n",fileName);
  }

  if(!nbLine)
  {
    //avoid comments
    while(fgets(tmp,length,fd))
    {
      if(tmp[0] == '%')
        continue;
      else
        break;
    }

    //test if number of lines is in the file
    cpt = sscanf(tmp,"%d %d",&v,&t);
    if(cpt == 2)
      nbLine = v;

    if(!nbLine)
    {
      nbLine++;
      while(fgets(tmp,length,fd))
      {
        nbLine++;
      }
    }

    fseek(fd,0,SEEK_SET);
  }

  ierr = CPLM_IVectorMalloc(buf, nbLine);CPLM_CHKERR(ierr);

  while(fgets(tmp,length,fd))
  {
    if(tmp[0] == '%')
      continue;
    else
      break;
  }

  cpt = sscanf(tmp,"%d %d",&v,&t);
  if(cpt==1)
  {
    buf->val[0] = v;
    begin = 1;
  }

  for(int i = begin; i < buf->nval; i++)
  {
    nread = fscanf(fd,"%d",&buf->val[i]);
  }

  free(tmp);
  fclose(fd);
CPLM_END_TIME
CPLM_POP
  return ierr || !nread;
}



/**
  *
  *
  * Computation complexity : size of the IVector
**/
int CPLM_IVectorSave(CPLM_IVector_t *v,const char *fileName, const char *header)
{
CPLM_PUSH
CPLM_BEGIN_TIME
  FILE *fd = NULL;

  CPLM_ASSERT(v->nval  > 0);
  CPLM_ASSERT(v->val  != NULL);

  fd = fopen(fileName,"w");
  CPLM_ASSERT(fd != NULL);
  if(!fd){
    CPLM_Abort("Error, impossible to create %s\n",fileName);
  }

  fprintf(fd,"%%%s\n%d 1\n",header, v->nval);

  for(int i = 0; i < v->nval; i++)
  {
    fprintf(fd,"%d\n", v->val[i]);
  }

  fclose(fd);

CPLM_END_TIME
CPLM_POP
  return 0;
}





#if 0
void CPLM_IVectorTestFunction(){
CPLM_PUSH
CPLM_BEGIN_TIME

#ifndef TEST
	printf("To activate this method, please recompile it with TEST defined\n");
#else
  int ierr  = 0;
  int ok    = 0;
  int nv    = 5;
  int cpt   = 0;

  CPLM_IVector_t buf  = CPLM_IVectorNULL();
  CPLM_IVector_t comp = CPLM_IVectorNULL();
  CPLM_IVector_t tmp  = CPLM_IVectorNULL();
  CPLM_IVector_t perm = CPLM_IVectorNULL();



  //CHECK IVectorNULL
  CPLM_IVector_t v0   = CPLM_IVectorNULL();
  ierr = (v0.nval == 0) && (v0.val == NULL);
  ok  = ok || !ierr;
  if(!ierr) eprintf("IVectorNULL");



  //CHECH IVectorMalloc
  ierr = CPLM_IVectorMalloc(&v0,0) || !IVectorMalloc(&v0,-1) || IVectorMalloc(&v0,nv);
  ok  = ok || ierr;
  if(ierr) eprintf("IVectorMalloc");



  //CHECK IVectorFree
  CPLM_IVectorFree(&v0);
  ierr = (v0.nval != nv) || (v0.nval == 0) || (v0.val == NULL);
  ok  = ok || !ierr;
  if(!ierr) eprintf("IVectorFree");



  //CHECK IVectorIsSame
  CPLM_IVector_t v1 = CPLM_IVectorNULL();
  CPLM_IVector_t v2 = CPLM_IVectorNULL();
  CPLM_IVector_t v3 = CPLM_IVectorNULL();
  CPLM_IVector_t v4 = CPLM_IVectorNULL();

  ierr = CPLM_IVectorMalloc(&v1,nv);CPLM_CHKERR(ierr);
  ierr = CPLM_IVectorMalloc(&v2,nv);CPLM_CHKERR(ierr);
  ierr = CPLM_IVectorMalloc(&v3,nv);CPLM_CHKERR(ierr);
  ierr = CPLM_IVectorMalloc(&v4,11);CPLM_CHKERR(ierr);

  //same IVectors
  for(int i=0;i<v1.nval;i++)
    v1.val[i]=v2.val[i]=i;

  //different values
  for(int i=0;i<v3.nval;i++)
    v3.val[i]=v3.nval-i-1;

  //different values and size
  for(int i=0;i<v4.nval;i++)
    v4.val[i]=-i;

  //match same IVector, different IVectors but same size, different IVectors with different size, a CPLM_IVector_t with a null CPLM_IVector_t AND a null CPLM_IVector_t with null IVector
  ierr = CPLM_IVectorIsSame(&v1,&v2) || !IVectorIsSame(&v1,&v3) || !IVectorIsSame(&v2,&v4) || !IVectorIsSame(&v0,&v4) || IVectorIsSame(&v0,&v0);
  ok  = ok || ierr;
  if(ierr) eprintf("IVectorIsSame");



  //CHECK IVectorCalloc
  CPLM_IVectorFree(&v4);
  ierr = CPLM_IVectorMalloc(&comp,11);CPLM_CHKERR(ierr);
  for(int i=0;i<11;i++)
    comp.val[i]=0;


  ierr =  CPLM_IVectorCalloc(&tmp,0) || IVectorCalloc(&v4,11) || CPLM_IVectorIsSame(&v4,&comp) || !IVectorCalloc(&tmp,-1);
  ok  = ok || ierr;
  if(ierr) eprintf("IVectorCalloc");
  CPLM_IVectorFree(&tmp);
  CPLM_IVectorFree(&comp);





  //CHECK IVectorLoad
  ierr = !CPLM_IVectorLoad("../TestDir/foo",&buf,0) || IVectorLoad("../TestDir/testLoadIVector.vec", &buf, 0) || CPLM_IVectorIsSame(&v1,&buf);
  ok  = ok || ierr;
  if(ierr) eprintf("IVectorLoad");



  //CHECK IVectorSave
  ierr = !CPLM_IVectorSave(&v0,"../TestDir/foo") || IVectorSave(&buf,"../TestDir/erase_file") || CPLM_IVectorLoad("../TestDir/erase_file", &comp, 0) || CPLM_IVectorIsSame(&buf,&comp);
  ok  = ok || ierr;
  if(ierr) eprintf("IVectorSave");



  //CHECK IVectorCopy
  ierr = CPLM_IVectorCopy(&v3,&perm);CPLM_CHKERR(ierr);
  ierr = CPLM_IVectorIsSame(&v3,&perm);
  if(ierr) eprintf("IVectorCopy");
  CPLM_IVectorFree(&perm);



  //CHECK IVectorSequence
  ierr = CPLM_IVectorSequence(&perm,0,nv-1,1);
  ierr = CPLM_IVectorIsSame(&v1,&perm);
  ok  = ok || ierr;
  if(ierr) eprintf("IVectorSequence");
  CPLM_IVectorFree(&perm);



  //CHECK IVectorRemove
  ierr = CPLM_IVectorMalloc(&comp,v1.nval-1);CPLM_CHKERR(ierr);
  for(int i=0;i<v1.nval;i++){
    if(i==3)
      continue;
    else
      comp.val[cpt++]=i;
  }
  cpt = 0;
  ierr = CPLM_IVectorMalloc(&tmp,nv);
  //try to remove 3
  ierr = CPLM_IVectorConstant(&tmp,3);
  ierr = CPLM_IVectorRemove(&v1,&tmp);
  ierr = CPLM_IVectorIsSame(&v1,&comp);
  ok  = ok || ierr;
  //try to remove 7
  ierr = CPLM_IVectorConstant(&tmp,7);
  ierr = CPLM_IVectorRemove(&v1,&tmp);
  ierr = CPLM_IVectorIsSame(&v1,&comp);
  ok  = ok || ierr;
  if(ierr) eprintf("IVectorRemove");
  CPLM_IVectorFree(&comp);
  CPLM_IVectorFree(&tmp);




  //CHECK IVectorOffsetCopy
  ierr = CPLM_IVectorSequence(&tmp,0,2,1)CPLM_CHKERR(ierr);
  ierr = CPLM_IVectorMalloc(&comp,nv);CPLM_CHKERR(ierr);
  ierr = CPLM_IVectorConstant(&comp,3);CPLM_CHKERR(ierr);
  ierr = CPLM_IVectorOffsetCopy(&comp, &tmp, 0);CPLM_CHKERR(ierr);
  CPLM_IVectorFree(&tmp);
  ierr = CPLM_IVectorMalloc(&tmp,1);CPLM_CHKERR(ierr);
  ierr = CPLM_IVectorConstant(&tmp,4);CPLM_CHKERR(ierr);
  ierr = CPLM_IVectorOffsetCopy(&comp, &tmp, -1);CPLM_CHKERR(ierr);
  ierr = CPLM_IVectorIsSame(&v2,&comp);
  ok  = ok || ierr;
  if(ierr) eprintf("IVectorOffsetCopy");
  CPLM_IVectorFree(&comp);
  CPLM_IVectorFree(&tmp);



  //TODO
  //CHECK IVectorFusion
  //CHECK IVectorConcatInPlace
  //CHECK IVectorReduce
  //CHECK IVectorSub
  //CHECK IVectorGetPos
  //CHECK IVectorRealloc
  //CHECK IVectorAddSpace
  //CHECK IVectorConstant
  //CHECK IVectorRandom
  //CHECK IVectorPermute
  //CHECK IVectorInvert
  //ALL MPI functions
  //CHECK IVector

  if(!ok) printf("*************************************\nTests of Object CPLM_IVector_t are ok\n");

  CPLM_IVectorFree(&v0);
  CPLM_IVectorFree(&v1);
  CPLM_IVectorFree(&v2);
  CPLM_IVectorFree(&v3);
  CPLM_IVectorFree(&v4);
#endif
CPLM_END_TIME
CPLM_POP

}
#endif





int CPLM_IVectorConstant(CPLM_IVector_t *v, int cst)
{
CPLM_PUSH
CPLM_BEGIN_TIME

  int ierr  = 0;

  CPLM_ASSERT(v->val != NULL);

  for(int i = 0; i < v->nval; i++)
  {
    v->val[i] = cst;
  }

CPLM_END_TIME
CPLM_POP
  return ierr;
}





int CPLM_IVectorSequence(CPLM_IVector_t *v, int begin, int end, int step)
{
CPLM_PUSH
CPLM_BEGIN_TIME

  int ierr    = 0;
  int length  = (end-begin)/step + 1;

  ierr = handleMalloc(v, length);CPLM_CHKERR(ierr);

  CPLM_ASSERT(length == v->nval);

  v->val[0] = begin;

  for(int i = 1; i < length; i++)
  {
    v->val[i] = v->val[i - 1] + step;
  }

CPLM_END_TIME
CPLM_POP
  return ierr;
}





int CPLM_IVectorRandom(CPLM_IVector_t *v, int generatorSeed)
{
CPLM_PUSH
CPLM_BEGIN_TIME

  int ierr  = 0;

  CPLM_ASSERT(v->val != NULL);

  srand(generatorSeed);

  for(int i = 0; i < v->nval; i++)
  {
    v->val[i] = (int)( rand() % 100 );
  }

CPLM_END_TIME
CPLM_POP
  return ierr;
}





int CPLM_IVectorSort(CPLM_IVector_t *v)
{
CPLM_PUSH
CPLM_BEGIN_TIME

  int ierr  = 0;

  CPLM_quickSort(v->val, 0, v->nval - 1);

CPLM_END_TIME
CPLM_POP
  return ierr;
}



//#define OLDREMOVE

//ASSUME v and r are sorted
//remove elements of r (if exist) from v
#ifdef OLDREMOVE
int CPLM_IVectorRemove(CPLM_IVector_t *v, CPLM_IVector_t *r)
#else
int IVectorRmElements(CPLM_IVector_t *v, CPLM_IVector_t *r)
#endif
{
CPLM_PUSH
CPLM_BEGIN_TIME
  int ierr  = 0;
  int ptr_v = 0;
  int ptr_r = 0;
  int cpt   = 0;
  int niter = 0;
  int nskip = 0;
  CPLM_IVector_t tmp = CPLM_IVectorNULL();

  CPLM_ASSERT(v->val != NULL);
  CPLM_ASSERT(r->val != NULL);

  CPLM_IVectorPrintf("v", v);
  CPLM_IVectorPrintf("r", r);

  ierr = CPLM_IVectorMalloc(&tmp,v->nval);CPLM_CHKERR(ierr);

  while(ptr_v<v->nval && ptr_r<r->nval)
  {
    niter++;
    if(ptr_v == 48)
    {
      printf("ptr_v %d ptr_r %d\tv_io->val = %d\t r_in->val = %d\n",
          ptr_v, ptr_r, v->val[ptr_v], r->val[ptr_r]);
    }
    //printf("v->val[%d] = %d ?? r->val[%d] = %d\n",ptr_v,v->val[ptr_v],ptr_r,r->val[ptr_r]);
    //remove this element
    if(v->val[ptr_v] == r->val[ptr_r])
    {
      if(v->nval == 342)
        printf("[%d] remove %d => v->val[%d] == r->val[%d] == %d\n",
            niter, nskip, ptr_v, ptr_r, v->val[ptr_v]);
      nskip++;
      ptr_v++;
      ptr_r++;
    }
    else
    {
      //Ignore the r current value
      if(v->val[ptr_v] > r->val[ptr_r])
      {
        ptr_r++;
        if(v->nval == 342)
          printf("Move ptr_r %d\n",ptr_r);
      }
      else
      {
        if(v->nval == 342)
          printf("v->val[%d] = v->val[%d] => added %d\n",
              cpt, ptr_v, v->val[ptr_v]);
        tmp.val[cpt++] = v->val[ptr_v];
        ptr_v++;
      }
    }
  }

  printf("niter %d, nremove %d, ptr_v %d ptr_r %d cpt %d\n",
      niter, nskip, ptr_v, ptr_r, cpt);

  //Test if it remains data
  if(ptr_v < v->nval)
  {
    memcpy(&(tmp.val[cpt]), &(v->val[ptr_v]), (v->nval - ptr_v) * sizeof(int));
    cpt += v->nval-ptr_v;
    if(v->nval == 342)
      printf("Remaining added %d\n", v->nval - ptr_v);
  }

  CPLM_IVectorFree(v);
  v->val  = tmp.val;
  v->nval = cpt;

CPLM_END_TIME
CPLM_POP
  return ierr;
}





//ASSUME v and r are sorted
//remove elements of r (if exist) from v
#ifdef OLDREMOVE
int IVectorRmElements(CPLM_IVector_t *v_io, CPLM_IVector_t *r_in)
#else
int CPLM_IVectorRemove(CPLM_IVector_t *v_io, CPLM_IVector_t *r_in)
#endif
{
CPLM_PUSH
CPLM_BEGIN_TIME
  int ierr  = 0;
  int ptr_v = 0;
  int ptr_r = 0;
  int pos   = 0;

  CPLM_ASSERT(v_io->val != NULL);
  CPLM_ASSERT(r_in->val != NULL);

  while((ptr_v < v_io->nval) && (ptr_r < r_in->nval))
  {
    //remove this element
    if(v_io->val[ptr_v] == r_in->val[ptr_r])
    {
      ptr_v++;
      ptr_r++;
    }
    else
    {
      //Ignore the r current value
      if(v_io->val[ptr_v] > r_in->val[ptr_r])
      {
        ptr_r++;
      }
      else
      {
        v_io->val[pos]  = v_io->val[ptr_v];
        pos++;
        ptr_v++;
      }
    }
  }

  //Test if it remains data
  if(ptr_v < v_io->nval)
  {
    memmove(v_io->val + pos,
            v_io->val + ptr_v,
            (v_io->nval - ptr_v) * sizeof(int));
    pos += v_io->nval - ptr_v;
  }

  v_io->nval = pos;

CPLM_END_TIME
CPLM_POP
  return ierr;
}





int CPLM_IVectorCreateFromPtr(CPLM_IVector_t *v, int length, int *val)
{
CPLM_PUSH
CPLM_BEGIN_TIME
  int ierr  = 0;

  CPLM_ASSERT(val    != NULL);
  CPLM_ASSERT(v->val == NULL);
  CPLM_ASSERT(length >= 0);

  v->nval = length;
  v->size = length;
  v->val  = val;

CPLM_END_TIME
CPLM_POP
  return ierr;
}





int CPLM_IVectorSwap(CPLM_IVector_t *v1, CPLM_IVector_t *v2)
{
CPLM_PUSH
CPLM_BEGIN_TIME
  int ierr  = 0;
  int *tmp  = NULL;
  int nv    = 0;

//CPLM_ASSERT(v1->val != NULL);
//CPLM_ASSERT(v2->val != NULL);

  tmp     = v1->val;
  v1->val = v2->val;
  v2->val = tmp;

  nv        = v1->nval;
  v1->nval  = v2->nval;
  v2->nval  = nv;

  nv        = v1->size;
  v1->size  = v2->size;
  v2->size  = nv;

CPLM_END_TIME
CPLM_POP
  return ierr;
}




/*
 *  Memory check allocation
 */





int CPLM_IVectorMallocChk( CPLM_IVector_t   *v_out,
                      int         length,
                      const char  *file,
                      int         line,
                      const char  *varName)
{
CPLM_PUSH
CPLM_BEGIN_TIME
  v_out->size = length;
  v_out->nval = length;

  CPLM_ASSERT(v_out      != NULL);
  CPLM_ASSERT(v_out->val == NULL);

  v_out->val  = (int*)CPLM_malloc(v_out->size * sizeof(int),
      file,
      line,
      varName);

CPLM_END_TIME
CPLM_POP
  return !(v_out->val != NULL);
}





int CPLM_IVectorCallocChk( CPLM_IVector_t   *v_out,
                      int         length,
                      const char  *file,
                      int         line,
                      const char  *varName)
{
CPLM_PUSH
CPLM_BEGIN_TIME

  CPLM_ASSERT(v_out      != NULL);
  CPLM_ASSERT(v_out->val == NULL);

  v_out->nval = length;
  v_out->size = length;
  v_out->val  = (int*)CPLM_calloc(v_out->size,
      sizeof(int),
      file,
      line,
      varName);

CPLM_END_TIME
CPLM_POP
  return !(v_out->val != NULL);
}





int CPLM_IVectorReallocChk(CPLM_IVector_t   *v_io,
                      int         length,
                      const char  *file,
                      int         line,
                      const char  *varName)
{
CPLM_PUSH
CPLM_BEGIN_TIME

  v_io->size = length;
  v_io->nval = length;

  CPLM_ASSERT(v_io       != NULL);
  CPLM_ASSERT(v_io->val  != NULL);

  v_io->val  = (int*)CPLM_realloc(v_io->val,
      v_io->size * sizeof(int),
      file,
      line,
      varName);

CPLM_END_TIME
CPLM_POP
  return !(v_io->val != NULL);
}





void CPLM_IVectorFreeChk(CPLM_IVector_t   *v_io,
                    const char  *file,
                    int         line,
                    const char  *varName)
{
CPLM_PUSH
CPLM_BEGIN_TIME

  if(v_io)
  {
    if(v_io->val)
    {
      CPLM_free(v_io->val, file, line, varName);
    }
    v_io->nval = 0;
    v_io->size = 0;
    v_io->val  = NULL;
  }

CPLM_END_TIME
CPLM_POP
}





#ifndef MEMCHECK
int CPLM_IVectorMalloc(CPLM_IVector_t *v_out,
                  int       length)
{
CPLM_PUSH
CPLM_BEGIN_TIME
  v_out->size = length;
  v_out->nval = length;

  CPLM_ASSERT(v_out      != NULL);
  CPLM_ASSERT(v_out->val == NULL);

  v_out->val  = (int*)malloc(v_out->size * sizeof(int));

CPLM_END_TIME
CPLM_POP
  return !(v_out->val != NULL);
}





int CPLM_IVectorCalloc(CPLM_IVector_t *v_out,
                  int       length)
{
CPLM_PUSH
CPLM_BEGIN_TIME

  CPLM_ASSERT(v_out      != NULL);
  CPLM_ASSERT(v_out->val == NULL);

  v_out->nval = length;
  v_out->size = length;
  v_out->val  = (int*)calloc(v_out->size, sizeof(int));

CPLM_END_TIME
CPLM_POP
  return !(v_out->val != NULL);
}





int CPLM_IVectorRealloc( CPLM_IVector_t *v_io,
                    int       length)
{
CPLM_PUSH
CPLM_BEGIN_TIME

  v_io->size = length;
  v_io->nval = length;

  CPLM_ASSERT(v_io       != NULL);
  CPLM_ASSERT(v_io->val  != NULL);

  v_io->val  = (int*)realloc(v_io->val, v_io->size * sizeof(int));

CPLM_END_TIME
CPLM_POP
  return !(v_io->val != NULL);
}





void CPLM_IVectorFree(CPLM_IVector_t *v_io)
{
CPLM_PUSH
CPLM_BEGIN_TIME

  if(v_io)
  {
    if(v_io->val)
    {
      free(v_io->val);
    }
    v_io->nval = 0;
    v_io->size = 0;
    v_io->val  = NULL;
  }

CPLM_END_TIME
CPLM_POP
}
#endif
