/*
* This file contains functions used for tracking symbolic pointer in a workspace
*
* Authors : Sebastien Cayrols
* Email   : sebastien.cayrols@[(gmail.com) | (inria.fr)]
*/

#include <math.h>
#include <stdio.h>
#include <stdlib.h>

#include <cpalamem_macro.h>
#include <MPIutils.h>
#include <abstractTree.h>
#include <cpalamem_instrumentation.h>

int CPLM_TreeCall(CPLM_TreeVoid_t *data)
{
CPLM_PUSH
CPLM_OPEN_TIMER

  int ierr  = 0;
  int rank  = 0;
  int size  = 1;

  MPI_Comm_rank(data->comm, &rank);
  MPI_Comm_size(data->comm, &size);

  CPLM_ASSERT(data->src  != NULL);
  CPLM_ASSERT(data->dest != NULL);

  for(int i = 0; i < data->nlvl; i++)
  {
    if( data->dest[i] != rank )
    {
      ierr = ( data->kernelS != NULL ) ? data->kernelS(data) : ierr;
      ierr = data->send(data,
                        data->dest[i],
                        0,
                        data->comm);CPLM_checkMPIERR(ierr,"send data");
    }

    if( data->src[i] != rank )
    {
      ierr = data->recv(data,
                        data->src[i],
                        0,
                        data->comm);CPLM_checkMPIERR(ierr,"Recv data");
      ierr = ( data->kernelR != NULL ) ? data->kernelR(data) : ierr;
    }
  }

  MPI_Waitall(data->nrequestS, data->requestS, data->statusS);

CPLM_CLOSE_TIMER
CPLM_POP
  return ierr;
}





int CPLM_TreeCallCreate(CPLM_TreeVoid_t *data, fcommScheme commScheme, MPI_Comm comm)
{
CPLM_PUSH
  int ierr = 0;

  data->comm = comm;

  ierr = CPLM_TreeCallSetCommScheme(data, commScheme);CPLM_CHKERR(ierr);

CPLM_POP
  return ierr;
}





int CPLM_TreeCallSetCommScheme(CPLM_TreeVoid_t *data, fcommScheme commScheme)
{
CPLM_PUSH

  int ierr = 0;
  int rank = 0;
  int size = 1;
  int nlvl = 0;

  data->commScheme  = commScheme;
  nlvl              = data->nlvl;
  data->nrequestR   = 0;
  data->nrequestS   = 0;

  MPI_Comm_rank(data->comm, &rank);
  MPI_Comm_size(data->comm, &size);

  ierr = data->commScheme(rank,
                          size,
                          &data->src,
                          &data->dest,
                          &data->nlvl);CPLM_CHKERR(ierr);

  if(data->requestS == NULL)
  {
    data->requestS = (MPI_Request*) malloc(data->nlvl * sizeof(MPI_Request));
    data->requestR = (MPI_Request*) malloc(data->nlvl * sizeof(MPI_Request));

    data->statusS  = (MPI_Status*)  malloc(data->nlvl * sizeof(MPI_Status));
    data->statusR  = (MPI_Status*)  malloc(data->nlvl * sizeof(MPI_Status));
  }
  else
  {
    if(nlvl < data->nlvl)
    {
      data->requestS = (MPI_Request*) realloc(data->requestS, data->nlvl * sizeof(MPI_Request));
      data->requestR = (MPI_Request*) realloc(data->requestR, data->nlvl * sizeof(MPI_Request));

      data->statusS  = (MPI_Status*)  realloc(data->statusS, data->nlvl * sizeof(MPI_Status));
      data->statusR  = (MPI_Status*)  realloc(data->statusR, data->nlvl * sizeof(MPI_Status));
    }
  }

  CPLM_ASSERT(data->requestS != NULL);
  CPLM_ASSERT(data->requestR != NULL);
  CPLM_ASSERT(data->statusS  != NULL);
  CPLM_ASSERT(data->statusR  != NULL);
  
CPLM_POP
  return ierr;
}




int CPLM_TreeCallDestroy(CPLM_TreeVoid_t *data)
{
CPLM_PUSH
  int ierr = 0;

  CPLM_free(data->src);
  CPLM_free(data->dest);
  
  CPLM_free(data->requestS);
  CPLM_free(data->requestR);
  
  CPLM_free(data->statusS);
  CPLM_free(data->statusR);

CPLM_POP
return ierr;
}



/******************************************************************
*
*                         OLD PART (Coming from tsqr)
*
*******************************************************************/
/* Function that computes the steps that a processor i is going to do during a TSQR according to the tree form */
int CPLM_TreelevelsToStep(int rank, int size, CPLM_TreeType_t treeType, int *nlvl)
{
  int ierr    = 0;
  int levels  = 0;

  switch (treeType)
  {
    case FlatTree :
      if(rank == 0)
        levels=size - 1;
      else
        levels = 0;
      break;

    case BinaryTree :
      if(size == 1)
        levels = 0;
      else if(size == 2)
      {
        if(rank == 0)
          levels = 1;
        else if(rank == 1)
          levels = 0;
      }
      if(size % 2 == 0 && size > 2)
      {
        if(rank % 2 == 0)
        {
          CPLM_TreelevelsToStep(rank/2, size/2, treeType, &levels);
          levels++;
        } 
        else if(rank % 2 == 1)
          levels = 0;
      }
      if(size % 2 == 1 && size > 2)
      {
        if(rank % 2 == 0 && rank +1 != size)
        {
          CPLM_TreelevelsToStep(rank/2, (size + 1)/2, treeType, &levels);
          levels++;
        }
        else if(rank +1 == size)
        {
          CPLM_TreelevelsToStep(rank/2, (size + 1)/2, treeType, &levels);
        }
        else if(rank % 2 == 1)
          levels = 0;
      }
      break;

    case SebTree :

      if(size == 1)
      {
        levels = 0;
      }
      else if(size == 2)
      {
        if(rank == 0)
          levels = 1;
        else if(rank == 1)
          levels = 0;
        else
        {
          CPLM_Abort("the rank %d has to be less than %d",rank,size);
        }
      }
      else if(size % 2 == 0 && size > 2)
      {
        if(rank * 2 < size )
        {
          CPLM_TreelevelsToStep(rank, size/2, treeType, &levels);
          levels++;
        }
        else
          levels = 0;
      }
      else if(size % 2 == 1 && size > 2)
      {
        if(rank * 2 < size - 1)
        {
          CPLM_TreelevelsToStep(rank, (size + 1)/2, treeType, &levels);
          levels++;
        }
        else if(rank == (size - 1)/2)
        {
          CPLM_TreelevelsToStep(rank, (size + 1)/2, treeType, &levels);
          levels++;
        }
        else if(size < rank * 2 && rank != (size - 1)/2)
        {
          levels = 0;
        }
        else
        {
          CPLM_Abort("Unknown case");
        }
      }
      break;

    default:
      CPLM_Abort("Unknown treeType %d",treeType);
  }

  *nlvl = levels;

  return ierr;
}

/* Function that determines the complement processor of a processor i at the level j of the treeType */
int CPLM_TreeDeterminComplement(int rank, int size, int level, CPLM_TreeType_t treeType, int *complem)
{
  int ierr        = 0;
  int complement  = 0;
  int level2      = 0;
  int levelsize   = 0;

  levelsize = size;

  switch (treeType) 
  {
    case FlatTree :
      if(rank != 0)
        complement = (rank == level ? 0 : -1);
      else
        complement = (size == 1 ? -1 : level);
      break;

    case BinaryTree :
      level2 = pow(2,level);

      if(level > log2(size) + 1)
      {
        printf("The level %d doesn't exist in bianry tree with size = %d \n", level, size);
        CPLM_ASSERT(level <= log2(size) + 1);
      }

      if(rank % level2 != 0)
        complement = -1;
      else if(rank % level2 == 0 && rank != level2)
      {
        int ranklevel = rank/level2;

        for(int j = 0; j < level; j++)
          levelsize = (levelsize % 2 == 0 ? levelsize/2 : (levelsize+1)/2);

        complement = (ranklevel % 2 == 0 ? level2 * (ranklevel + 1) : level2 * (ranklevel - 1));

        if(ranklevel + 1 == levelsize && levelsize % 2 == 1)
          complement = -1;
      }
      else if(rank == level2)
        complement = 0;
      break;

    case SebTree :
      if(level > log2(size) + 1)
      {
        printf("The level %d doesn't exist in bianry tree with size = %d \n", level, size);
        return -2;
      }

      for(int j = 0; j < level; j++)
        levelsize = (levelsize % 2 == 0 ? levelsize/2 : (levelsize+1)/2);

      if(rank >= levelsize)
        complement = -1;
      else
        complement = levelsize - 1 - rank;

      if(levelsize % 2 == 1 && rank == levelsize/2)
        complement = -1;
      break;
  }

  *complem = complement;

  return ierr;
}





