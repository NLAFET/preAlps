/*
* This file contains functions used to manipulate dvector
*
* Authors : Sebastien Cayrols
*         : Remi Lacroix
* Email   : sebastien.cayrols@[(gmail.com) | (inria.fr)]
*/
/**
 * \file mat_csr.c
 * \brief Structure to store a matrix into a CSR format
 * \author Sebastien Cayrols and Remi Lacroix
 * \version 0.2
 * \date 20 june 2013
 *
 * Structure which manipulate the CSR format
 *
 *  For any question, email :  sebastien.cayrols@[(gmail.com) | (inria.fr)]
 *  DO NOT DISTRIBUTE
 */

#ifdef MPIACTIVATE
  #include <mpi.h>
#endif

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>

#include <cpalamem_macro.h>
#include <mat_csr.h>
#include <MPIutils.h>
#include <QS.h>
#include <mat_load_mm.h>
#include <cpalamem_instrumentation.h>

/**
 * \fn void CPLM_MatCSRConvertTo0BasedIndexing(CPLM_Mat_CSR_t *m)
 * \brief Convert a matrix into C format index
 * \param *matCSR The matrix which has to be reformated
 */
void CPLM_MatCSRConvertTo0BasedIndexing(CPLM_Mat_CSR_t *m)
{
  if (m) {
    int i;
    for (i = 0; i <= m->info.m; i++) {
      m->rowPtr[i]--;
    }
    for (i = 0; i < m->info.lnnz; i++) {
      m->colInd[i]--;
    }
  }
}

/**
 * \fn void CPLM_MatCSRConvertTo1BasedIndexing(CPLM_Mat_CSR_t *m)
 * \brief Convert a matrix into matlab format index
 * \param *matCSR The matrix which has to be reformated
 */
void CPLM_MatCSRConvertTo1BasedIndexing(CPLM_Mat_CSR_t *m)
{
  if (m) {
    int i;
    for (i = 0; i <= m->info.m; i++) {
      m->rowPtr[i]++;
    }
    for (i = 0; i < m->info.lnnz; i++) {
      m->colInd[i]++;
    }
  }
}

/*=================================================================*/
/*The following part has been added by Sebastien Cayrols 18/06/2013*/
/*=================================================================*/

/**
 * \fn int CPLM_MatCSRCopy(CPLM_Mat_CSR_t *m1, CPLM_Mat_CSR_t *m2)
 * \brief Function which copy all the CSR matrix to a new CSR matrix
 * \param *m1     The original matrix which has to be copied
 * \param *m2     The copy matrix
 * \return        0 if copy has succeed
 */
int CPLM_MatCSRCopy(CPLM_Mat_CSR_t *m1, CPLM_Mat_CSR_t *m2){
CPLM_PUSH
CPLM_BEGIN_TIME

  int err=0;

  err = CPLM_MatCSRCopyStruct(m1,m2);

	memcpy(m2->val,m1->val,m2->info.lnnz*sizeof(double));

CPLM_END_TIME
CPLM_POP
	return err;

}

/**
 * \fn int CPLM_MatCSRCopyStruct(CPLM_Mat_CSR_t *m1, CPLM_Mat_CSR_t *m2)
 * \brief Function which copy the structure of the CSR matrix to a new CSR matrix
 * \param *m1     The original matrix which has to be copied
 * \param *m2     The copy matrix
 * \return        0 if copy has succeed
 */
int CPLM_MatCSRCopyStruct(CPLM_Mat_CSR_t *A_in, CPLM_Mat_CSR_t *B_out)
{
CPLM_PUSH
CPLM_BEGIN_TIME

	int ierr = 0;

  B_out->info = A_in->info;

  ierr = CPLM_MatCSRMalloc(B_out);CPLM_CHKERR(ierr);

  memcpy(B_out->rowPtr, A_in->rowPtr, (B_out->info.m+1) * sizeof(int));
  memcpy(B_out->colInd, A_in->colInd, B_out->info.lnnz  * sizeof(int));

CPLM_END_TIME
CPLM_POP
	return ierr;
}


/**
 * \fn void CPLM_MatCSRPrintInfo(CPLM_Mat_CSR_t *m)
 * \brief Method which prints the data structure
 * \param *info The data structure of a CSR matrix
 */
/*Function prints informations about a CPLM_Info_t matrix */
void CPLM_MatCSRPrintInfo(CPLM_Mat_CSR_t *m){
  CPLM_Info_t p = m->info;
	printf("Matrix %dx%d with %d nnz\tlocal data : %dx%d with %d lnnz %s",
					p.M,p.N,p.nnz,p.m,p.n,p.lnnz,
					(p.structure==SYMMETRIC) ? "Structure = Symmetric\n" : "Structure = Unsymmetric\n");
}

/**
 * \fn void print_MatrixCSR(CPLM_Mat_CSR_t *m)
 * \brief Method which prints a CSR matrix in the CSR format
 * \brief Note : this method is enable only if DEBUG is defined[TODO]
 * \param *matCSR The CSR matrix which has to be printed
 * \param print The boolean choice to print or not the values of the matrix
 */
/*Function prints a CPLM_Mat_CSR_t matrix */
void CPLM_MatCSRPrint(CPLM_Mat_CSR_t *m){

  if(m->val != NULL)
  {
	  printf("VALUE : [ ");
	  for(int i=0;i<m->info.lnnz;i++){
	  	printf("%2.*f\t",_PRECISION,m->val[i]);
	  }
	  printf("]\n");
  }

	printf("COLUMN INDICES : [ ");
	for(int i=0;i<m->info.lnnz;i++){
		printf("%2d\t",m->colInd[i]);
	}
	printf("]\n");

	printf("ROW POINTER : [ ");
	for(int i=0;i<m->info.m+1;i++){
		printf("%2d\t",m->rowPtr[i]);
	}
	printf("]\n");
}





/**
 * \fn void CPLM_MatCSRPrint2D(CPLM_Mat_CSR_t *m)
 * \brief Method which prints the CSR matrix into standard format
 * \param *matCSR The matrix which has to be printed
 */
/*Print original matrix */
void CPLM_MatCSRPrint2D(CPLM_Mat_CSR_t *m)
{
	int zero=0;
	if(m->val==NULL)
  {
		for(int i=0;i<m->info.m;i++){
			printf("[ ");
			for(int j=m->rowPtr[i], indCol=0; indCol < m->info.n ;indCol++){
				if(j<m->rowPtr[i+1] && indCol==m->colInd[j]){
					printf("X ");
					j++;
				}
				else
					printf(". ");
			}
			printf("]\n");
		}
	}
  else
  {
		for(int i=0;i<m->info.m;i++){
			printf("[ ");
			//for each case of the line
			for(int j=m->rowPtr[i], indCol=0; indCol < m->info.n ;indCol++){
				//if this case is in colInd
				if(j<m->rowPtr[i+1] && indCol==m->colInd[j]){
					printf("%2.*f\t",_PRECISION,m->val[j]);
					j++;
				}
				else
					printf("%7d\t",zero);
			}
			printf("]\n");
		}
  }
}





/**
 * \fn void CPLM_MatCSRPrint2D(CPLM_Mat_CSR_t *m)
 * \brief Method which prints the CSR matrix into standard format
 * \param *matCSR The matrix which has to be printed
 */
/*Print original matrix */
void CPLM_MatCSRPrintPartial2D(CPLM_Mat_CSR_t *m)
{
	int zero=0;
	if(m->val==NULL)
  {
		for(int i=0;i<m->info.m;i++){
			printf("[ ");
			for(int j=m->rowPtr[i], indCol=0; indCol < m->info.n ;indCol++){
				if(j<m->rowPtr[i+1] && indCol==m->colInd[j]){
					printf("X ");
					j++;
				}
				else
					printf(". ");
			}
			printf("]\n");
		}
	}
  else
  {
		for(int i = 0; i < m->info.m; i++)
    {
			printf("[ ");
			//for each case of the line
			for(int j = m->rowPtr[i], indCol = 0; indCol < m->info.n ;indCol++)
      {
				//if this case is in colInd
				if(j < m->rowPtr[i+1] && indCol == m->colInd[j])
        {
					printf("%2.*f\t",_PRECISION,m->val[j]);
					j++;
				}
				else
					printf("%7d\t",zero);

        //Jump if needed to the end of the line
        if(indCol == PRINT_PARTIAL_N)
        {
          indCol = CPLM_MAX(m->info.n - PRINT_PARTIAL_N - 1, indCol);
          printf("...");
        }
			}
			printf("]\n");
      if(i == PRINT_PARTIAL_M)
      {
        i = CPLM_MAX(m->info.m - PRINT_PARTIAL_M - 1, i);
        printf("...\n");
      }
		}
  }
}


/**
 * \fn int CPLM_MatCSRSave(CPLM_Mat_CSR_t *m, const char *filename)
 * \brief Method which saves a CSR matrix into a file
 * \Note This function saves the matrix into Matrix market format
 * \param *m          The CSR matrix which has to be saved
 * \param *filename   The name of the file
 */
/*Function saves a CPLM_Mat_CSR_t matrix in a file*/
int CPLM_MatCSRSave(CPLM_Mat_CSR_t *m, const char *filename){

	FILE *ofd;
	int err = 0;

	//WARNING : Always save in general structure
	const char *first_line = "%%MatrixMarket matrix coordinate real general\n";

	if((ofd = fopen(filename,"w"))==NULL){
		fprintf(stderr,"Error during fopen of %s\n",filename);
		return 1;
	}

	fputs(first_line,ofd);
	fprintf(ofd,"%d %d %d\n",m->info.m,m->info.n,m->info.lnnz);

	for(int line=0;line<m->info.m;line++)
	  for(int pos=m->rowPtr[line];pos<m->rowPtr[line+1];pos++)
	    fprintf(ofd,"%d %d %.16e\n",line+1,m->colInd[pos]+1,m->val[pos]);

	fclose(ofd);

	return err;

}

/**
 * \fn int CPLM_MatCSRDelDiag(CPLM_Mat_CSR_t *matCSR)
 * \brief Function which creates a CSR matrix with the same structure of the original CSR matrix and
 * deletes the diagonal values
 * \param *m1 The original CSR matrix
 * \param *m2 The CSR matrix created without diagonal values
 */
/*Function deletes diagonal element from a CPLM_Mat_CSR_t matrix*/
int CPLM_MatCSRDelDiag(CPLM_Mat_CSR_t *m1, CPLM_Mat_CSR_t *m2){
CPLM_PUSH
CPLM_BEGIN_TIME

	int del    = 0;
  int err       = 0;
	int lnAdd     = 0;
  int nAdd      = 0;

  err = CPLM_MatCSRInit(m2,&(m1->info));CPLM_CHKERR(err);

  m2->info.lnnz -= m1->info.m;//Assumption : the diagonal elements are all non zero
  m2->info.M    = m2->info.m;
  m2->info.N    = m2->info.n;
  m2->info.nnz  = m2->info.lnnz;

  err = CPLM_MatCSRMalloc(m2);CPLM_CHKERR(err);

	m2->rowPtr[0] = 0;

	for(int i=0;i<m1->info.m;i++){
		lnAdd   = 0;
		del  = 0;
		for(int j=m1->rowPtr[i];j<m1->rowPtr[i+1];j++){
			if(m1->colInd[j]==i){
				del  = 1;
				continue;
			}

			m2->colInd[nAdd]  = m1->colInd[j];
			m2->val[nAdd]     = m1->val[j];
			nAdd++;
			lnAdd++;
		}

		if(del==0){
			fprintf(stderr,"Error, no diagonal value on row %d\n",i);
			return 1;
		}

		m2->rowPtr[i+1] = m2->rowPtr[i]+lnAdd;
	}

  if (m2->info.lnnz!=nAdd){
			fprintf(stderr,"Error during diagonal elimination\t Malloc of %d elements not equal to %d values added\n",m2->info.nnz,nAdd);
			return 1;
  }
CPLM_END_TIME
CPLM_POP
	return err;
}


/**
 * \fn int CPLM_MatCSRSymStruct(CPLM_Mat_CSR_t *m1, CPLM_Mat_CSR_t *m2)
 * \brief Function symmetrizes the structure of a matrix
 * \param *m1   The original CSR matrix
 * \param *m2   The symmetric CSR matrix
 */
/*Function symmetrizes a CPLM_Mat_CSR_t matrix and delete its diagonal elements if wondered*/
int CPLM_MatCSRSymStruct(CPLM_Mat_CSR_t *m1, CPLM_Mat_CSR_t *m2){
CPLM_PUSH
CPLM_BEGIN_TIME

  int ierr = 0;

	if(m1->info.m != m1->info.n){
		fprintf(stderr,"This matrix is not square\n");
		exit(1);
	}

  ierr = CPLM_MatCSRInit(m2,&(m1->info));CPLM_CHKERR(ierr);
  m2->info.M=m2->info.m;
  m2->info.N=m2->info.n;

	m2->rowPtr = (int*) calloc((m1->info.m+1),sizeof(int));
  //m2->rowPtr[0]=0;[TODO change this calloc and the algo maybe ! if time to do that]

	//nb val added into original matrix
	int nbVal=0,valueAdded=0;
  for(int i=0;i<m1->info.m;i++){
	  for(int j=m1->rowPtr[i];j<m1->rowPtr[i+1];j++){
		  int tmp_col=m1->colInd[j];
		  //if not a diagonal element
		  if(tmp_col!=i){
			  valueAdded=0;
			  //For each nnz of the column
			  for(int k=m1->rowPtr[tmp_col];k<m1->rowPtr[tmp_col+1];k++)
				  if(m1->colInd[k]==i){
					  valueAdded=1;
					  break;
				  }
				  else if(m1->colInd[k]>i){
					  valueAdded=1;
					  m2->rowPtr[tmp_col+1]++;
					  nbVal++;
					  break;
				  }
			  if(valueAdded==0){
				  m2->rowPtr[tmp_col+1]++;
				  nbVal++;
			  }
		  }
	  }
  }


	m2->info.lnnz=m1->info.lnnz+nbVal-m1->info.m;
  m2->info.nnz=m2->info.lnnz;

  m2->colInd = (int*)malloc((m2->info.lnnz)*sizeof(int));

	int valueIgnored=0;
	//init by -1
	memset(m2->colInd,-1,m2->info.lnnz*sizeof(int));

	int sum=0;

	for(int i=0;i<m1->info.m;i++){
		//compute the real number of values for the row i
		sum+=m2->rowPtr[i+1]-1;
		m2->rowPtr[i+1]=m1->rowPtr[i+1]+sum;
	}
  for(int i=0;i<m1->info.m;i++){
	  //route the row i
	  for(int j=m1->rowPtr[i];j<m1->rowPtr[i+1];j++){
		  int tmp_col=m1->colInd[j];
		  //if value is not the diagonal
		  if(tmp_col!=i){
			  //copy values from original matrix
			  for(int ii=m2->rowPtr[i];ii<m2->rowPtr[i+1];ii++){
				  if(m2->colInd[ii]==-1){
					  m2->colInd[ii]=tmp_col;
					  break;
				  }
			  }
			  valueIgnored=0;
			  //looking for if i ( the row ) has to be added into tmp_col row
			  for(int k=m1->rowPtr[tmp_col];k<m1->rowPtr[tmp_col+1];k++){
				  //if exists so continue
				  if(i==m1->colInd[k]){
					  valueIgnored=1;
					  break;
				  }
				  else if(i<m1->colInd[k]){
					  break;
				  }
			  }
			  //if all values are less than the row index
			  if(valueIgnored==0){
				  valueAdded=0;
				  for(int ii=m2->rowPtr[tmp_col];ii<m2->rowPtr[tmp_col+1];ii++){
						  if(m2->colInd[ii]==-1){
							  valueAdded=1;
							  m2->colInd[ii]=i;
							  break;
						  }
					  }
			  }
		  }
	  }
  }

	for(int i=0;i<m2->info.m;i++){
		CPLM_quickSort(m2->colInd,m2->rowPtr[i],m2->rowPtr[i+1]-1);
	}
	m2->info.structure=SYMMETRIC;
	m2->val=NULL;

CPLM_END_TIME
CPLM_POP
	return ierr;

}


/**
 * \fn int CPLM_MatCSRUnsymStruct(CPLM_Mat_CSR_t *m1, CPLM_Mat_CSR_t *m2)
 * \brief Function which creates a CSR matrix and fills it from the original CSR matrix symmetrizing the structure
 * \param *m1 The input symmetric CSR matrix where the structure is for instancethe upper part
 * \param *m2 The output general CSR matrix
 */
/*Function symmetrizes a CPLM_Mat_CSR_t matrix*/
int CPLM_MatCSRUnsymStruct(CPLM_Mat_CSR_t *m1, CPLM_Mat_CSR_t *m2){
CPLM_PUSH
CPLM_BEGIN_TIME

  int err=0;

	if(m1->info.m != m1->info.n){
		fprintf(stderr,"matrix is not square\n");
		exit(1);
	}

  err = CPLM_MatCSRInit(m2,&(m1->info));CPLM_CHKERR(err);
  m2->info.M=m2->info.m;
  m2->info.N=m2->info.n;

	m2->rowPtr = (int*)calloc((m1->info.m+1),sizeof(int));

	int *ptr;
	ptr=(int*)calloc(m1->info.m,sizeof(int));

  //For each line
  for(int i=0;i<m1->info.m;i++){
    //For each column
	  for(int j=m1->rowPtr[i];j<m1->rowPtr[i+1];j++){
		  int tmp_col=m1->colInd[j];
		  if(tmp_col==i) continue;
	    ptr[tmp_col]++;
	  }
  }

  m2->info.lnnz=m2->info.nnz=m1->info.lnnz*2-m1->info.m;

  m2->colInd = (int*)malloc(m2->info.lnnz*sizeof(int));

  m2->val = (double*)malloc(m2->info.lnnz*sizeof(double));

	int offset=0;

	//compute the real number of values for the row i
	for(int i=0;i<m1->info.m;i++){
		m2->rowPtr[i+1]=m1->rowPtr[i+1]+ptr[i]+offset;
		offset+=ptr[i];
	}

  memset(ptr,0,m1->info.m*sizeof(int));

  for(int i=0;i<m1->info.m;i++){
	  //route the i'th row
	  for(int j=m1->rowPtr[i];j<m1->rowPtr[i+1];j++){
		  int tmp_col=m1->colInd[j];
		  if(tmp_col==i) continue;
		  m2->colInd[m2->rowPtr[tmp_col]+ptr[tmp_col]]=i;
		  m2->val[m2->rowPtr[tmp_col]+ptr[tmp_col]]=m1->val[j];

		  ptr[tmp_col]++;
	  }
	  memcpy(&m2->colInd[m2->rowPtr[i]+ptr[i]],&m1->colInd[m1->rowPtr[i]],(m1->rowPtr[i+1]-m1->rowPtr[i])*sizeof(int));
	  memcpy(&m2->val[m2->rowPtr[i]+ptr[i]],&m1->val[m1->rowPtr[i]],(m1->rowPtr[i+1]-m1->rowPtr[i])*sizeof(double));

	  ptr[i]+=(m1->rowPtr[i+1]-m1->rowPtr[i]);
  }

  free(ptr);

  for(int i=0;i<m2->info.m;i++){
		CPLM_quickSortWithValues(m2->colInd,m2->rowPtr[i],m2->rowPtr[i+1]-1,m2->val);
	}

CPLM_END_TIME
CPLM_POP
	return err;

}





/**
 * \fn int CPLM_MatCSRPermute(CPLM_Mat_CSR_t *m1,
 * CPLM_Mat_CSR_t *m2,
 * int *colPerm,
 * int *rowPerm,
 * Choice_permutation permute_values)
 * \brief Function creates a CSR matrix and fills in with the original
 *        CSR matrix which has been permuted
 * \param *m1               The original CSR matrix
 * \param *m2               The permuted matrix CSR matrix
 * \param *colPerm          The array of permutation where the row of the 
 *                          returned CSR matrix is equal to perm[i] where i 
 *                          is the i'th row of the original CSR matrix
 * Note : i -> perm[i]
 * \param *rowPerm          The array of invert permutation
 * \param permute_values    Indicate if values have to be permuted or ignored
 * \return                  0 if permutation succeed
 */
/*Function which permutes CPLM_Mat_CSR_t matrix with colPerm and rowPerm vector*/
int CPLM_MatCSRPermute(CPLM_Mat_CSR_t           *A_in,
                  CPLM_Mat_CSR_t           *B_out,
                  int                 *rowPerm,
                  int                 *colPerm,
                  Choice_permutation  permute_values)
{
CPLM_PUSH
CPLM_BEGIN_TIME

  int ierr  = 0;
	int lnval = 0;
  CPLM_IVector_t tmp_s     = CPLM_IVectorNULL();
  CPLM_IVector_t iColPerm  = CPLM_IVectorNULL();

  B_out->info = A_in->info;

	if(permute_values ==  PERMUTE)
  {
		ierr  = CPLM_MatCSRMalloc(B_out);CPLM_CHKERR(ierr);
  }
  else
  {
	  B_out->rowPtr = (int*)malloc((B_out->info.m+1)  * sizeof(int));
	  B_out->colInd = (int*)malloc(B_out->info.lnnz   * sizeof(int));
    CPLM_ASSERT(B_out->rowPtr != NULL);
    CPLM_ASSERT(B_out->colInd != NULL);
  }

  ierr = CPLM_IVectorCreateFromPtr(&tmp_s,A_in->info.n,colPerm);CPLM_CHKERR(ierr);
  ierr = CPLM_IVectorInvert(&tmp_s,&iColPerm);CPLM_CHKERR(ierr);

	B_out->rowPtr[0]=0;

  //Copy data where rows are permuted too
  for(int i = 0; i < B_out->info.m; i++)
  {
    lnval = A_in->rowPtr[ rowPerm[i] + 1] - A_in->rowPtr[ rowPerm[i] ];
    memcpy( B_out->colInd + B_out->rowPtr[i],
            A_in->colInd + A_in->rowPtr[rowPerm[i]],
            lnval * sizeof(int));
  	B_out->rowPtr[i+1] = B_out->rowPtr[i] + lnval;
  }

	if(permute_values == PERMUTE)
  {
  	for(int i = 0; i < B_out->info.m; i++)
    {
      lnval = A_in->rowPtr[ rowPerm[i] + 1] - A_in->rowPtr[ rowPerm[i] ];
      memcpy( B_out->val + B_out->rowPtr[i],
              A_in->val + A_in->rowPtr[rowPerm[i]],
              lnval * sizeof(double));
  	}
  }

  //Permute columns
  for(int i = 0; i < B_out->info.lnnz; i++)
  	B_out->colInd[i] = iColPerm.val[B_out->colInd[i]];

  //Sort columns
  if(permute_values == PERMUTE)
  {
	  for(int i = 0; i < B_out->info.m; i++)
	  	CPLM_quickSortWithValues(  B_out->colInd,
                            B_out->rowPtr[i],
                            B_out->rowPtr[i+1] - 1,
                            B_out->val);
  }
  else
  {
	  for(int i = 0; i < B_out->info.m;i++)
	  	CPLM_quickSort(  B_out->colInd,
                  B_out->rowPtr[i],
                  B_out->rowPtr[i+1] - 1);
  }

  CPLM_IVectorFree(&iColPerm);

CPLM_END_TIME
CPLM_POP
	return ierr;

}


/**
 * \fn int CPLM_MatCSRGetSub(CPLM_Mat_CSR_t *m1, CPLM_Mat_CSR_t *m2, int *interval, int num_parts)
 * \brief Function creates a CSR matrix without value which corresponds to a submatrix of the original CSR matrix and this submatrix is a part given by Metis_GraphPartKway
 * Note : this function does not need the matrix values
 * \param *m1         The original CSR matrix
 * \param *m2         The original CSR matrix
 * \param *interval   The array containing the begin and the end of each part of the CSR matrix
 * \param num_parts   The number of the part which will be returned
 * \return            0 if succeed
 */
/*function which returns a submatrice at CSR format from an original matrix (in CSR format too) and filtered by parts*/
/*num_parts corresponds to the number which selects rows from original matrix and interval allows to select the specific rows*/
int CPLM_MatCSRGetSub(CPLM_Mat_CSR_t *m1, CPLM_Mat_CSR_t *m2, int *interval, int num_parts){

  int err=0;

  err=CPLM_MatCSRInit(m2,&(m1->info));CPLM_CHKERR(err);

	m2->info.M    = m1->info.m;
  m2->info.m    = interval[num_parts+1]-interval[num_parts];
	m2->info.nnz  = m1->info.lnnz;
  m2->info.lnnz = m1->rowPtr[interval[num_parts+1]]-m1->rowPtr[interval[num_parts]];

  err=CPLM_MatCSRMalloc(m2);CPLM_CHKERR(err);

#ifdef DEBUG
	printf("Block n°%d nb_nnz = %d\tnb_vertices = %d\n",num_parts, m2->info.nnz, m2->info.M);
#endif

	int ind=0;
	int nbValues=0;
	//variable which adapts the values in rowPtr for local colInd
	int offset = m1->rowPtr[interval[num_parts]];
	//copy of arrays
	for(int i=interval[num_parts];i<interval[num_parts+1];i++){
		m2->rowPtr[ind++]=m1->rowPtr[i]-offset;
		for(int ii=m1->rowPtr[i];ii<m1->rowPtr[i+1];ii++){
        m2->val[nbValues]=m1->val[ii];
				m2->colInd[nbValues++]=m1->colInd[ii];
		}
	}

	//complet the last cell of the rowPtr array for the CSR format
	m2->rowPtr[ind]=m1->rowPtr[interval[num_parts+1]]-offset;

	return err;
}





/**
 * \fn
 * \brief Function creates a CSR matrix without value which corresponds to a submatrix of the original CSR matrix and this submatrix is a part given by Metis_GraphPartKway
 * Note : this function does not need the matrix values
 * \param *A_in         The original CSR matrix
 * \param *B_out        The original CSR matrix
 * \param *pos          The array containing the begin of each part of the CSR matrix
 * \param numBlock      The number of the part which will be returned
 * \return            0 if succeed
 */
/*function which returns a submatrice at CSR format from an original matrix (in CSR format too) and filtered by parts*/
/*num_parts corresponds to the number which selects rows from original matrix and interval allows to select the specific rows*/
int CPLM_MatCSRGetDiagBlock(CPLM_Mat_CSR_t *A_in, CPLM_Mat_CSR_t *B_out, CPLM_IVector_t *pos, CPLM_IVector_t *colPos, int structure)
{
CPLM_PUSH
CPLM_BEGIN_TIME

  int ierr      = 0;
  int lm        = 0;
  int lnnz      = 0;
	int offset    = 0;//variable which adapts the values in rowPtr for local colInd
  int numBlock  = 0;
  int nblock    = 0;
  CPLM_IVector_t diagPos = CPLM_IVectorNULL();

  MPI_Comm_rank(MPI_COMM_WORLD, &numBlock);
  MPI_Comm_size(MPI_COMM_WORLD, &nblock);

  if(A_in->info.m < pos->val[ pos->nval - 1])//i.e. rowLayout
  {

    CPLM_ASSERT(colPos->val != NULL);

    //Count how many lnnz there will be
    int sum         = 0;
    CPLM_IVector_t rowSize  = CPLM_IVectorNULL();

    ierr = CPLM_IVectorMalloc(&rowSize,A_in->info.m);CPLM_CHKERR(ierr);

    if(structure == SYMMETRIC)
    {
      ierr = CPLM_MatCSRGetDiagIndOfPanel(A_in,&diagPos,pos,colPos,numBlock);CPLM_CHKERR(ierr);
      for(int i = 0; i < A_in->info.m; i++)
      {
        rowSize.val[i]  = colPos->val[i*nblock+numBlock+1] - diagPos.val[i];
        sum            += rowSize.val[i];
      }
    }
    else
    {
      for(int i = 0; i < A_in->info.m; i++)
      {
        rowSize.val[i]  = colPos->val[i*nblock+numBlock+1] - colPos->val[i * nblock + numBlock];
        sum            += rowSize.val[i];
      }
    }
	  /*
    * ====================
    *    copy of arrays
    * =====================
    */
    int ind   = 0;
    int ptr   = 0;
    int nvAdd = 0;

    ierr = CPLM_MatCSRSetInfo(B_out,
                            A_in->info.m,
                            A_in->info.n,
                            A_in->info.lnnz,
                            A_in->info.m,
                            pos->val[numBlock+1]-pos->val[numBlock],
                            sum,
                            1);CPLM_CHKERR(ierr);

    ierr = CPLM_MatCSRMalloc(B_out);CPLM_CHKERR(ierr);

    B_out->rowPtr[0] = 0;
    if(structure == SYMMETRIC)
    {
      for(int i = 0; i < A_in->info.m; i++)
      {
        ptr   = diagPos.val[i];
        nvAdd = rowSize.val[i];

        memcpy(&(B_out->colInd[ind]),&(A_in->colInd[ptr]),nvAdd*sizeof(int));
        memcpy(&(B_out->val[ind])   ,&(A_in->val[ptr]),   nvAdd*sizeof(double));

        B_out->rowPtr[i+1]  =   B_out->rowPtr[i] + nvAdd;
        ind                 +=  nvAdd;
      }
    }
    else
    {
      for(int i = 0; i < A_in->info.m; i++)
      {
        ptr   = colPos->val[i * nblock + numBlock];
        nvAdd = rowSize.val[i];

        memcpy(&(B_out->colInd[ind]),&(A_in->colInd[ptr]),nvAdd*sizeof(int));
        memcpy(&(B_out->val[ind])   ,&(A_in->val[ptr]),   nvAdd*sizeof(double));

        B_out->rowPtr[i+1]  =   B_out->rowPtr[i] + nvAdd;
        ind                 +=  nvAdd;
      }
    }

    int offset = pos->val[numBlock];

    for(int i = 0; i < B_out->info.lnnz; i++)
      B_out->colInd[i] -= offset;

    CPLM_IVectorFree(&rowSize);
    CPLM_IVectorFree(&diagPos);

  }
  else if(colPos == NULL) //A_in is a colPanel
  {

    CPLM_Abort("Case of column panel never tested. So => ABORT");

    CPLM_IVector_t lrowSize  = CPLM_IVectorNULL();
    CPLM_IVector_t endRow    = CPLM_IVectorNULL();
    int nvAdd = 0;

    lm = pos->val[numBlock+1] - pos->val[numBlock];

    if(structure == SYMMETRIC)
    {

      ierr = CPLM_IVectorCreateFromPtr ( &endRow,
                                    lm,
                                    &(A_in->rowPtr[pos->val[numBlock+1]])
                                  );CPLM_CHKERR(ierr);
      ierr = CPLM_IVectorSum(&endRow,&diagPos,&lrowSize,1);CPLM_CHKERR(ierr);
      ierr = CPLM_IVectorReduce(&lrowSize,&lnnz);CPLM_CHKERR(ierr);
    }
    else
    {
	    offset  = A_in->rowPtr[pos->val[numBlock]];
      lnnz    = A_in->rowPtr[pos->val[numBlock+1]] - A_in->rowPtr[pos->val[numBlock]];
    }

    ierr = CPLM_MatCSRSetInfo(B_out,
                            A_in->info.m,
                            A_in->info.n,
                            A_in->info.lnnz,
                            lm,
                            A_in->info.n,
                            lnnz,
                            1);CPLM_CHKERR(ierr);

    ierr = CPLM_MatCSRMalloc(B_out);CPLM_CHKERR(ierr);
	  /*
    * ====================
    *    copy of arrays
    * =====================
    */
    if(structure == SYMMETRIC)
    {
      B_out->rowPtr[0]=0;
      for(int i = 0; i < lm; i++)
      {
        int begin = diagPos.val[pos->val[numBlock]+i];
	      //copy of arrays
        memcpy(&(B_out->colInd[nvAdd]), &(A_in->colInd[begin]),            lrowSize.val[i]*sizeof(int));
        memcpy(&(B_out->val[nvAdd]),    &(A_in->val[begin]),               lrowSize.val[i]*sizeof(double));
        B_out->rowPtr[i+1]  = lrowSize.val[i] + B_out->rowPtr[i];
        nvAdd += lrowSize.val[i];
      }
    }
    else
    {
	    //copy of arrays
      memcpy(B_out->colInd, &(A_in->colInd[offset]),            B_out->info.lnnz*sizeof(int));
      memcpy(B_out->val,    &(A_in->val[offset]),               B_out->info.lnnz*sizeof(double));
      memcpy(B_out->rowPtr, &(A_in->rowPtr[pos->val[numBlock]]),  (B_out->info.m+1)*sizeof(int));

      for(int i = 0; i < B_out->info.m + 1; i++)
	      B_out->rowPtr[i]  -=  offset;
    }
  }
  else//i.e. not a panel
  {
    CPLM_Abort("The non-panel shape of A is not implemented yet");
  }
CPLM_END_TIME
CPLM_POP
	return ierr;
}





/**
 * \fn int CPLM_MatCSRGetRowPanel(CPLM_Mat_CSR_t *A_in, CPLM_Mat_CSR_t *B_out, CPLM_IVector_t *pos, int numBlock)
 * \brief Function creates a CSR matrix without value which corresponds to a submatrix of the original CSR matrix and this submatrix is a part given by Metis_GraphPartKway
 * Note : this function does not need the matrix values
 * \param *A_in         The original CSR matrix
 * \param *B_out        The original CSR matrix
 * \param *pos          The array containing the begin of each part of the CSR matrix
 * \param numBlock      The number of the part which will be returned
 * \return            0 if succeed
 */
/*function which returns a submatrice at CSR format from an original matrix (in CSR format too) and filtered by parts*/
/*num_parts corresponds to the number which selects rows from original matrix and interval allows to select the specific rows*/
int CPLM_MatCSRGetRowPanel(CPLM_Mat_CSR_t *A_in, CPLM_Mat_CSR_t *B_out, CPLM_IVector_t *pos, int numBlock)
{

  int ierr    = 0;
  int lm      = 0;
  int lnnz    = 0;
	//variable which adapts the values in rowPtr for local colInd
	int offset  = 0;

  CPLM_ASSERT(numBlock < pos->nval);
  CPLM_ASSERT(pos->val[numBlock+1] < A_in->info.m+1);

  lm      = pos->val[numBlock+1]-pos->val[numBlock];
  lnnz    = A_in->rowPtr[pos->val[numBlock+1]]-A_in->rowPtr[pos->val[numBlock]];
	offset  = A_in->rowPtr[pos->val[numBlock]];

  if(B_out->val == NULL || (lm > B_out->info.m || lnnz > B_out->info.lnnz) )
  {

    B_out->info = A_in->info;

	  B_out->info.M    = A_in->info.m;
	  B_out->info.nnz  = A_in->info.lnnz;
    B_out->info.m    = lm;
    B_out->info.lnnz = lnnz;

    if(B_out->val == NULL)
    {
      ierr  = CPLM_MatCSRMalloc(B_out);CPLM_CHKERR(ierr);
    }
    else
    {
      ierr  = CPLM_MatCSRRealloc(B_out);CPLM_CHKERR(ierr);
    }
  }
  //Since it could be a work allocated before with a bigger size, we need to set the new real number of nnz in the row panel.
  //It involves an extra memory size if lnnz is lower than the previous one.
  //For instance, if lnnz = [ 12, 11, 11], at first, lnnz = 12 and after the memory size allocated is still 12 but only 11 values are in.
  B_out->info.lnnz  = lnnz;
  B_out->info.m     = lm;

	CPLM_debug("Block n°%d nb_nnz = %d\tnb_vertices = %d\n",numBlock, B_out->info.lnnz, B_out->info.m);

  if(lnnz > 0)
  {
    CPLM_ASSERT(offset < A_in->info.lnnz);
    CPLM_ASSERT((offset + B_out->info.lnnz - 1) < A_in->info.lnnz);

    //copy of arrays
    memcpy(B_out->colInd, &(A_in->colInd[offset]),            B_out->info.lnnz*sizeof(int));
    memcpy(B_out->val,    &(A_in->val[offset]),               B_out->info.lnnz*sizeof(double));
    memcpy(B_out->rowPtr, &(A_in->rowPtr[pos->val[numBlock]]),  (B_out->info.m+1)*sizeof(int));

    for(int i = 0; i < B_out->info.m + 1; i++)
    {
      B_out->rowPtr[i]  -=  offset;
    }

  }
  else
  {
    memset(B_out->rowPtr, 0, (B_out->info.m + 1) * sizeof(int));
  }

	return ierr;
}





int CPLM_MatCSRGetColPanel(CPLM_Mat_CSR_t *A_in, CPLM_Mat_CSR_t *B_out, CPLM_IVector_t *pos, CPLM_IVector_t *colPos, int numBlock)
{
CPLM_PUSH
CPLM_BEGIN_TIME
  int ierr    = 0;
  int nblock  = pos->nval - 1;

  //If non-allocated memory or number of columns are greater than previous call
  if(B_out->val == NULL || B_out->info.n < (pos->val[numBlock+1]-pos->val[numBlock]) )
  {
    B_out->info      = A_in->info;
    B_out->info.M    = A_in->info.m;
    B_out->info.N    = A_in->info.n;
    B_out->info.n    = pos->val[numBlock+1]-pos->val[numBlock];
	  B_out->info.nnz  = A_in->info.lnnz;
    B_out->info.lnnz = 0;
  }

  //Count how many lnnz there will be
  int sum         = 0;
  CPLM_IVector_t rowSize  = CPLM_IVectorNULL();

  ierr = CPLM_IVectorMalloc(&rowSize,A_in->info.m);CPLM_CHKERR(ierr);
  for(int i=0;i<A_in->info.m;i++)
  {
    rowSize.val[i]  = colPos->val[i*nblock+numBlock+1] - colPos->val[i*nblock+numBlock];
    sum           += rowSize.val[i];
  }

  if(sum > B_out->info.lnnz)
  {
      B_out->info.lnnz = sum;

      if(B_out->val == NULL)
      {
        ierr = CPLM_MatCSRMalloc(B_out);CPLM_CHKERR(ierr);
      }
      else
      {
        ierr = CPLM_MatCSRRealloc(B_out);CPLM_CHKERR(ierr);
      }
  }
	
  /*
  * ====================
  *    copy of arrays
  * =====================
  */
  int ind = 0;
  B_out->rowPtr[0] = 0;
  for(int i=0;i<A_in->info.m;i++){
    int ptr   = colPos->val[i*nblock+numBlock];
    int nvAdd = rowSize.val[i];

    memcpy(&(B_out->colInd[ind]),&(A_in->colInd[ptr]),nvAdd*sizeof(int));
    memcpy(&(B_out->val[ind])   ,&(A_in->val[ptr]),   nvAdd*sizeof(double));

    B_out->rowPtr[i+1]  =   B_out->rowPtr[i]+nvAdd;
    ind                 +=  nvAdd;
  }

  int offset = pos->val[numBlock];

  for(int i=0;i<B_out->info.lnnz;i++)
    B_out->colInd[i]-=offset;

  CPLM_IVectorFree(&rowSize);
CPLM_END_TIME
CPLM_POP
	return ierr;
}





int CPLM_MatCSRGetSubBlock ( CPLM_Mat_CSR_t *A_in,
                        CPLM_Mat_CSR_t *B_out,
                        CPLM_IVector_t *posR,
                        CPLM_IVector_t *posC,
                        int       numRBlock,
                        int       numCBlock,
                        int       **work,
                        size_t    *workSize)
{
CPLM_PUSH
CPLM_BEGIN_TIME
  int ierr    = 0;
  int nblockR = posR->nval - 1;
  int nblockC = posC->nval - 1;
  int sum     = 0;
  int fl      = 0;  //First line of the block
  int flnb    = 0;  //First line of the next block
  int nrow    = 0;
  int fc      = 0;  //First col of the block
  int fcnb    = 0;  //First col of the next block
  int ncol    = 0;
  int ind     = 0;  //
  int ptr     = 0;  //Position of the first column of the block
  int ptrC    = 0;  //Pointer to the first column of the block
  int lnvAdd  = 0;  //Number of values on the current line to add
  int lwork   = 0;  //Computed ideal size of the work
  int ncolPos = 0;  //Size of colPos
  int offset  = 0;  //Offset applied to the colInd array to shift the column 
                    // values such that the first column of the block in A 
                    // is numbered as 0 in B
  CPLM_IVector_t rowSize_s = CPLM_IVectorNULL();
  CPLM_IVector_t colPos_s  = CPLM_IVectorNULL();

  CPLM_ASSERT(A_in       != NULL);
  CPLM_ASSERT(B_out      != NULL);
  CPLM_ASSERT(A_in->val  != NULL);
  CPLM_ASSERT(posR       != NULL);
  CPLM_ASSERT(posC       != NULL);
  CPLM_ASSERT(work       != NULL);

  fl    = posR->val[numRBlock];
  flnb  = posR->val[numRBlock + 1];
  nrow  = flnb - fl;

  fc    = posC->val[numCBlock];
  fcnb  = posC->val[numCBlock + 1];
  ncol  = fcnb - fc;

  //If non-allocated memory or number of columns are greater than previous call
  if(B_out->val == NULL || B_out->info.n < nrow )
  {
    B_out->info      = A_in->info;
    B_out->info.M    = A_in->info.m;
    B_out->info.N    = A_in->info.n;
    B_out->info.m    = nrow;
    B_out->info.n    = ncol;
	  B_out->info.nnz  = A_in->info.lnnz;
    B_out->info.lnnz = 0;
  }

  ncolPos = nrow * nblockC + 1;
  lwork   = nrow + ncolPos;

  if (*work == NULL)
  {
    *workSize = (size_t)lwork;
    *work     = (int*) malloc(*workSize * sizeof(int));
    CPLM_ASSERT(*work != NULL);
  }
  else if(*workSize < lwork)
  {
    *workSize = (size_t)lwork;
    *work     = (int*) realloc(*work, *workSize * sizeof(int));
    CPLM_ASSERT(*work != NULL);
  }


  ierr = CPLM_IVectorCreateFromPtr(&rowSize_s, nrow, *work);CPLM_CHKERR(ierr);
  ierr = CPLM_IVectorCreateFromPtr(&colPos_s,
      ncolPos,
      rowSize_s.val + rowSize_s.nval);CPLM_CHKERR(ierr);



  ierr = CPLM_MatCSRGetPartialColBlockPos(A_in,
      posR,
      numRBlock,
      posC,
      &colPos_s);CPLM_CHKERR(ierr);
//CPLM_IVectorPrintf("Partial colPos", &colPos_s);


  //Count how many lnnz there will be
  for(int i = 0; i < nrow; i++)
  {
    ptr = i * nblockC + numCBlock;

    rowSize_s.val[i]  = colPos_s.val[ptr + 1] - colPos_s.val[ptr];
  //CPLM_debug("%d elements in row %d\n", rowSize_s.val[i], i);
    sum               += rowSize_s.val[i];
  }

  if(!sum)
  {
    return ierr;
  }
//CPLM_debug("sum %d\n", sum);

  if(sum > B_out->info.lnnz)
  {
      B_out->info.lnnz = sum;

      if(B_out->val == NULL)
      {
        ierr = CPLM_MatCSRMalloc(B_out);CPLM_CHKERR(ierr);
      }
      else
      {
        ierr = CPLM_MatCSRRealloc(B_out);CPLM_CHKERR(ierr);
      }
  }
  else
  {
    //Here we can loose some space and imply a realloc elsewhere
    B_out->info.lnnz = sum;
  }
	
  /*
  * ====================
  *    copy of arrays
  * =====================
  */
  B_out->rowPtr[0] = 0;
  for(int i = 0; i < nrow; i++)
  {
    ptrC   = colPos_s.val[i * nblockC + numCBlock];
    lnvAdd = rowSize_s.val[i];

    memcpy(B_out->colInd  + ind,  A_in->colInd + ptrC, lnvAdd * sizeof(int));
    memcpy(B_out->val + ind,      A_in->val + ptrC,    lnvAdd * sizeof(double));

    B_out->rowPtr[i + 1]  =   B_out->rowPtr[i] + lnvAdd;
    ind                   +=  lnvAdd;
  }

  offset = posC->val[numCBlock];
  for(int i = 0; i < B_out->info.lnnz; i++)
  {
    B_out->colInd[i] -= offset;
  }


CPLM_END_TIME
CPLM_POP
	return ierr;
}





int CPLM_MatCSRGetSubMatrix( CPLM_Mat_CSR_t *A_in,
                        CPLM_Mat_CSR_t *B_out,
                        CPLM_IVector_t *pos,
                        CPLM_IVector_t *colPos,
                        int       numRBlock,
                        int       numCBlock,
                        CPLM_IVector_t *work)
{
CPLM_PUSH
CPLM_BEGIN_TIME
  int ierr    = 0;
  int nblock  = pos->nval - 1;
  int sum     = 0;
  int fl      = 0;  //First line of the block
  int flnb    = 0;  //First line of the next block
  int nrow    = 0;
  int ind     = 0;  //
  int ptr     = 0;  //Position of the first column of the block
  int ptrC    = 0;  //Pointer to the first column of the block
  int lnvAdd  = 0;  //Number of values on the current line to add
  int offset  = 0;  //Offset applied to the colInd array to shift the column 
                    // values such that the first column of the block in A 
                    // is numbered as 0 in B

  CPLM_ASSERT(A_in       != NULL);
  CPLM_ASSERT(B_out      != NULL);
  CPLM_ASSERT(A_in->val  != NULL);
  CPLM_ASSERT(pos        != NULL);
  CPLM_ASSERT(colPos     != NULL);
  CPLM_ASSERT(work       != NULL);

  fl    = pos->val[numRBlock];
  flnb  = pos->val[numRBlock + 1];
//CPLM_debug("From row %d to %d\n", fl, flnb);
//CPLM_IVectorPrintf("pos", pos);
  nrow  = flnb - fl;

  //If non-allocated memory or number of columns are greater than previous call
  if(B_out->val == NULL || B_out->info.n < nrow )
  {
    B_out->info      = A_in->info;
    B_out->info.M    = A_in->info.m;
    B_out->info.N    = A_in->info.n;
    B_out->info.m    = nrow;
    B_out->info.n    = pos->val[numCBlock + 1] - pos->val[numCBlock];
	  B_out->info.nnz  = A_in->info.lnnz;
    B_out->info.lnnz = 0;
  }

//CPLM_MatCSRPrintfInfo("B_out", B_out);

  if (work->val == NULL)
  {
    ierr = CPLM_IVectorMalloc(work, nrow);CPLM_CHKERR(ierr);
  }
  else if(work->nval < nrow)
  {
    ierr = CPLM_IVectorRealloc(work, nrow);CPLM_CHKERR(ierr);
  }

//CPLM_IVectorPrintf("ColPos",colPos);
//CPLM_MatCSRPrintf("A", A_in);

  //Count how many lnnz there will be
  for(int i = fl; i < flnb; i++)
  {
    ptr = i * nblock + numCBlock;

    work->val[i - fl]   = colPos->val[ptr + 1] - colPos->val[ptr];
  //CPLM_debug("(%d)%d - (%d)%d = %d elements in row %d\n", ptr + 1, colPos->val[ptr + 1], ptr, colPos->val[ptr], work->val[i - fl], i);
    sum           += work->val[i - fl];
  }

  if(!sum)
  {
    return ierr;
  }
//CPLM_debug("sum %d\n", sum);

  if(sum > B_out->info.lnnz)
  {
      B_out->info.lnnz = sum;

      if(B_out->val == NULL)
      {
        ierr = CPLM_MatCSRMalloc(B_out);CPLM_CHKERR(ierr);
      }
      else
      {
        ierr = CPLM_MatCSRRealloc(B_out);CPLM_CHKERR(ierr);
      }
  }
  else
  {
    //Here we can loose some space and imply a realloc elsewhere
    B_out->info.lnnz = sum;
  }
	
  /*
  * ====================
  *    copy of arrays
  * =====================
  */
  B_out->rowPtr[0] = 0;
  for(int i = fl; i < flnb; i++)
  {
    ptrC   = colPos->val[i * nblock + numCBlock];
    lnvAdd = work->val[i - fl];
  //CPLM_debug("will copy %d values from %d to %d\n", lnvAdd, ptrC, ind);

    memcpy(B_out->colInd  + ind,  A_in->colInd + ptrC, lnvAdd * sizeof(int));
    memcpy(B_out->val + ind,      A_in->val + ptrC,    lnvAdd * sizeof(double));

    B_out->rowPtr[i - fl + 1]  =   B_out->rowPtr[i - fl] + lnvAdd;
    ind                   +=  lnvAdd;
  }

  offset = pos->val[numCBlock];
  for(int i = 0; i < B_out->info.lnnz; i++)
  {
    B_out->colInd[i] -= offset;
  }
//CPLM_MatCSRPrintf("B_out", B_out);

CPLM_END_TIME
CPLM_POP
	return ierr;
}





//This function extracts at least one column panel but also more than one
//TODO rebuild colPos
//numBlock is a list of index blocks
int CPLM_MatCSRGetColPanels(CPLM_Mat_CSR_t *m1, CPLM_Mat_CSR_t *m2, CPLM_IVector_t *pos, CPLM_IVector_t *colPos, CPLM_IVector_t *numBlock){

  int ierr=0;
  int nblock = pos->nval - 1;

  ierr=CPLM_MatCSRInit(m2,&(m1->info));CPLM_CHKERR(ierr);

	m2->info.M    = m1->info.M;
  m2->info.n    = 0;
  //Compute number of columns
  for(int i=0;i<numBlock->nval;i++)
    m2->info.n    += pos->val[numBlock->val[i]+1]-pos->val[numBlock->val[i]];
	m2->info.nnz  = m1->info.lnnz;

  int sum=0;
  //Contain number of nnz for each block in each line
  CPLM_IVector_t rowSize;
  ierr = CPLM_IVectorMalloc(&rowSize,m1->info.m*numBlock->nval);CPLM_CHKERR(ierr);

  for(int i=0;i<m1->info.m;i++){
    for(int j=0;j<numBlock->nval;j++){
      rowSize.val[i*numBlock->nval+j]=colPos->val[i*nblock+numBlock->val[j]+1]-colPos->val[i*nblock+numBlock->val[j]];
      sum+=rowSize.val[i*numBlock->nval+j];
    }
  }

  m2->info.lnnz = sum;
  ierr=CPLM_MatCSRMalloc(m2);CPLM_CHKERR(ierr);

	//copy of arrays
  int ind=0;
  m2->rowPtr[0]=0;
  for(int i=0;i<m1->info.m;i++){
    for(int j=0;j<numBlock->nval;j++){
      int ptr   = colPos->val[i*nblock+numBlock->val[j]];
      int nvAdd = rowSize.val[i*numBlock->nval+j];

      memcpy(&(m2->colInd[ind]),&(m1->colInd[ptr]),nvAdd*sizeof(int));
      int offset = pos->val[numBlock->val[j]];
      for(int k=0;k<nvAdd;k++)
        m2->colInd[ind+k]-=offset;

      memcpy(&(m2->val[ind]),&(m1->val[ptr]),nvAdd*sizeof(double));
      ind+=nvAdd;
    }
    m2->rowPtr[i+1]=ind;
  }

#ifdef DEBUG
  CPLM_MatCSRPrintf("From\n",m1);
  printf("extraction of panel blocks\n");
  CPLM_IVectorPrintf("numBlock index",numBlock);
  printf("gives\n");
  CPLM_MatCSRPrintInfo(m2);
  CPLM_MatCSRPrint(m2);
#endif
  CPLM_IVectorFree(&rowSize);
	return ierr;
}


/**
 * \fn int CPLM_MatCSRGetSubFromVector(CPLM_Mat_CSR_t *m1, CPLM_Mat_CSR_t *m2, CPLM_IVector_t *v)
 * \brief Function creates a CSR matrix without value which corresponds to a submatrix of the original CSR matrix filtered by a CPLM_IVector_t of selection
 * Note : this function does not need the matrix values
 * \param *m1     The original CSR matrix
 * \param *m2     The CSR matrix with selected rows/colums but without value
 * \param *v      The CPLM_IVector_t of selection
 * \return        0 if succeed
 */
int CPLM_MatCSRGetSubFromVector(CPLM_Mat_CSR_t *m1, CPLM_Mat_CSR_t *m2, CPLM_IVector_t *v){
CPLM_PUSH
CPLM_BEGIN_TIME

	int err=0;
	int sum=0;

	CPLM_quickSort(v->val,0,v->nval-1);

	err=CPLM_MatCSRInit(m2,&(m1->info));
	m2->info.structure=UNSYMMETRIC;

	for(int i=0;i<v->nval;i++)
		sum+=m1->rowPtr[v->val[i]+1]-m1->rowPtr[v->val[i]];

	m2->info.nnz=m2->info.lnnz=sum;

	//allocation of final arrays with right size
	m2->rowPtr = (int*)malloc((m2->info.m+1) * sizeof(int));
  m2->colInd = (int*)malloc(m2->info.lnnz * sizeof(int));

	int nbValues=0;
	//represents the number of nnz in a row
	int nbVal=0;
	int cpt=0,found=0;
	int begin=0;

	m2->rowPtr[0]=0;
	//copy of arrays
	for(int i=0;i<v->nval;i++){
		nbVal=0;
		begin=0;
		for(int ii=m1->rowPtr[v->val[i]];ii<m1->rowPtr[v->val[i]+1];ii++){
			cpt=begin;
			found=0;
			while(cpt<v->nval && found!=1){
				if(m1->colInd[ii]>v->val[cpt]){
					cpt++;
					continue;
				}
				else if(m1->colInd[ii]==v->val[cpt]){
					m2->colInd[nbValues]=cpt;
					nbValues++;
					nbVal++;
					found=1;
					begin=cpt;
				}
				else
					break;
			}
		}
		m2->rowPtr[i+1]=m2->rowPtr[i]+nbVal;
	}

	m2->info.nnz=m2->info.lnnz=nbValues;

#ifdef DEBUG
	printf("SubBlock composed of nb_nnz = %3d\tnb_vertices = %d\n", m2->info.nnz, m2->info.M);
#endif
	int *save_ptr;
	save_ptr=(int*)realloc(m2->colInd,m2->info.lnnz*sizeof(int));

	m2->colInd=save_ptr;

	m2->val=NULL;
CPLM_END_TIME
CPLM_POP
	return err;
}


/**
 * \fn int CPLM_MatCSRGetRectFromInt(CPLM_Mat_CSR_t *m1, CPLM_Mat_CSR_t *m2, int begin, int end)
 * \brief Function creates a CSR matrix with values which corresponds to a submatrix of the original CSR matrix filtered by a CPLM_IVector_t of selection but only on rows
 * \param *m1     The original CSR matrix
 * \param *m2     The CSR submatrix corresponding only to the selecting CPLM_IVector_t ( but not square ! )
 * \param begin   The first row in matCSR
 * \param end     The last row +1 in matCSR
 * \return        0 if succeed
 */
int CPLM_MatCSRGetRectFromInt(CPLM_Mat_CSR_t *m1, CPLM_Mat_CSR_t *m2, int begin, int end){
CPLM_PUSH
CPLM_BEGIN_TIME

  int err=0;

  err=CPLM_MatCSRInit(m2,&(m1->info));CPLM_CHKERR(err);
  //TODO change size !!
  m2->info.m=end-begin;
	m2->info.nnz=m2->info.lnnz=m1->rowPtr[end]-m1->rowPtr[begin];

  err=CPLM_MatCSRMalloc(m2);CPLM_CHKERR(err);

	int nbValues=0;
	//represents the number of nnz in a row
	int nbVal=0;

	m2->rowPtr[0]=0;
	//copy of arrays
	for(int i=begin;i<end;i++){
		nbVal=m1->rowPtr[i+1] - m1->rowPtr[i];

		memcpy(&(m2->colInd[nbValues]),&(m1->colInd[m1->rowPtr[i]]),nbVal*sizeof(int));
		memcpy(&(m2->val[nbValues]),&(m1->val[m1->rowPtr[i]]),nbVal*sizeof(double));

		m2->rowPtr[i+1-begin]=m2->rowPtr[i-begin]+nbVal;

		nbValues+=nbVal;
	}

CPLM_END_TIME
CPLM_POP
	return err;
}


/**
 * \fn int CPLM_MatCSRGetSubFromInterval(CPLM_Mat_CSR_t *m1, CPLM_Mat_CSR_t *m2, int begin, int end)
 * \brief Function creates a CSR matrix with values which corresponds to a submatrix of the original CSR matrix filtered by a CPLM_IVector_t of selection but only on rows
 * \param *m1     The original CSR matrix
 * \param *m2     The CSR submatrix corresponding to thi interval
 * \param begin   The first row
 * \param end     The last row
 * \return        0 if succeed
 */
int CPLM_MatCSRGetSubFromInterval(CPLM_Mat_CSR_t *m1, CPLM_Mat_CSR_t *m2, int begin, int end){
CPLM_PUSH
CPLM_BEGIN_TIME

  int err=0, sum=0;
  int size=end-begin;

  err = CPLM_MatCSRInit(m2,&(m1->info));CPLM_CHKERR(err);

	sum = m1->rowPtr[end+1]-m1->rowPtr[begin];

	m2->info.nnz=m2->info.lnnz=sum;
	m2->info.M=m2->info.m=size;

  err=CPLM_MatCSRMalloc(m2);CPLM_CHKERR(err);

	int nVal=0;
	//represents the number of nnz in a row
	int lnVal=0;

	m2->rowPtr[0]=0;
	//copy of arrays
	for(int j=0,i=begin;i<end;i++){
		lnVal=m1->rowPtr[i+1] - m1->rowPtr[i];

		memcpy(&(m2->colInd[nVal]), &(m1->colInd[m1->rowPtr[i]]), lnVal*sizeof(int));
		memcpy(&(m2->val[nVal]),    &(m1->val[m1->rowPtr[i]]),    lnVal*sizeof(double));

		m2->rowPtr[j+1]=m2->rowPtr[j]+lnVal;

		j++;
		nVal+=lnVal;
	}

CPLM_END_TIME
CPLM_POP
	return err;
}

/**
 * \fn int CPLM_MatCSRGetRecFromVector(CPLM_Mat_CSR_t *m1, CPLM_Mat_CSR_t *m2, CPLM_IVector_t *v)
 * \brief Function creates a CSR matrix with values which corresponds to a submatrix of the original CSR matrix filtered by a CPLM_IVector_t of selection but only on rows
 * \param *m1     The original CSR matrix
 * \param *m2     The original CSR matrix
 * \param *v      The CPLM_IVector_t of selection for rows which is the global CPLM_IVector_t is m1 is a submatrix
 * \return        0 if succeed
 */
int MatCSRGetRecFromGlobalVector(CPLM_Mat_CSR_t *m1, CPLM_Mat_CSR_t *m2, CPLM_IVector_t *v){
CPLM_PUSH
CPLM_BEGIN_TIME

#ifdef DEBUG
  CPLM_IVectorPrintf("row filter", v);
#endif

  int err=0;
	int sum=0;

  CPLM_quickSort(v->val,0,v->nval-1);

	err=CPLM_MatCSRInit(m2,&(m1->info));CPLM_CHKERR(err);
	m2->info.structure=UNSYMMETRIC;
	m2->info.M=m2->info.m=v->nval;

	for(int i=0;i<v->nval;i++)
		sum+=m1->rowPtr[v->val[i]+1]-m1->rowPtr[v->val[i]];

	m2->info.lnnz=m2->info.nnz=sum;

  err=CPLM_MatCSRMalloc(m2);CPLM_CHKERR(err);

	int nbValues=0;
	//represents the number of nnz in a row
	int nbVal=0;

	m2->rowPtr[0]=0;
	//copy of arrays
	for(int i=0;i<v->nval;i++){

		nbVal=m1->rowPtr[v->val[i]+1] - m1->rowPtr[v->val[i]];

		memcpy(&(m2->colInd[nbValues]),&(m1->colInd[m1->rowPtr[v->val[i]]]),nbVal*sizeof(int));
		memcpy(&(m2->val[nbValues]),&(m1->val[m1->rowPtr[v->val[i]]]),nbVal*sizeof(double));

		m2->rowPtr[i+1]=m2->rowPtr[i]+nbVal;

		nbValues+=nbVal;
	}

CPLM_END_TIME
CPLM_POP
	return err;
}






/**
 * \fn int CPLM_MatCSRGetRecFromVector(CPLM_Mat_CSR_t *m1, CPLM_Mat_CSR_t *m2, CPLM_IVector_t *v)
 * \brief Function creates a CSR matrix with values which corresponds to a submatrix of the original CSR matrix filtered by a CPLM_IVector_t of selection but only on rows
 * \param *m1     The original CSR matrix
 * \param *m2     The original CSR matrix
 * \param *v      The CPLM_IVector_t of selection for rows which is local to m1
 * \return        0 if succeed
 */
int CPLM_MatCSRGetRecFromVector(CPLM_Mat_CSR_t *m1, CPLM_Mat_CSR_t *m2, CPLM_IVector_t *v){
CPLM_PUSH
CPLM_BEGIN_TIME

#ifdef DEBUG
  CPLM_IVectorPrintf("row filter", v);
#endif

  int err=0;
	int sum=0;

  CPLM_quickSort(v->val,0,v->nval-1);

	err=CPLM_MatCSRInit(m2,&(m1->info));CPLM_CHKERR(err);
	m2->info.structure=UNSYMMETRIC;
	m2->info.M=m2->info.m=v->nval;

	for(int i=0;i<v->nval;i++)
		sum+=m1->rowPtr[v->val[i]+1]-m1->rowPtr[v->val[i]];

	m2->info.lnnz=m2->info.nnz=sum;

  err=CPLM_MatCSRMalloc(m2);CPLM_CHKERR(err);

	int nbValues=0;
	//represents the number of nnz in a row
	int nbVal=0;

	m2->rowPtr[0]=0;
	//copy of arrays
	for(int i=0;i<v->nval;i++){

		nbVal=m1->rowPtr[v->val[i]+1] - m1->rowPtr[v->val[i]];

		memcpy(&(m2->colInd[nbValues]),&(m1->colInd[m1->rowPtr[v->val[i]]]),nbVal*sizeof(int));
		memcpy(&(m2->val[nbValues]),&(m1->val[m1->rowPtr[v->val[i]]]),nbVal*sizeof(double));

		m2->rowPtr[i+1]=m2->rowPtr[i]+nbVal;

		nbValues+=nbVal;
	}

CPLM_END_TIME
CPLM_POP
	return err;
}


/**
 * \fn int CPLM_MatCSRGetSqrtFromVector(CPLM_Mat_CSR_t *m1, CPLM_Mat_CSR_t *m2, CPLM_IVector_t *v)
 * \brief Function creates a CSR matrix with values which corresponds to a submatrix of the original CSR matrix filtered by a CPLM_IVector_t of selection but only on column to get a square matrix
 * \param *m1     The original CSR matrix
 * \param *m2     The CSR submatrix corresponding only to the selecting vector
 * \param *v      The CPLM_IVector_t of selection
 * \return        0 if succeed
 */
//function which returns a square submatrice at CSR format from a rectangular matrix (in CSR format too) and filtered by parts
int CPLM_MatCSRGetSqrtFromVector(CPLM_Mat_CSR_t *A_in, CPLM_Mat_CSR_t *B_out, CPLM_IVector_t *v)
{
CPLM_PUSH
CPLM_BEGIN_TIME

  int ierr  = 0;
	int nbVal = 0;//represents the number of nnz in a row
  int c     = 0;
  CPLM_IVector_t columns  = CPLM_IVectorNULL();//boolean of columns wondered
  CPLM_IVector_t indexC   = CPLM_IVectorNULL();//Index of columns

  CPLM_ASSERT(v->val != NULL);

  //Be sort v is sorted
	CPLM_quickSort(v->val, 0, v->nval - 1);

  //Set info and Allocations
	B_out->info = A_in->info;
	B_out->info.N = A_in->info.n;
  B_out->info.n = v->nval;
  ierr  = CPLM_MatCSRMalloc(B_out);CPLM_CHKERR(ierr);

  ierr = CPLM_IVectorCalloc(&columns, A_in->info.n);CPLM_CHKERR(ierr); 
  ierr = CPLM_IVectorMalloc(&indexC, A_in->info.n);CPLM_CHKERR(ierr);

  ierr = CPLM_IVectorConstant(&indexC,-1);CPLM_CHKERR(ierr);

  for(int i = 0; i < v->nval; i++)
  {
    c               = v->val[i];
    columns.val[c]  = 1;
    indexC.val[c]   = i;
  }

  //Get values and columns of each element of v
  B_out->rowPtr[0] = 0;
  for(int i = 0; i < B_out->info.m; i++)
  {
		for(int nnz = A_in->rowPtr[i]; nnz < A_in->rowPtr[i + 1]; nnz++)
    {
	    c = A_in->colInd[nnz];
	    if(columns.val[c])
      {
	      B_out->colInd[nbVal]  = indexC.val[c];
	      B_out->val[nbVal++]   = A_in->val[nnz];
	    }
		}
		B_out->rowPtr[i + 1]  = nbVal;
	}

  B_out->info.nnz   = A_in->info.lnnz;
  B_out->info.lnnz  = nbVal;

  //Adjust size
  B_out->colInd = (int*)    realloc(B_out->colInd,
      B_out->info.lnnz * sizeof(int));
  B_out->val    = (double*) realloc(B_out->val,
      B_out->info.lnnz * sizeof(double));

  //Sort columns of each line
  for(int i = 0; i < B_out->info.m; i++)
    CPLM_quickSortWithValues(B_out->colInd,
        B_out->rowPtr[i],
        B_out->rowPtr[i + 1] - 1,
        B_out->val);

  CPLM_IVectorFree(&indexC);
  CPLM_IVectorFree(&columns);

CPLM_END_TIME
CPLM_POP
	return ierr;
}


/**
 * \fn int CPLM_MatCSRGetSubFromVectors(CPLM_Mat_CSR_t *m1, CPLM_Mat_CSR_t *m2, CPLM_IVector_t *vl, CPLM_IVector_t *vc)
 * \brief Function creates a CSR matrix without value which corresponds to a submatrix of the original CSR matrix filtered by a CPLM_IVector_t of row's selection and a CPLM_IVector_t of column's selection
 * Note : this function does not need the matrix values
 * \param *m1         The original CSR matrix
 * \param *m2         The sub CSR matrix
 * \param *vl         The CPLM_IVector_t of row selection
 * \param *vc         The CPLM_IVector_t of column selection
 * \return            0 if succeed
 */
//function which returns a submatrice at CSR format from an original matrix (in CSR format too) and filtered by two vectors
int CPLM_MatCSRGetSubFromVectors(CPLM_Mat_CSR_t *m1, CPLM_Mat_CSR_t *m2, CPLM_IVector_t *vl, CPLM_IVector_t *vc){
CPLM_PUSH
CPLM_BEGIN_TIME

  int err=0;

	CPLM_quickSort(vl->val,0,vl->nval-1);
	CPLM_quickSort(vc->val,0,vc->nval-1);

	err=CPLM_MatCSRInit(m2,&(m1->info));CPLM_CHKERR(err);
	m2->info.structure=UNSYMMETRIC;

	int sum=0;

	for(int i=0;i<vl->nval;i++)
		sum+=m1->rowPtr[vl->val[i]+1]-m1->rowPtr[vl->val[i]];

	m2->info.nnz=m2->info.lnnz=sum;

  err=CPLM_MatCSRMalloc(m2);

	int nbValues=0;
	//represents the number of nnz in a row
	int nbVal=0;
	int cpt=0,found=0;
	int begin=0;

	m2->rowPtr[0]=0;
	//copy of arrays
	//for each line of vec_line
	for(int i=0;i<vl->nval;i++){
		nbVal=0;
		begin=0;
		//for each column
		for(int ii=m1->rowPtr[vl->val[i]];ii<m1->rowPtr[vl->val[i]+1];ii++){
			cpt=begin;
			found=0;
			//while value not found in vec_column
			while(cpt<vc->nval && found!=1){
				if(m1->colInd[ii]>vc->val[cpt]){
					cpt++;
					continue;
				}//if column is in vec_column
				else if(m1->colInd[ii]==vc->val[cpt]){
					m2->colInd[nbValues]=cpt;
					m2->val[nbValues]=m1->val[ii];
					nbValues++;
					nbVal++;
					found=1;
					begin=cpt+1;
				}
				else
					break;
			}
		}
		m2->rowPtr[i+1]=m2->rowPtr[i]+nbVal;
	}

	if(m2->info.nnz!=nbValues){

		m2->info.nnz=m2->info.lnnz=nbValues;
		int *save_ptr;
		save_ptr=(int*)realloc(m2->colInd,m2->info.lnnz*sizeof(int));
		m2->colInd=save_ptr;

		double *save_ptr_too;
		save_ptr_too=(double*)realloc(m2->val,m2->info.lnnz*sizeof(double));
		m2->val=save_ptr_too;
	}
CPLM_END_TIME
CPLM_POP
	return err;
}





/**
 * \fn int CPLM_MatCSRIsAbsEqual(CPLM_Mat_CSR_t *m1, CPLM_Mat_CSR_t *m2)
 * \brief Function which test if these two CSR matrices are the same
 * \param *matCSR1 The CSR matrix
 * \param *matCSR2 The CSR matrix
 * \return a boolean value
 */
int CPLM_MatCSRIsAbsEqual(CPLM_Mat_CSR_t *m1, CPLM_Mat_CSR_t *m2)
{
  int ok = CPLM_TRUE;

  if(!CPLM_MatCSRIsSameStruct(m1,m2))
    return !ok;

	for(int i = 0; i < m1->info.m; i++)
  {
		for(int j = m1->rowPtr[i]; j < m1->rowPtr[i + 1]; j++)
    {
			if(fabs( fabs(m1->val[j]) - fabs(m2->val[j]) ) > CPLM_EPSILON)
      {
				fprintf(stderr,"Error val\n[%d,%d] %f != %f\n", i, j, m1->val[j], m2->val[j]);
				fprintf(stderr,"Error val\n[%d,%d] %a != %a\n", i, j, m1->val[j], m2->val[j]);
				return !ok;
			}
		}
	}
	return ok;
}





/**
 * \fn int CPLM_MatCSRIsEqual(CPLM_Mat_CSR_t *m1, CPLM_Mat_CSR_t *m2)
 * \brief Function which test if these two CSR matrices are the same
 * \param *matCSR1 The CSR matrix
 * \param *matCSR2 The CSR matrix
 * \return a boolean value
 */
int CPLM_MatCSRIsEqual(CPLM_Mat_CSR_t *m1, CPLM_Mat_CSR_t *m2)
{
  int ok = CPLM_TRUE;

  if(!CPLM_MatCSRIsSameStruct(m1,m2))
  {
    fprintf(stderr, "Error, these matrices do not have the same structure\n");
    CPLM_MatCSRPrintfInfo("M1", m1);
    CPLM_MatCSRPrintfInfo("M2", m2);

    return !ok;
  }

	for(int i = 0; i < m1->info.m; i++)
  {
		for(int j = m1->rowPtr[i]; j < m1->rowPtr[i + 1]; j++)
    {
			if( fabs(m1->val[j] - m2->val[j]) > CPLM_EPSILON)
      {
				fprintf(stderr,"Error val\n[%d,%d] %f != %f\n", i, j, m1->val[j], m2->val[j]);
				fprintf(stderr,"Error val\n[%d,%d] %a != %a\n", i, j, m1->val[j], m2->val[j]);
				return !ok;
			}
		}
	}
	return ok;
}





/**
 * \fn int CPLM_MatCSRIsSameStruct(CPLM_Mat_CSR_t *m1, CPLM_Mat_CSR_t *m2)
 * \brief Function which test if these two CSR matrices have the same structure
 * \param *matCSR1 The CSR matrix
 * \param *matCSR2 The CSR matrix
 * \return a boolean value
 */
int CPLM_MatCSRIsSameStruct(CPLM_Mat_CSR_t *m1, CPLM_Mat_CSR_t *m2)
{
  int ok = CPLM_TRUE;

	if( m1->info.M          !=  m2->info.M          ||
	 		m1->info.N          !=  m2->info.N          ||
	 		m1->info.m          !=  m2->info.m          ||
	 		m1->info.n          !=  m2->info.n          ||
	 		m1->info.nnz        !=  m2->info.nnz        ||
	 		m1->info.lnnz       !=  m2->info.lnnz       ||
	 		m1->info.blockSize  !=  m2->info.blockSize  ||
	 		m1->info.structure  !=  m2->info.structure  ||
	 		m1->info.format     !=  m2->info.format )
  {

		fprintf(stderr,"Error of structure\n");
#ifdef DEBUG
    CPLM_MatCSRPrintfInfo("matrix 1", m1);
    CPLM_MatCSRPrint(m1);
    CPLM_MatCSRPrintfInfo("matrix 2", m2);
    CPLM_MatCSRPrint(m2);
#endif
    return !ok;
	}

	for(int i = 0;  i < m1->info.m; i++)
  {
		for(int j = m1->rowPtr[i];  j < m1->rowPtr[i + 1];  j++)
    {
			if(m1->colInd[j] != m2->colInd[j])
      {
				fprintf(stderr,"[Row %d]Error col %d\n%d != %d\n",i,j,m1->colInd[j],m2->colInd[j]);
#ifdef DEBUG
        CPLM_MatCSRPrintfInfo("matrix 1", m1);
        CPLM_MatCSRPrint(m1);
        CPLM_MatCSRPrintfInfo("matrix 2", m2);
        CPLM_MatCSRPrint(m2);
#endif
				return !ok;
			}
		}
	}
	return ok;
}





int CPLM_MatCSRIsSym(CPLM_Mat_CSR_t *m)
{
  int ok      = CPLM_TRUE;
  int ierr    = 0;
  int sym     = 1;
  int column  = 0;
  int length  = 0;
  double val = 0.0;
  CPLM_IVector_t ptr_diag = CPLM_IVectorNULL();

  ierr = CPLM_MatCSRGetDiagInd(m,&ptr_diag);CPLM_CHKERR(ierr);

  for(int line = 0; line < m->info.m; line++)
  {
    sym = 1;
    for (int idx_column = ptr_diag.val[line] + 1; idx_column < m->rowPtr[line+1]; idx_column++)
    {
      column  = m->colInd[idx_column];
      val     = m->val[idx_column];
      for(int ii = m->rowPtr[column]; ii < ptr_diag.val[column]; ii++)
      {
        if(m->colInd[ii] == line && m->val[ii] == val)
        {
          sym++;
          break;
        }
      }

    }
    length = (m->rowPtr[line+1] - ptr_diag.val[line]);
    if(sym != length)
    {
      fprintf(stderr,"Error, Matrix is not symmetric\nInfo : Line %d => %d / %d values have its symmetric value\n",line,sym,length);
      return !ok;
    }
  }

  CPLM_IVectorFree(&ptr_diag);

  return ok;
}

/**
 * \fn void matCSRTestFunction()
 * \brief Function which test all functions written for a CSR matrix
 */
void CPLM_MatCSRTestFunction(){

#if 0
	int cr=0, ok=0;
	CPLM_Mat_CSR_t matCSR, mat, tmp_mat;
  // CPLM_Mat_CSR_t ttmp_mat, L, U;
	const char matrix_name1[]="../TestDir/matvf2dAD100100.mtx";
	const char matrix_name2[]="../TestDir/b1_ss.mtx";
	int row[]={0,2,4,7,9};
	int col[]={0,2,1,2,0,1,2,2,3};
	double val[]={1.0,2.0,3.0,4.0,5.0,6.0,7.0,8.0,9.0};
	int row1[]={0,1,2,4,5};
	int col1[]={2,2,0,1,2};
	double val1[]={2.0,4.0,5.0,6.0,8.0};
	int row2[]={0,1,2,5,6};
	int col2[]={2,2,0,1,3,2};
	double val2[]={2.0,4.0,5.0,6.0,7.0,8.0};
	// int row3[]={0,2,5,7};
	// int col3[]={0,1,0,1,2,1,2};
	// double val3[]={2,-1,-1,2,-1,-1,2};

  ttmp_mat.info.M=ttmp_mat.info.N=ttmp_mat.info.m=ttmp_mat.info.n=3;
	ttmp_mat.info.nnz=tmp_mat.info.lnnz=7;
	ttmp_mat.info.blockSize=1;
	ttmp_mat.info.format=FORMAT_CSR;
	ttmp_mat.info.structure=UNSYMMETRIC;
	ttmp_mat.rowPtr=malloc((ttmp_mat.info.M+1)*sizeof(int));
	ttmp_mat.colInd=malloc(ttmp_mat.info.nnz*sizeof(int));
	ttmp_mat.val=malloc(ttmp_mat.info.nnz*sizeof(double));
	for(int i=0;i<ttmp_mat.info.M+1;i++)
	  ttmp_mat.rowPtr[i]=row3[i];
	for(int i=0;i<ttmp_mat.info.nnz;i++){
	  ttmp_mat.colInd[i]=col3[i];
	  ttmp_mat.val[i]=val3[i];
	}

	PetscLUFactorization(&ttmp_mat, &L, &U, &M);

	CPLM_MatCSRPrint(&L);
	printf("------------------\n");
	CPLM_MatCSRPrint(&U);

	CPLM_MatCSRFree(&L);
	CPLM_MatCSRFree(&U);

	LUfactorization(&ttmp_mat,&L,&U);

	CPLM_MatCSRPrint(&L);
	printf("------------------\n");
	CPLM_MatCSRPrint(&U);
	matCSR.info.M=matCSR.info.N=matCSR.info.m=matCSR.info.n=4;
	matCSR.info.nnz=matCSR.info.lnnz=9;
	matCSR.info.blockSize=1;
	matCSR.info.format=FORMAT_CSR;
	matCSR.info.structure=UNSYMMETRIC;
	matCSR.rowPtr=(int*)malloc((matCSR.info.M+1)*sizeof(int));
	matCSR.colInd=(int*)malloc(matCSR.info.nnz*sizeof(int));
	matCSR.val=(double*)malloc(matCSR.info.nnz*sizeof(double));
	for(int i=0;i<matCSR.info.M+1;i++)
	  matCSR.rowPtr[i]=row[i];
	for(int i=0;i<matCSR.info.nnz;i++){
	  matCSR.colInd[i]=col[i];
	  matCSR.val[i]=val[i];
	}

	mat.info.M=mat.info.N=mat.info.m=mat.info.n=4;
	mat.info.nnz=mat.info.lnnz=9;
	mat.info.blockSize=1;
	mat.info.format=FORMAT_CSR;
	mat.info.structure=UNSYMMETRIC;
	mat.rowPtr=(int*)malloc((mat.info.M+1)*sizeof(int));
	mat.colInd=(int*)malloc(mat.info.nnz*sizeof(int));
	mat.val=(double*)malloc(mat.info.nnz*sizeof(double));
	for(int i=0;i<mat.info.M+1;i++)
	  mat.rowPtr[i]=row[i];
	for(int i=0;i<mat.info.nnz;i++){
	  mat.colInd[i]=col[i];
	  mat.val[i]=val[i];
	}

	tmp_mat.info.M=tmp_mat.info.N=tmp_mat.info.m=tmp_mat.info.n=4;
	tmp_mat.info.nnz=tmp_mat.info.lnnz=9;
	tmp_mat.info.blockSize=1;
	tmp_mat.info.format=FORMAT_CSR;
	tmp_mat.info.structure=UNSYMMETRIC;
	tmp_mat.rowPtr=(int*)malloc((tmp_mat.info.M+1)*sizeof(int));
	tmp_mat.colInd=(int*)malloc(tmp_mat.info.nnz*sizeof(int));
	tmp_mat.val=(double*)malloc(tmp_mat.info.nnz*sizeof(double));
	for(int i=0;i<tmp_mat.info.M+1;i++)
	  tmp_mat.rowPtr[i]=row[i];
	for(int i=0;i<tmp_mat.info.nnz;i++){
	  tmp_mat.colInd[i]=col[i];
	  tmp_mat.val[i]=val[i];
	}

	mat.val[mat.info.nnz-1]=0.0;
	tmp_mat.colInd[mat.info.nnz-1]=-1.0;

	//test on same matrix, on a matrix with last column value is changed, inverts arguments of the function from the last case
	cr = CPLM_MatCSRIsSameStruct(&matCSR,&matCSR) || !MatCSRIsSameStruct(&tmp_mat,&matCSR) || !MatCSRIsSameStruct(&matCSR,&tmp_mat); ok = ok || cr;
	if(cr) eprintf("MatCSRIsSameStruct");

	//test on same matrix, on a matrix with last value is changed, inverts arguments of the function from the last case
	cr = CPLM_MatCSRIsEqual(&matCSR,&matCSR) || !MatCSRIsEqual(&mat,&matCSR) || !MatCSRIsEqual(&matCSR,&mat); ok = ok || cr;
	if(cr) eprintf("MatCSRIsEqual"); CPLM_MatCSRFree(&mat);

	CPLM_MatCSRFree(&tmp_mat);
	cr = tmp_mat.val!=NULL || tmp_mat.rowPtr!=NULL || tmp_mat.colInd!=NULL; ok = ok || cr;
	if(cr) eprintf("MatCSRFree");

	mat.info.M=mat.info.N=mat.info.m=mat.info.n=4;
	mat.info.nnz=mat.info.lnnz=5;
	mat.info.blockSize=1;
	mat.info.format=FORMAT_CSR;
	mat.info.structure=UNSYMMETRIC;
	mat.rowPtr=(int*)malloc((mat.info.M+1)*sizeof(int));
	mat.colInd=(int*)malloc(mat.info.nnz*sizeof(int));
	mat.val=(double*)malloc(mat.info.nnz*sizeof(double));
	for(int i=0;i<mat.info.M+1;i++)
	  mat.rowPtr[i]=row1[i];
	for(int i=0;i<mat.info.nnz;i++){
	  mat.colInd[i]=col1[i];
	  mat.val[i]=val1[i];
	}

	CPLM_MatCSRDelDiag(&matCSR,&tmp_mat);
	cr = CPLM_MatCSRIsEqual(&mat,&tmp_mat); ok = ok || cr;
  if(cr) eprintf("MatCSRDelDiag"); CPLM_MatCSRFree(&tmp_mat); MatCSRFree(&mat);

	mat.info.M=mat.info.N=mat.info.m=mat.info.n=4;
	mat.info.nnz=mat.info.lnnz=6;
	mat.info.blockSize=1;
	mat.info.format=FORMAT_CSR;
	mat.info.structure=SYMMETRIC;
	mat.rowPtr=(int*)malloc((mat.info.M+1)*sizeof(int));
	mat.colInd=(int*)malloc(mat.info.nnz*sizeof(int));
	mat.val=(double*)malloc(mat.info.nnz*sizeof(double));
	for(int i=0;i<mat.info.M+1;i++)
	  mat.rowPtr[i]=row2[i];
	for(int i=0;i<mat.info.nnz;i++){
	  mat.colInd[i]=col2[i];
	  mat.val[i]=val2[i];
	}

	CPLM_MatCSRSymStruct(&matCSR,&tmp_mat);
	cr = CPLM_MatCSRIsSameStruct(&mat,&tmp_mat); ok = ok || cr;
  if(cr) eprintf("MatCSRSymStruct"); CPLM_MatCSRFree(&tmp_mat);MatCSRFree(&mat);MatCSRFree(&matCSR);

  CPLM_LoadMatrixMarket(matrix_name1, &mat);
#ifdef MPIACTIVATE
	CPLM_LoadBlockMatrixMMEx(MPI_COMM_SELF, matrix_name1, 1, FORMAT_CSR, &matCSR);
#else
  CPLM_LoadMatrixMarket(matrix_name1, &matCSR);
#endif
  cr = CPLM_MatCSRIsEqual(&mat,&matCSR); ok = ok || cr;
  if(cr) eprintf("LoadMatrixMarket"); CPLM_MatCSRFree(&matCSR); MatCSRFree(&mat);

	CPLM_LoadMatrixMarket(matrix_name2, &matCSR);
	CPLM_IVector_t select;
	select.nval=matCSR.info.M;
	select.val=(int*)malloc(select.nval*sizeof(int));
	for(int i=0;i<select.nval;i++)
	  select.val[i]=i;

	CPLM_MatCSRGetSubFromVector(&matCSR,&mat,&select);
	cr = CPLM_MatCSRIsSameStruct(&mat,&matCSR); CPLM_MatCSRFree(&mat); ok = ok || cr;
	if(cr) eprintf("MatCSRGetSubFromVector");

	CPLM_MatCSRGetSubFromVectors(&matCSR,&mat,&select,&select);
	cr = CPLM_MatCSRIsEqual(&mat,&matCSR); CPLM_MatCSRFree(&mat); ok = ok || cr;
	if(cr) eprintf("MatCSRGetSubFromVectors");

  CPLM_MatCSRGetRecFromVector(&matCSR,&tmp_mat,&select);
  cr = CPLM_MatCSRIsEqual(&tmp_mat,&matCSR); ok = ok || cr;
	if(cr) eprintf("MatCSRGetRecFromVector");

  CPLM_MatCSRGetSqrtFromVector(&tmp_mat,&mat,&select);
	cr = CPLM_MatCSRIsEqual(&mat,&matCSR); CPLM_MatCSRFree(&mat);MatCSRFree(&tmp_mat); ok = ok || cr;
	if(cr) eprintf("MatCSRGetSqrtFromVector");

  CPLM_MatCSRGetRectFromInt(&matCSR,&mat,0,select.nval);
	cr = CPLM_MatCSRIsEqual(&mat,&matCSR); CPLM_MatCSRFree(&mat); ok = ok || cr;
	if(cr) eprintf("MatCSRGetRectFromInt");

	CPLM_MatCSRCopy(&matCSR,&mat);
	cr = CPLM_MatCSRIsEqual(&mat,&matCSR); CPLM_MatCSRFree(&mat); ok = ok || cr;
	if(cr) eprintf("MatCSRCopy");

	CPLM_MatCSRSave(&matCSR,"erase_file.mtx");
	CPLM_LoadMatrixMarket("erase_file.mtx", &mat);
	cr = CPLM_MatCSRIsEqual(&mat,&matCSR); CPLM_MatCSRFree(&matCSR);MatCSRFree(&mat); ok = ok || cr;
	if(cr) eprintf("MatCSRSave");

	if(!ok) printf("Tests of Object CPLM_Mat_CSR_t are ok\n");

  //Test of performance
	ierr = CPLM_LoadBlockMatrixMMEx(PETSC_COMM_SELF, matrix_name1, 1, FORMAT_CSR, &matCSR);
  int *vec_line=NULL;
  int size_line=4000;
  if((vec_line=(int*)malloc(size_line*sizeof(int)))==NULL){
    fprintf(stderr,"Error during malloc of vec_line \n");
    exit(1);
  }
  for(int i=0;i<size_line;i++)
    vec_line[i]=2*i;

  double t =	MPI_Wtime();
  CPLM_Mat_CSR_t mat_ref = getSubMatCSRFromVector(&matCSR,vec_line,size_line);
  top(t,"SubMatrix returned by getSubMatCSRFromVector",0);

  t =	MPI_Wtime();
  CPLM_Mat_CSR_t mat_refs = getSubMatCSRFromVectors(&matCSR,vec_line,size_line,vec_line,size_line);
  top(t,"SubMatrix returned by getSubMatCSRFromVectors",0);

  t =	MPI_Wtime();
  CPLM_Mat_CSR_t mat_rec_tmp = getRectangularSubMatCSRFromVector(&matCSR,vec_line,size_line);
  CPLM_Mat_CSR_t mat_square = getSquareSubMatCSRFromVector(&mat_rec_tmp,vec_line,size_line);
  top(t,"SubMatrix returned by getSquareSubMatCSRFromVector",0);
  //--------------------------------------
#else
  CPLM_Abort("Unimplemented yet\n");
#endif
}


/**
 * \fn int CPLM_MatCSRChkDiag(CPLM_Mat_CSR_t *m)
 * \brief This function looks for position of diagonal elements in m and assume the matrix does not have any zero on the diagonal
 * \param *m    The CSR matrix
 * \param *v    The CPLM_IVector_t returned containing indices
 * \return      0 if the searching is done
 */
int CPLM_MatCSRChkDiag(CPLM_Mat_CSR_t *m){
CPLM_PUSH
CPLM_BEGIN_TIME
  int err=0;
  int min_mn = (m->info.n < m->info.m) ? m->info.n : m->info.m;
  for(int i=0;i<min_mn;i++){
    int found=0;
    for(int col=m->rowPtr[i];col<m->rowPtr[i+1];col++){
      if(m->colInd[col]==i){
        found=1;
        break;
      }
    }
    if(!found){
      fprintf(stderr,"Error, no diagonal value on the row %d\n",i);
      return 1;
    }
  }
CPLM_END_TIME
CPLM_POP
  return err;
}





/**
 * \fn int CPLM_MatCSRGetDiagIndOfPanel(CPLM_Mat_CSR_t *A_in, CPLM_IVector_t *v)
 * \brief This function looks for position of diagonal elements in m and assume the matrix does not have any zero on the diagonal
 * \param *A_in   The CSR matrix
 * \param *v      The CPLM_IVector_t returned containing indices
 * \param offset  The offset to local the beginning of the diagonal block in the panel
 * \return      0 if the memory allocation is ok
 */
int CPLM_MatCSRGetDiagIndOfPanel(CPLM_Mat_CSR_t *A_in, CPLM_IVector_t *d_out, CPLM_IVector_t *pos, CPLM_IVector_t *colPos, int numBlock)
{
CPLM_PUSH
CPLM_BEGIN_TIME

  int ierr      = 0;
  int cpt       = 0;
  int rowLayout = 0;
  int rowB      = 0; //The beginning index of the block line
  int rowE      = 0; //The beginning index of the next block line
  int colB      = 0;
  int nblock    = 0;
  int *colPtr = NULL;

  nblock = pos->nval-1;

  //Check if it is either a row layout or a column layout
  if(A_in->info.m > A_in->info.n)//i.e. Column layout
  {
    rowB  = pos->val[numBlock];
    rowE  = pos->val[numBlock+1];
    colPtr = A_in->rowPtr;
  }
  else//i.e. Row layout
  {
    rowB = 0;
    rowE = A_in->info.m;
    colPtr = colPos->val;
    rowLayout = 1;
    colB = pos->val[numBlock];
    //CPLM_debug("colB %d\n",colB);
  }

  //Allocate the output vector
  if(d_out->val == NULL)
  {
    ierr = CPLM_IVectorMalloc(d_out, rowE-rowB);CPLM_CHKERR(ierr);
  }

  //Search position of each diagonal element
  for(int i = rowB; i < rowE; i++)
  {
    //CPLM_debug("Row %d\n",i);
    int j = ((rowLayout == 0) ? i : (i * nblock + numBlock));
    //CPLM_debug("Corrected Row %d\n",j);
    for(int col = colPtr[j]; col < colPtr[j+1]; col++)
    {
      //CPLM_debug("Colptr %d\tof col %d =?= %d\n",col,A_in->colInd[col]-colB,i);
      if(A_in->colInd[col] - colB == i )
      {
        d_out->val[cpt++] = col;
        break;
      }
    }
  }

CPLM_END_TIME
CPLM_POP
  return ierr;
}






/**
 * \fn int CPLM_MatCSRGetDiagInd(CPLM_Mat_CSR_t *A_in, CPLM_IVector_t *v)
 * \brief This function looks for position of diagonal elements in m and assume the matrix does not have any zero on the diagonal
 * \param *A_in   The CSR matrix
 * \param *v      The CPLM_IVector_t returned containing indices
 * \return      0 if the memory allocation is ok
 */
int CPLM_MatCSRGetDiagInd(CPLM_Mat_CSR_t *A_in, CPLM_IVector_t *v)
{
CPLM_PUSH
CPLM_BEGIN_TIME

  int ierr=0;

  if(v->val == NULL)
  {
    ierr = CPLM_IVectorMalloc(v,A_in->info.m);CPLM_CHKERR(ierr);
  }

  for(int i = 0; i < A_in->info.m; i++)
  {
    for(int col = A_in->rowPtr[i]; col < A_in->rowPtr[i+1]; col++)
    {
      if(A_in->colInd[col] == i)
      {
        v->val[i] = col;
        break;
      }
    }
  }

CPLM_END_TIME
CPLM_POP
  return ierr;
}


/**
 * \fn int CPLM_MatCSRSend(CPLM_Mat_CSR_t *m, int dest, MPI_Comm comm)
 * \brief This function sends a CSR matrix to id'th MPI process
 * \param *m    The CSR matrix
 * \param dest  The MPI process id which receives the matrix
 * \param comm  The MPI communicator of the group
 * \return      0 if the sending is done
 */
#ifdef MPIACTIVATE
int CPLM_MatCSRSend(CPLM_Mat_CSR_t *m, int dest, MPI_Comm comm){
CPLM_PUSH
CPLM_BEGIN_TIME

  int err   = 0;
  int tag   = 0;

  MPI_Datatype MPI_MAT_CSR = initMPI_StructCSR();

  //broadcast the matrix to all processes included into MPI comm group
  if( dest == -1){
    fprintf(stderr,"Broadcast is not managed for the moment\n");
    return 1;
  }else{
    //send information of the matrix
    err=MPI_Send(&(m->info),1,MPI_MAT_CSR,dest,tag,comm);CPLM_checkMPIERR(err,"send_info");

    if(m->info.m>0){ //Send Data only if the number of rows is greater than 0
      //send rowPtr
      err=MPI_Send(m->rowPtr,m->info.m+1,   MPI_INT,dest,tag,comm);CPLM_checkMPIERR(err,"send_rowPrt");

      //send colInd
      err=MPI_Send(m->colInd,m->info.lnnz,   MPI_INT,dest,tag,comm);CPLM_checkMPIERR(err,"send_colInd");

      //send values
      err=MPI_Send(m->val,m->info.lnnz,      MPI_DOUBLE,dest,tag,comm);CPLM_checkMPIERR(err,"send_val");
    }
  }
CPLM_END_TIME
CPLM_POP
  return err;
}
#endif

#ifdef MPIACTIVATE
int CPLM_MatCSRBcastInfo(CPLM_Info_t *info, int source, MPI_Comm comm){

  int err=0;

  MPI_Datatype MPI_MAT_CSR = initMPI_StructCSR();

  err=MPI_Bcast(info,1,MPI_MAT_CSR,source,comm);CPLM_checkMPIERR(err,"send_info");

  return err;
}
#endif



int CPLM_MatCSRInit(CPLM_Mat_CSR_t *A_out, CPLM_Info_t *info)
{

  A_out->info      = *info;

	A_out->rowPtr    = NULL;
	A_out->colInd    = NULL;
	A_out->val       = NULL;

	return 0;
}





/**
 * \fn int createMatCSR(CPLM_Mat_CSR_t *m, CPLM_Info_t *info)
 * \brief This function creates a CSR matrix from informations in parameters
 * \Note  No control is made on size of rows, cols and vals
 * \param *m      The CSR matrix
 * \param *info   Information like size, nnz structure, to create the matrix
 * \param *rows   Array of row pointer  ;   could be NULL
 * \param *cols   Array of col indice   ;   could be NULL
 * \param *vals   Array of values       ;   could be NULL
 * \return        0 if the matrix creation succeed
 */
int CPLM_MatCSRCreate(CPLM_Mat_CSR_t *m, int *rows, int *cols, double *vals)
{

  int ierr = 0;

  ierr = CPLM_MatCSRMalloc(m);CPLM_CHKERR(ierr);

	if(rows != NULL)
	  memcpy(m->rowPtr,rows,  (m->info.m+1)   * sizeof(int));
	if(cols != NULL)
    memcpy(m->colInd,cols,  (m->info.lnnz)  * sizeof(int));
	if(vals != NULL)
    memcpy(m->val,vals,     (m->info.lnnz)  * sizeof(double));

  return ierr;

}

/**
 * \fn int CPLM_MatCSRRecv(CPLM_Mat_CSR_t *m, int source, MPI_Comm comm)
 * \brief This function sends a CSR matrix to id'th MPI process
 * \param *m      The CSR matrix
 * \param source  The MPI process id which sends the matrix
 * \param comm    The MPI communicator of the group
 * \return        0 if the reception succeed
 */
#ifdef MPIACTIVATE
int CPLM_MatCSRRecv(CPLM_Mat_CSR_t *A_out, int source, MPI_Comm comm)
{
CPLM_PUSH
CPLM_BEGIN_TIME

  int ierr  = 0;
  int tag   = 0;
  MPI_Status status;

  MPI_Datatype MPI_MAT_CSR = initMPI_StructCSR();

  //broadcast the matrix over all processes included into MPI comm group
  if( source == -1)
  {
    fprintf(stderr,"Broadcast is not managed for the moment\n");
    ierr = 1;
  }
  else
  {
    //recv information of the matrix
    ierr = MPI_Recv(&(A_out->info),1,MPI_MAT_CSR,source,tag,comm,&status);CPLM_checkMPIERR(ierr,"recv_info");

    ierr = CPLM_MatCSRMalloc(A_out);CPLM_CHKERR(ierr);

    if(A_out->info.m>0){ //The Data will be sent only if the number of rows is greater than 0
      //recv rowPtr
      ierr = MPI_Recv(A_out->rowPtr,A_out->info.m+1,  MPI_INT,source,tag,comm,&status);CPLM_checkMPIERR(ierr,"recv_rowPrt");

      //recv colInd
      ierr = MPI_Recv(A_out->colInd,A_out->info.lnnz, MPI_INT,source,tag,comm,&status);CPLM_checkMPIERR(ierr,"recv_colInd");

      //recv values
      ierr = MPI_Recv(A_out->val,   A_out->info.lnnz, MPI_DOUBLE,source,tag,comm,&status);CPLM_checkMPIERR(ierr,"recv_val");
   }
      
  }

CPLM_END_TIME
CPLM_POP
  return ierr;
}
#endif












/*
*
* This function returns colPos which is an index of the begin and end of each block in column point of view.
*
*/
//#define IFCOND
int CPLM_MatCSRGetColBlockPos(CPLM_Mat_CSR_t *m, CPLM_IVector_t *pos, CPLM_IVector_t *colPos)
{
CPLM_PUSH
CPLM_BEGIN_TIME

  int nblock      = pos->nval - 1;
  int ierr        = 0;
  int numBlock    = 0;//By default, we consider the first block
  int newNumBlock = 0;
  int c           = 0;

  ierr = CPLM_IVectorMalloc(colPos, m->info.m * nblock + 1);CPLM_CHKERR(ierr);

  colPos->val[0]             = 0;
  colPos->val[pos->nval - 1] = m->rowPtr[m->info.m];

  for(int i = 0; i < m->info.m; i++)
  {
    numBlock = 0;
    for(int j = m->rowPtr[i]; j < m->rowPtr[i+1]; j++)
    {
      c = m->colInd[j];
#ifdef IFCOND
      if (c >= pos->val[numBlock + 1])
      {
        //Save ending position
        colPos->val[i * nblock + numBlock + 1] = j;
        newNumBlock  = c / nblock;
        for(int k = numBlock + 1; k < newNumBlock; k++)
        {
          //Save starting position
          colPos->val[i * nblock + k + 1] = j;
        }
        numBlock = newNumBlock;
      }
#else
      while(c >= pos->val[numBlock + 1])
      {
        numBlock++;
        colPos->val[i * nblock + numBlock] = j;
      }
#endif
    }
    for(int k = numBlock + 1; k <= nblock; k++)
    {
      colPos->val[i * nblock + k] = m->rowPtr[i + 1];
    }
  }

CPLM_END_TIME
CPLM_POP
  return ierr;
}





/*
*
* This function returns colPos which is an index of the begin and end of each block in column point of view.
*
*/
int CPLM_MatCSRGetPartialColBlockPos(CPLM_Mat_CSR_t *A_in,
                                CPLM_IVector_t *posR,
                                int       numBlock,
                                CPLM_IVector_t *posC,
                                CPLM_IVector_t *colPos)
{
CPLM_PUSH
CPLM_BEGIN_TIME

  int nblockR     = posR->nval - 1;
  int nblockC     = posC->nval - 1;
  int ierr        = 0;
  int newNumBlock = 0;
  int c           = 0;
  int curRow      = 0;
  int nrow        = 0;
  int offsetB     = 0;
  int offsetE     = 0;


  offsetB = posR->val[numBlock];
  offsetE = posR->val[numBlock + 1];
  nrow    = offsetE - offsetB;

  if(colPos->val == NULL)
  {
    ierr = CPLM_IVectorMalloc(colPos, nrow * nblockC + 1);CPLM_CHKERR(ierr);
  }
  else if((nrow * nblockC + 1) > colPos->nval)
  {
  //ierr = CPLM_IVectorRealloc(colPos, nrow * nblock + 1);CPLM_CHKERR(ierr);
    CPLM_Abort("Try to realloc a pointer that could be symbolic");
  }

  colPos->val[0]                = A_in->rowPtr[offsetB];
  colPos->val[colPos->nval - 1] = A_in->rowPtr[offsetE];

  for(int i = 0; i < nrow; i++)
  {
    numBlock = 0;
    curRow = offsetB + i;
    colPos->val[i * nblockC] = A_in->rowPtr[curRow];
    for(int j = A_in->rowPtr[curRow]; j < A_in->rowPtr[curRow + 1]; j++)
    {
      c = A_in->colInd[j];
      while(c >= posC->val[numBlock + 1])
      {
        numBlock++;
        CPLM_ASSERT((i * nblockC + numBlock) < colPos->nval);
        colPos->val[i * nblockC + numBlock] = j;
      }
    }
    for(int k = numBlock + 1; k <= nblockC; k++)
    {
      CPLM_ASSERT((i * nblockC + k) < colPos->nval);
      CPLM_ASSERT((i + 1) < A_in->info.m + 1);
      colPos->val[i * nblockC + k] = A_in->rowPtr[curRow + 1];
    }
  }

CPLM_END_TIME
CPLM_POP
  return ierr;
}





int CPLM_MatCSRConvertToDenseDVector(CPLM_Mat_CSR_t *m_in, CPLM_DVector_t *v_out)
{

  int ierr = 0;
  ierr = CPLM_DVectorCalloc(v_out,m_in->info.m*m_in->info.n);CPLM_CHKERR(ierr);

  for(int i=0;i<m_in->info.m;i++)
    for(int j=m_in->rowPtr[i];j<m_in->rowPtr[i+1];j++){
      CPLM_ASSERT((i * m_in->info.n + m_in->colInd[j]) < v_out->nval);
      v_out->val[i * m_in->info.n + m_in->colInd[j]] = m_in->val[j];
    }

  return ierr;
}





int CPLM_MatCSRToMatDense(CPLM_Mat_CSR_t *A_in, CPLM_Mat_Dense_t *B_out)
{
CPLM_PUSH
CPLM_BEGIN_TIME

  int ierr    = 0;
  int M       = 0;
  int N       = 0;
  int offset  = 0;

  M = A_in->info.m;
  N = A_in->info.n;

  if(B_out->val == NULL)
  {
    ierr = CPLM_MatDenseSetInfo(B_out,M,N,M,N,ROW_MAJOR);
    ierr = CPLM_MatDenseCalloc(B_out);CPLM_CHKERR(ierr);
  }
  else
  {
    if(B_out->info.nval < ( A_in->info.m * A_in->info.n ) )
    {
      ierr = CPLM_MatDenseSetInfo(B_out,M,N,M,N,ROW_MAJOR);
      ierr = CPLM_MatDenseRealloc(B_out);CPLM_CHKERR(ierr);
    }
  }

  for(int i = 0; i < A_in->info.m; i++)
  {
    offset = i * A_in->info.n;
    for(int j = A_in->rowPtr[i]; j < A_in->rowPtr[i+1]; j++)
    {
      CPLM_ASSERT((offset + A_in->colInd[j]) < B_out->info.nval);
      B_out->val[offset + A_in->colInd[j] ] = A_in->val[j];
    }
  }

CPLM_END_TIME
CPLM_POP
  return ierr;
}

#define EPSILON 1e-15





int CPLM_MatCSRConvertFromDenseDVector(CPLM_Mat_CSR_t *m_out, CPLM_DVector_t *v_in, int M, int N)
{

  int ierr = 0;
  int nnz=0;
  CPLM_Info_t info;
  info.M=info.m=M;
  info.N=info.n=N;

  for(int i=0;i<v_in->nval;i++)
    //if(v->val[i] > EPSILON )
    if(v_in->val[i] != 0.0 )
      nnz++;

  info.nnz=info.lnnz=nnz;
  info.blockSize=1;
  info.format=FORMAT_CSR;
  info.structure=UNSYMMETRIC;

  CPLM_MatCSRInit(m_out,&info);
  CPLM_MatCSRMalloc(m_out);

  int cpt=0;
  m_out->rowPtr[0]=cpt;
  for(int i=0;i<M;i++)
  {
    for(int j=0;j<N;j++)
      //if(v->val[i*N+j] > EPSILON){
      if(v_in->val[i*N+j] != 0.0 )
      {
        m_out->colInd[cpt]=j;
        m_out->val[cpt++]=v_in->val[i*N+j];
      }
    m_out->rowPtr[i+1]=cpt;
  }

  return ierr;

}





//colPos  is the starting index of each block in each row
//m       is the number of rows
//nblock  is the number of blocks
//bi      is the current block
//dep     is the dependency CPLM_IVector_t containing block id dependency of the block bi
int CPLM_MatCSRGetCommDep(CPLM_IVector_t *colPos, int m, int nblock, int bi, CPLM_IVector_t *dep)
{
CPLM_PUSH
CPLM_BEGIN_TIME

  int ierr  = 0;
  int cpt   = 0;
  CPLM_IVector_t tmp = CPLM_IVectorNULL();

  ierr = CPLM_IVectorCalloc(&tmp,nblock);CPLM_CHKERR(ierr);
  ierr = CPLM_IVectorMalloc(dep,nblock);CPLM_CHKERR(ierr);

  for(int i = 0; i < m; i++)
  {
    CPLM_ASSERT(i*nblock+nblock<colPos->nval);
    for(int j = 0; j < nblock; j++)
    {
      tmp.val[j] += colPos->val[i*nblock+j+1] - colPos->val[i*nblock+j];
    }
  }

#ifdef DEBUG
  CPLM_IVectorPrintf("[RAW] Dep vector", &tmp);
#endif

  for(int i = 0; i < nblock; i++)
    if(tmp.val[i] && i != bi)
      dep->val[cpt++] = i;

  if(cpt == 0)
    CPLM_Abort("There is no dependencies between some blocks of A...");

  ierr = CPLM_IVectorRealloc(dep,cpt);CPLM_CHKERR(ierr);

  CPLM_IVectorFree(&tmp);
CPLM_END_TIME
CPLM_POP
  return ierr;

}





int CPLM_MatCSRSetInfo(CPLM_Mat_CSR_t *A_out, int M, int N, int nnz, int m, int n, int lnnz, int blockSize)
{
  int ierr = 0;

  A_out->info.M         = M;
  A_out->info.N         = N;
  A_out->info.nnz       = nnz;
  A_out->info.m         = m;
  A_out->info.n         = n;
  A_out->info.lnnz      = lnnz;
  A_out->info.blockSize = blockSize;
  A_out->info.format    = FORMAT_CSR;
  A_out->info.structure = UNSYMMETRIC;

  return ierr;
}




//This function takes a sparse matrix m1 and a new pattern m2. Then it copies values from m1 into m2 and keep 0 inside.
//This should be used after symbolic factorization, in the way to perform a numeric ILU0 on it.
int CPLM_MatCSRAddExplicitZeros(CPLM_Mat_CSR_t *m1, CPLM_Mat_CSR_t *m2){
CPLM_PUSH
CPLM_BEGIN_TIME
  int ierr  = 0;
  //Pointer in m2
  int ptr   = 0;

  //Ensure if m2->val is NULL then allocate and set to 0
  if(m2->val != NULL){
    memset(m2->val,0,m2->info.nnz*sizeof(double));
  }else{
    m2->val = (double*) calloc(m2->info.nnz,sizeof(double));
    CPLM_ASSERT(m2->val != NULL);
  }

  for(int i=0;i<m1->info.nnz;i++){
    while(m1->colInd[i]!=m2->colInd[ptr]) ptr++;
    m2->val[ptr]=m1->val[i];
  }
CPLM_END_TIME
CPLM_POP
  return ierr;
}




//Here only val could be NULL
int CPLM_MatCSRCreateFromPtr(CPLM_Mat_CSR_t *A_in, int *rowPtr, int *colInd, double *val )
{
CPLM_PUSH

  A_in->rowPtr  = rowPtr;
  A_in->colInd  = colInd;
  A_in->val     = val;

CPLM_POP
  return !(rowPtr != NULL && colInd != NULL);
}





int CPLM_MatCSRGetNormInf(CPLM_Mat_CSR_t *A_in, double *normInf)
{
CPLM_PUSH
  int ierr    = 0;
  int size    = 0;
  int offset  = 0;
  CPLM_DVector_t ptr_s = CPLM_DVectorNULL();
  CPLM_DVector_t val = CPLM_DVectorNULL();
  
  ierr = CPLM_DVectorMalloc(&val, A_in->info.m);CPLM_CHKERR(ierr);

  for(int i = 0; i < A_in->info.m; i++)
  {
    size    = A_in->rowPtr[i + 1] - offset;

    ierr = CPLM_DVectorCreateFromPtr(&ptr_s,
        size,
        A_in->val + offset);CPLM_CHKERR(ierr);
    
    ierr = CPLM_DVectorGetNorm1(&ptr_s, &val.val[i]);CPLM_CHKERR(ierr);

    offset += size;
  }

  ierr = CPLM_DVectorGetNorm1(&val, normInf);CPLM_CHKERR(ierr);

  CPLM_DVectorFree(&val);

CPLM_POP
  return ierr;
}





/**
 * \fn void getLUmatrix(CPLM_Mat_CSR_t *matCSR, CPLM_Mat_CSR_t *matL, CPLM_Mat_CSR_t *matU, int rank)
 * \brief This function creates L and U matrix given by matCSR matrix
 * \param *matCSR The CSR matrix
 * \param *matL The CSR lower triangular matrix
 * \param *matU The CSR upper triangular matrix
 */
/*This function creates L and U matrix given by matCSR matrix*/
//====================================
//12/26/2016: function cleaned but unused so unchecked!!!!
//====================================
int CPLM_MatCSRGetLUFactors(CPLM_Mat_CSR_t *A_in,
    CPLM_Mat_CSR_t *L_out,
    CPLM_Mat_CSR_t *U_out,
    CPLM_IVector_t *diagPtr)
{
CPLM_PUSH
CPLM_BEGIN_TIME

  int ierr = 0;
	int nvalL = 0;
  int nvalU = 0;
  int cpt   = 0;
  CPLM_IVector_t lvalL = CPLM_IVectorNULL();
  CPLM_IVector_t lvalU = CPLM_IVectorNULL();

  CPLM_ASSERT(A_in           !=  NULL);
  CPLM_ASSERT(A_in->val      !=  NULL);
  CPLM_ASSERT(diagPtr->val   !=  NULL);
  //We assume the diagonal elements of A_in are not null
  CPLM_ASSERT(diagPtr->nval  ==  A_in->info.m);
  
	L_out->info = U_out->info = A_in->info;
	L_out->info.nnz  = A_in->info.lnnz;
	U_out->info.nnz  = A_in->info.lnnz;

  ierr = CPLM_IVectorMalloc(&lvalL,  A_in->info.m);CPLM_CHKERR(ierr);
  ierr = CPLM_IVectorMalloc(&lvalU,  A_in->info.m);CPLM_CHKERR(ierr);

  //Count how many nnz in L and U
	for(int i = 0; i < diagPtr->nval; i++)
  {
    lvalL.val[i] = diagPtr->val[i] - A_in->rowPtr[i] + 1;//+1 for diag elements
    lvalU.val[i] = A_in->rowPtr[i] - diagPtr->val[i];

    nvalL += lvalL.val[i];
    nvalU += lvalU.val[i];
	}

	L_out->info.lnnz = nvalL;
  U_out->info.lnnz = nvalU;

  ierr = CPLM_MatCSRMalloc(L_out);CPLM_CHKERR(ierr);
  ierr = CPLM_MatCSRMalloc(U_out);CPLM_CHKERR(ierr);

	L_out->rowPtr[0] = 0;
	U_out->rowPtr[0] = 0;

#ifdef VERBOSE
	printf("L : nbValues = %d\n",nvalL);
	printf("U : nbValues = %d\n",nvalU);
#endif	
	
	nvalL = 0;
  nvalU = 0;
	
	for(int i = 0; i < A_in->info.m; i++)
  {
    //Copy lower elements
    memcpy( L_out->colInd + nvalL,
            A_in->colInd  + A_in->rowPtr[i],
            lvalL.val[i]  * sizeof(int));
    memcpy( L_out->val    + nvalL,
            A_in->val     + A_in->rowPtr[i],
            lvalL.val[i]  * sizeof(double));
    nvalL += lvalL.val[i];
    //Set diagonal elements to 1.0
    L_out->val[nvalL - 1] = 1.0;
    
    //Copy higher elements
    cpt = 0;
    for(int j = diagPtr->val[i]; j < A_in->rowPtr[i + 1]; j++)
    {
      U_out->colInd[nvalU + cpt] = A_in->colInd[j] - i;
      cpt ++;
    }
    CPLM_ASSERT(cpt == lvalU.val[i]);
    memcpy( U_out->val    + nvalU,
            A_in->val     + A_in->rowPtr[i],
            lvalU.val[i]  * sizeof(double));
    nvalU += lvalU.val[i];

		L_out->rowPtr[i + 1]  = nvalL;
		U_out->rowPtr[i + 1]  = nvalU;
	}

CPLM_END_TIME
CPLM_POP
  return ierr;
}





/*
 *  Memory check allocation
 */










/**
 * \fn int CPLM_MatCSRMallocChk(CPLM_Mat_CSR_t *A_io, const char *file, int line, const char *varName)
 * \brief Allocate the memory following the info part.
 * More precisely, it allows m+1 INT for rowPtr, lnnz INT and lnnz DOUBLE for colInd and val arrays.
 * It checks weither the arrays are null or not.
 * \param *A_io   The matrix to free
 * \param *file   The file where this routine is called
 * \param line    The line where this routine is called
 * \param varName The name of the variable to free
 */
int CPLM_MatCSRMallocChk(CPLM_Mat_CSR_t   *A_io,
                    const char  *file,
                    int         line,
                    const char  *varName)
{
CPLM_PUSH

	A_io->rowPtr = (int*)   CPLM_malloc( ( A_io->info.m+1)  * sizeof(int),
      file,
      line,
      varName);
	A_io->colInd = (int*)   CPLM_malloc( A_io->info.lnnz    * sizeof(int),
      file,
      line,
      varName);
	A_io->val    = (double*)CPLM_malloc( A_io->info.lnnz    * sizeof(double),
      file,
      line,
      varName);

  CPLM_ASSERT(A_io->colInd != NULL);
  CPLM_ASSERT(A_io->rowPtr != NULL);
  CPLM_ASSERT(A_io->val != NULL);

CPLM_POP
	return !((A_io->rowPtr != NULL) && (A_io->colInd != NULL) && (A_io->val != NULL));
}





/**
 * \fn int CPLM_MatCSRReallocChk(CPLM_Mat_CSR_t *A_io, const char *file, int line, const char *varName)
 * \brief Reallocate the memory following the info part.
 * More precisely, it allows m+1 INT for rowPtr, lnnz INT and lnnz DOUBLE for colInd and val arrays.
 * It checks weither the arrays are null or not.
 * \param *A_io   The matrix to free
 * \param *file   The file where this routine is called
 * \param line    The line where this routine is called
 * \param varName The name of the variable to free
 */
int CPLM_MatCSRReallocChk( CPLM_Mat_CSR_t   *A_io,
                      const char  *file,
                      int         line,
                      const char  *varName)
{
CPLM_PUSH

	A_io->rowPtr = (int*)   CPLM_realloc(A_io->rowPtr,
      ( A_io->info.m+1) * sizeof(int),
      file,
      line,
      varName);
	A_io->colInd = (int*)   CPLM_realloc(A_io->colInd,
      A_io->info.lnnz   * sizeof(int),
      file,
      line,
      varName);
	A_io->val    = (double*)CPLM_realloc(A_io->val,
      A_io->info.lnnz   * sizeof(double),
      file,
      line,
      varName);

  CPLM_ASSERT(A_io->rowPtr != NULL);
  CPLM_ASSERT(A_io->colInd != NULL);
  CPLM_ASSERT(A_io->val != NULL);

CPLM_POP
	return !((A_io->rowPtr != NULL) && (A_io->colInd != NULL) && (A_io->val != NULL));
}





/**
 * \fn void CPLM_MatCSRFreeChk(CPLM_Mat_CSR_t *A_io, const char *file, int line, const char *varName)
 * \brief Free the memory used as the representation of the matrix.
 * In practice, it frees the three arrays when they are not null.
 * \param *A_io   The matrix to free
 * \param *file   The file where this routine is called
 * \param line    The line where this routine is called
 * \param varName The name of the variable to free
 */
void CPLM_MatCSRFreeChk( CPLM_Mat_CSR_t   *A_io,
                    const char  *file,
                    int         line,
                    const char  *varName)
{
  if (A_io) 
  {
    if (A_io->rowPtr)
    {
      CPLM_free( A_io->rowPtr, file, line, varName);
    }
    if (A_io->colInd)
    {
      CPLM_free( A_io->colInd, file, line, varName);
    }
    if (A_io->val)
    {
      CPLM_free( A_io->val   , file, line, varName);
    }
    A_io->rowPtr  = NULL;
    A_io->colInd  = NULL;
    A_io->val     = NULL;
  }
}





#ifndef MEMCHECK
/**
 * \fn int CPLM_MatCSRMalloc(CPLM_Mat_CSR_t *A_io)
 * \brief Allocate the memory following the info part.
 * More precisely, it allows m+1 INT for rowPtr, lnnz INT and lnnz DOUBLE for colInd and val arrays.
 * It checks weither the arrays are null or not.
 * \param *A_io   The matrix to free
 */
int CPLM_MatCSRMalloc(CPLM_Mat_CSR_t *A_io)
{
CPLM_PUSH

	A_io->rowPtr = (int*)   malloc( ( A_io->info.m+1) * sizeof(int));
	A_io->colInd = (int*)   malloc( A_io->info.lnnz   * sizeof(int));
	A_io->val    = (double*)malloc( A_io->info.lnnz   * sizeof(double));

  CPLM_ASSERT(A_io->colInd != NULL);
  CPLM_ASSERT(A_io->rowPtr != NULL);
  CPLM_ASSERT(A_io->val != NULL);

CPLM_POP
	return !((A_io->rowPtr != NULL) && (A_io->colInd != NULL) && (A_io->val != NULL));
}





/**
 * \fn int CPLM_MatCSRRealloc(CPLM_Mat_CSR_t *A_io)
 * \brief Reallocate the memory following the info part.
 * More precisely, it allows m+1 INT for rowPtr, lnnz INT and lnnz DOUBLE for colInd and val arrays.
 * It checks weither the arrays are null or not.
 * \param *A_io   The matrix to free
 */
int CPLM_MatCSRRealloc( CPLM_Mat_CSR_t *A_io)
{
CPLM_PUSH

	A_io->rowPtr = (int*)   realloc(A_io->rowPtr, (A_io->info.m+1)  * sizeof(int));
	A_io->colInd = (int*)   realloc(A_io->colInd, A_io->info.lnnz   * sizeof(int));
	A_io->val    = (double*)realloc(A_io->val,    A_io->info.lnnz   * sizeof(double));

  CPLM_ASSERT(A_io->rowPtr != NULL);
  CPLM_ASSERT(A_io->colInd != NULL);
  CPLM_ASSERT(A_io->val != NULL);

CPLM_POP
	return !((A_io->rowPtr != NULL) && (A_io->colInd != NULL) && (A_io->val != NULL));
}





/**
 * \fn void CPLM_MatCSRFree(CPLM_Mat_CSR_t *A_io)
 * \brief This method frees the memory occuped by a matrix
 * \param *A_io The matrix which has to be freed
 */
void CPLM_MatCSRFree(CPLM_Mat_CSR_t *A_io)
{
  if(A_io) 
  {
    if(A_io->rowPtr)
    {
      free(A_io->rowPtr);
    }
    if(A_io->colInd)
    {
      free(A_io->colInd);
    }
    if(A_io->val)
    {
      free(A_io->val);
    }
    A_io->rowPtr  = NULL;
    A_io->colInd  = NULL;
    A_io->val     = NULL;
  }
}
#endif
