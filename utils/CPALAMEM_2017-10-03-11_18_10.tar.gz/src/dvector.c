/*
* This file contains functions used to manipulate dvector
*
* Authors : Sebastien Cayrols
*         : Olivier Tissot
* Email   : sebastien.cayrols@[(gmail.com) | (inria.fr)]
*         : olivier.tissot@inria.fr
*/
/**
 * \file dvector.c
 * \brief Structure to store a CPLM_IVector_t with an array of values and its size
 * \author Sebastien Cayrols, Olivier Tissot
 * \version 0.1
 * \date 21 june 2013
 *
 *
 */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <math.h>


#include "cpalamem_macro.h"
#include "dvector.h"
#include "QS.h"
#include "MPIutils.h"
#include "cpalamem_instrumentation.h"




/**
 * \fn CPLM_IVector_t CPLM_DVectorPermute(CPLM_DVector_t *v, CPLM_IVector_t *perm)
 * \brief This function permutes the values of v following the perm vector. a ->
 * \param *v The CPLM_IVector_t contains a set of values
 * \param *perm The permutation vector
 * \return The permuted vector
 * Note : This function has not been checked
 * Computation complexity : size of v
 * Memory complexity : size of v * size of double
 */
int CPLM_DVectorPermute(CPLM_DVector_t *in, CPLM_IVector_t *perm, CPLM_DVector_t *out){
CPLM_PUSH
CPLM_BEGIN_TIME

  out->nval   = perm->nval;
  out->val = (double*)malloc(out->nval*sizeof(double));

  for(int i=0;i<perm->nval;i++)
    out->val[i]=in->val[perm->val[i]];

CPLM_END_TIME
CPLM_POP
  return EXIT_SUCCESS;
}



/**
 * \fn void CPLM_DVectorPrint(CPLM_IVector_t *v, const char *name)
 * \brief Method which prints a CPLM_IVector_t with its name
 * Note : This method is enable only if DEBUG is defined
 * \param *v The CPLM_IVector_t which has to be printed
 * \param *name The name of the vector
 */
/*Function prints a CPLM_IVector_t called name*/
void CPLM_DVectorPrint(CPLM_DVector_t *v)
{
CPLM_PUSH
CPLM_BEGIN_TIME

  int cpt   = 0;
  int limit = 0;
  limit = (v->nval > 30) ? 15 : v->nval;

	for(int i=0;i<v->nval;i++)
  {
	  if(i>limit && i<v->nval-limit)
    {
      if(cpt<3)
        printf(". ");
        cpt++;
	  }
		else
    {
		  printf("%.2e ",v->val[i]);
    }
  }
	printf("\n");
CPLM_END_TIME
CPLM_POP
}








/**
 * \fn void CPLM_DVectorPrint(CPLM_IVector_t *v, const char *name)
 * \brief Method which prints a CPLM_IVector_t with its name
 * Note : This method is enable only if DEBUG is defined
 * \param *v The CPLM_IVector_t which has to be printed
 * \param *name The name of the vector
 */
/*Function prints a CPLM_IVector_t called name*/
void CPLM_DVectorPrint2D(CPLM_DVector_t *v, int m, int lda, const char *name, int sumUp){
CPLM_PUSH
CPLM_BEGIN_TIME
  int nvPrinted=5;

  //Computed number of rows
  int cm = v->nval/lda;
  int n = lda;

	if(name!=NULL)
		printf("Matrix %s of size %d*%d :\n",name,m,n);
	else
		printf("Matrix of size %d*%d :\n",m,n);


  if(sumUp && lda<=nvPrinted*2)
    sumUp = 0;

  if(sumUp){
	  for(int i=0;i<m;i++){
      for(int j=0;j<nvPrinted;j++)
	  	  printf(" %6.2f",v->val[i*n+j]);
      for(int j=0;j<3;j++)
        printf(" .");
      for(int j=n-nvPrinted;j<n;j++)
	  	  printf(" %6.2f",v->val[i*n+j]);
      printf("\n");
    }

    //Handle extra memory storage
    if(cm>m)printf("+++++++++++++++++++++ Ghosted DATA ++++++++++++++++++++++++\n");
    for(int i=m;i<cm;i++){
      for(int j=0;j<nvPrinted;j++)
	  	  printf(" %6.2f",v->val[i*n+j]);
      for(int j=0;j<3;j++)
        printf(" .");
      for(int j=n-nvPrinted;j<n;j++)
	  	  printf(" %6.2f",v->val[i*n+j]);
      printf("\n");
    }

  }else{
	  for(int i=0;i<m;i++){
      for(int j=0;j<n;j++)
	  	  printf(" %6.2f",v->val[i*n+j]);
      printf("\n");
    }

    //Handle extra memory storage
    if(cm>m)printf("+++++++++++++++++++++ Ghosted DATA ++++++++++++++++++++++++\n");
    for(int i=m;i<cm;i++){
      for(int j=0;j<n;j++)
	  	  printf(" %6.2f",v->val[i*n+j]);
      printf("\n");
    }
  }

	printf("\n");
CPLM_END_TIME
CPLM_POP
}








/**
 * \fn void send_DVect(double *vec, int length, int send_to, int tag, MPI_Comm comm)
 * \brief Method which sends a CPLM_IVector_t to a process
 * \param *vec The value array of the vector
 * \param length The size of the vector
 * \param send_to The number of the process which will receive the vector
 * \param tag The tag of the communication
 * \param comm The communicator for MPI
 */
/*Function sends a CPLM_IVector_t to send_to*/
#ifdef MPIACTIVATE
int CPLM_DVectorSend(CPLM_DVector_t *v, int dest, int tag, MPI_Comm comm){
CPLM_PUSH
CPLM_BEGIN_TIME
	int cr;
	//send length of the vector
	cr=MPI_Send(&(v->nval),1,MPI_INT,dest,tag,comm);CPLM_checkMPIERR(cr,"send_length");
	//send data of the vector
	cr=MPI_Send(v->val,v->nval,MPI_DOUBLE,dest,tag,comm);CPLM_checkMPIERR(cr,"send_vec");
CPLM_END_TIME
CPLM_POP
  return cr;
}
#endif




/**
 * \fn int CPLM_DVectorISend(CPLM_IVector_t *vec, int dest, int tag, MPI_Comm comm)
 * \brief Method which sends a CPLM_IVector_t to a process
 * \param *vec    The CPLM_IVector_t sent to dest
 * \param dest    The number of the process which will receive the vector
 * \param tag     The tag of the communication
 * \param comm    The communicator for MPI
 * \return        0 if the CPLM_IVector_t is sent
 */
/*Function sends a CPLM_IVector_t to send_to*/
#ifdef MPIACTIVATE
int CPLM_DVectorISend(CPLM_DVector_t *v, int dest, int tag, MPI_Comm comm, MPI_Request **request){
CPLM_PUSH
CPLM_BEGIN_TIME

  if(*request == NULL)
    *request = (MPI_Request *)malloc(2*sizeof(MPI_Request));
	int cr=0;
	//send length of the vector
	cr=MPI_Isend(&v->nval,1,MPI_INT,dest,tag,comm,&((*request)[0]));CPLM_checkMPIERR(cr,"send_length");

	//send data of the vector
	cr=MPI_Isend(v->val,v->nval,MPI_DOUBLE,dest,tag,comm,&((*request)[1]));CPLM_checkMPIERR(cr,"send_vec");
CPLM_END_TIME
CPLM_POP

  return cr;
}
#endif





/**
 * \fn CPLM_DVector_t recv_DVect(int recv_from, int tag, MPI_Comm comm)
 * \brief Function which manage the reception of a CPLM_IVector_t and return it
 * \param recv_from The number of the process sending the vector
 * \param tag The tag of the communication
 * \param comm The communicator for MPI
 * \return The CPLM_IVector_t received
 */
/*Function returns a CPLM_IVector_t received from recv_from*/
#ifdef MPIACTIVATE
int CPLM_DVectorRecv(CPLM_DVector_t *v, int source, int tag, MPI_Comm comm)
{
CPLM_PUSH
CPLM_BEGIN_TIME

	MPI_Status status;
	int ierr    = 0;
  int length  = 0;

	//receive length of the vector
	ierr = MPI_Recv(&length,
      1,
      MPI_INT,
      source,
      tag,
      comm,
      &status);CPLM_checkMPIERR(ierr,"recv_length");

  if(v->val == NULL)
  {
    ierr = CPLM_DVectorMalloc(v, length);CPLM_CHKERR(ierr);
  }
  else if(v->nval < length)
  {
    ierr = CPLM_DVectorAddSpace(v, length);CPLM_CHKERR(ierr);
  }

	//receive data of the vector
	ierr  = MPI_Recv(v->val,
      v->nval,
      MPI_DOUBLE,
      source,
      tag,
      comm,
      &status);CPLM_checkMPIERR(ierr,"recv_vec");

  v->nval = length;

CPLM_END_TIME
CPLM_POP
	return ierr;
}
#endif






/**
 * \fn int CPLM_DVectorIRecv(CPLM_IVector_t *v, int source, int tag, MPI_Comm comm)
 * \brief Function which manage the reception of a CPLM_IVector_t and return it
 * \param v       The pointer of the CPLM_IVector_t to recv
 * \param source  The number of the process sending the vector
 * \param tag     The tag of the communication
 * \param comm    The communicator for MPI
 * \return Error code
 */
/*Function returns a CPLM_IVector_t received from recv_from*/
/*WARNING : this function has never been tested*/
#ifdef MPIACTIVATE
int CPLM_DVectorIRecv(CPLM_DVector_t *v, int source, int tag, MPI_Comm comm, MPI_Request *request){
CPLM_PUSH
CPLM_BEGIN_TIME

	MPI_Status status;
	int cr;

	//receive length of the vector
	cr=MPI_Irecv(&(v->nval),1,MPI_INT,source,tag,comm,request);CPLM_checkMPIERR(cr,"recv_length");

  MPI_Wait(request,&status);
	cr = CPLM_DVectorMalloc(v, v->nval);CPLM_CHKERR(cr);

	//receive data of the vector
	cr=MPI_Irecv(v->val,v->nval,MPI_DOUBLE,source,tag,comm,request);CPLM_checkMPIERR(cr,"recv_vec");

  //MPI_Wait(&request,&status);

CPLM_END_TIME
CPLM_POP
	return cr;
}
#endif




/**
 * \fn int CPLM_DVectorIRecv(CPLM_IVector_t *v, int source, int tag, MPI_Comm comm)
 * \brief Function which manage the reception of a CPLM_IVector_t and return it
 * \param v       The pointer of the CPLM_IVector_t to recv
 * \param source  The number of the process sending the vector
 * \param tag     The tag of the communication
 * \param comm    The communicator for MPI
 * \return Error code
 */
/*Function returns a CPLM_IVector_t received from recv_from*/
#ifdef MPIACTIVATE
int CPLM_DVectorIRecvConcat( CPLM_DVector_t   *v_io,
                        int         offset,
                        int         source,
                        int         tag,
                        MPI_Comm    comm,
                        int         nvalRecvd,
                        MPI_Request *request)
{
CPLM_PUSH
CPLM_BEGIN_TIME

	MPI_Status status;
	int ierr    = 0;

	//receive nval of the vector
	ierr = MPI_Irecv(&nvalRecvd,
      1,
      MPI_INT,
      source,
      tag,
      comm,
      request);CPLM_checkMPIERR(ierr,"recv_length");

  MPI_Wait(request,&status);

  if( offset + nvalRecvd > v_io->nval )
  {
	  ierr = CPLM_DVectorAddSpace(v_io, nvalRecvd);CPLM_CHKERR(ierr);
  }

	//receive data of the vector
	ierr=MPI_Irecv(v_io->val + offset,
      v_io->nval,
      MPI_DOUBLE,
      source,
      tag,
      comm,
      request);CPLM_checkMPIERR(ierr,"recv_vec");

CPLM_END_TIME
CPLM_POP
	return ierr;
}
#endif





/**
 * \fn int CPLM_DVectorAllGather(CPLM_DVector_t *loc_v, CPLM_DVector_t *glo_v, MPI_Comm comm);
 * \brief All gather local vectors (loc_v) into a global one (glo_v) which is
 *        sent to all procs.
 * \param loc_v: the local (to one process) vector
 * \param glo_v: the global CPLM_IVector_t that gather loc_v vectors
 * \param comm : the communicator for MPI
 * \return the error code from MPI
 */
#ifdef MPIACTIVATE
int CPLM_DVectorAllGather(CPLM_DVector_t *loc_v, CPLM_DVector_t *glo_v, MPI_Comm comm){
CPLM_PUSH
CPLM_BEGIN_TIME

  int ierr, size_comm;
  CPLM_IVector_t sizes;
  CPLM_IVector_t disps;

  //get the size of the communicator
  ierr = MPI_Comm_size(comm, &size_comm);
  CPLM_checkMPIERR(ierr,"comm_size");

  //gather the sizes of the local vectors
  ierr = CPLM_IVectorMalloc(&sizes,size_comm);CPLM_CHKERR(ierr);

	ierr = MPI_Allgather(&(loc_v->nval), 1, MPI_INT, sizes.val, 1, MPI_INT, comm);
  CPLM_checkMPIERR(ierr,"allgather_sizes");

  //constructs disps to have contiguous datas in glo_v
  ierr = CPLM_IVectorMalloc(&disps,size_comm);CPLM_CHKERR(ierr);
  disps.val[0] = 0;
  glo_v->nval = sizes.val[size_comm - 1];
  for (int i=1; i < size_comm; i++) {
    disps.val[i] = sizes.val[i-1] + disps.val[i-1];
    glo_v->nval += sizes.val[i-1];
  }

	ierr = CPLM_DVectorMalloc(glo_v, glo_v->nval);CPLM_CHKERR(ierr);

	//gather loc_v into glo_v (contiguously)
	ierr = MPI_Allgatherv(loc_v->val, loc_v->nval, MPI_DOUBLE, glo_v->val, sizes.val, disps.val, MPI_DOUBLE, comm);
  CPLM_checkMPIERR(ierr,"allgather_vec");

  // Free memory
  CPLM_IVectorFree(&disps);
  CPLM_IVectorFree(&sizes);
CPLM_END_TIME
CPLM_POP
	return ierr;
}
#endif





/*Function returns True if v1 and v2 contain the same value*/
int CPLM_DVectorIsSame(CPLM_DVector_t *v1, CPLM_DVector_t *v2)
{
CPLM_PUSH
CPLM_BEGIN_TIME
  int ok = CPLM_TRUE;

  if(v1->nval != v2->nval)
  {
    fprintf(stderr,"Error of structure\n%d != %d\n", v1->nval, v2->nval);
    return !ok;
  }
  for(int i = 0;  i < v1->nval; i++)
  {
    if(fabs(v1->val[i]-v2->val[i])  > CPLM_EPSILON)
    {
      fprintf(stderr,"Error of value\n%f != %f\n", v1->val[i], v2->val[i]);
      return !ok;
    }
  }
CPLM_END_TIME
CPLM_POP
  return ok;
}





int VectorIsNAN(CPLM_DVector_t *t)
{
CPLM_PUSH
CPLM_BEGIN_TIME
  int ok = CPLM_TRUE;

  for(int i = 0; i < t->nval; i++)
    if(t->val[i] != t->val[i])
      return !ok;

CPLM_END_TIME
CPLM_POP
  return ok;
}





/**
  *
  * \param size The size of the vector
  * Computation complexity : 2 * number of lines in fileName
  * Memory complexity      : length of tmp + size of CPLM_IVector_t * size of double
**/
int CPLM_DVectorLoad(const char *fileName, CPLM_DVector_t *buf, int size)
{
CPLM_PUSH
CPLM_BEGIN_TIME
  FILE *fd = NULL;
  int length  = 512;
  int nbLine  = size;
  int cpt     = 0;
  int v       = 0;
  int t       = 0;
  int begin   = 0;
  int nread   = 0;
  int ierr    = 0;
  double last = 0.0;
  char *tmp   = NULL;

  tmp = (char*)malloc(length * sizeof(char));
  CPLM_ASSERT(tmp != NULL);

  fd  = fopen(fileName,"r");
  if(!fd)
  {
    fprintf(stderr,"Error, impossible to load %s\n",fileName);
CPLM_END_TIME
CPLM_POP
    return 1;
  }

  if(!nbLine)
  {
    //avoid comments
    while(fgets(tmp,length,fd))
    {
      if(tmp[0] == '%')
        continue;
      else
        break;
    }

    //test if number of lines is in the file
    cpt = sscanf(tmp,"%d %d",&v,&t);
    if(cpt == 2)
      nbLine = v;

    if(!nbLine)
    {
      nbLine++;
      while(fgets(tmp,length,fd))
      {
        nbLine++;
      }
    }

    fseek(fd,0,SEEK_SET);
  }

  if(buf->val == NULL)
  {
    ierr = CPLM_DVectorMalloc(buf, nbLine);CPLM_CHKERR(ierr);
  }

  if(buf->nval < nbLine)
  {
    ierr = CPLM_DVectorRealloc(buf, nbLine);CPLM_CHKERR(ierr);
  }

  //Ignore comments
  while(fgets(tmp,length,fd))
  {
    if(tmp[0]=='%')
      continue;
    else
      break;
  }

  //Check if the size is given
  cpt = sscanf(tmp,"%d %d",&v,&t);
  if(cpt == 1)
  {
    buf->val[0] = atof(tmp);
    begin = 1;
    nread = 1;
  }

  //Read data
  for(int i = begin; i < nbLine; i++)
  {
    nread += fscanf(fd,"%lf", &buf->val[i]);
  }

  CPLM_debug("%d values read\n",nread);
  CPLM_ASSERT(fscanf(fd,"%lf", &last) == EOF);

  free(tmp);
  fclose(fd);
CPLM_END_TIME
CPLM_POP
  return ierr;
}




#ifdef MPIACTIVATE

int CPLM_DVectorLoadAndDistribute(const char *fileName,
                             CPLM_DVector_t *bufLocal_out,
                             CPLM_IVector_t* pos_in,
                             MPI_Comm comm)
{
CPLM_PUSH
CPLM_BEGIN_TIME
  FILE *fd  = NULL;
  int length  = 512;
  int cpt     = 0;
  int v       = 0;
  int t       = 0;
  int ierr    = 0;
  int nread   = 0;
  int rank    = 0;
  int size    = 0;
  char *tmp = NULL;
  //Avoid warning unused variable
  nread++;

  MPI_Comm_rank(comm,&rank);
  MPI_Comm_size(comm,&size);

  // root is the last process in order to reuse bufLocal_out
  if (rank == size - 1)
  {
    tmp = (char*) malloc(length*sizeof(char));

    fd = fopen(fileName,"r");
    if (!fd)
    {
      fprintf(stderr,"Error, impossible to load %s\n",fileName);
      return EXIT_FAILURE;
    }

    while (fgets(tmp,length,fd))
    {
      if (tmp[0] == '%')
        continue;
      else
        break;
    }

    // Loop on the processes
    for (int iProc = 0; iProc < size; ++iProc)
    {
      ierr = CPLM_DVectorMalloc(bufLocal_out, pos_in->val[iProc+1] - pos_in->val[iProc]);CPLM_CHKERR(ierr);
      int begin = 0;
      cpt = sscanf(tmp,"%d %d",&v,&t);
      if (cpt == 1)
      {
        bufLocal_out->val[0] = atof(tmp);
        begin = 1;
      }
      // Fill local buffer
      for (int i = begin; i < bufLocal_out->nval; i++)
        nread = fscanf(fd,"%lf",&bufLocal_out->val[i]);

      // Send local buffer and free it
      if (iProc < size - 1)
      {
        ierr = CPLM_DVectorSend(bufLocal_out,iProc,0,comm);CPLM_checkMPIERR(ierr,"DVectorLoadAndDistribute::send");
        CPLM_DVectorFree(bufLocal_out);
      }
    }
    free(tmp);
    fclose(fd);
  }
  else
  {
    ierr = CPLM_DVectorRecv(bufLocal_out,size-1,0,comm);CPLM_checkMPIERR(ierr,"DVectorLoadAndDistribute::recv");
  }
CPLM_END_TIME
CPLM_POP
  return EXIT_SUCCESS;
}

#endif // MPIACTIVATE

/**
  *
  *
  * Computation complexity : size of the vector
  * Memory complexity      : None
**/
int CPLM_DVectorSave(CPLM_DVector_t *v,const char *fileName, const char *header)
{
CPLM_PUSH
CPLM_BEGIN_TIME

  FILE *fd = NULL;

  CPLM_ASSERT(v->nval   >  0);
  CPLM_ASSERT(v->val   !=  NULL);

  fd=fopen(fileName,"w");
  if(!fd)
  {
    fprintf(stderr,"Error, impossible to create %s\n",fileName);
CPLM_END_TIME
CPLM_POP
    return 1;
  }

  fprintf(fd,"%%%%%s\n%d 1\n",header, v->nval);

  for(int i = 0; i < v->nval; i++)
  {
    fprintf(fd,"%.16e\n",v->val[i]);
  }

  fclose(fd);

CPLM_END_TIME
CPLM_POP
  return 0;
}


void CPLM_DVectorTestFunction(){
CPLM_PUSH
CPLM_BEGIN_TIME

#ifndef TEST
	printf("To activate this method, please recompile it with TEST defined\n");
#else
  printf("This function has to be done\n");

//  int cr=0,ok=0;;
//  CPLM_DVector_t Dbuf,Dcomp;
//  Dcomp.nv=7;
//  Dcomp.list=malloc(Dcomp.nv*sizeof(double));
//  Dcomp.list[0]=-0.0001;
//  Dcomp.list[1]=0.1167;
//  Dcomp.list[2]=-0.2333;
//  Dcomp.list[3]=0.1167;
//  Dcomp.list[4]=-0.4993128;
//
//  Dcomp.list[5]=0.3435885;
//  Dcomp.list[6]=0.7467878;
//
//  CPLM_IVector_t buf,comp;
//
//  CPLM_IVector_t v0, v1, v2, v3, v4;
//  v0.nv=0; v0.list=NULL;
//  v1.nv=v2.nv=v3.nv=5;
//  v1.list=malloc(v1.nv*sizeof(int));
//  v2.list=malloc(v2.nv*sizeof(int));
//  v3.list=malloc(v3.nv*sizeof(int));
//  for(int i=0;i<v1.nv;i++)
//    v1.list[i]=v2.list[i]=i;
//  for(int i=0;i<v3.nv;i++)
//    v3.list[i]=v3.nv-i-1;
//  v4.nv=11;
//  v4.list=malloc(v4.nv*sizeof(int));
//  for(int i=0;i<v4.nv;i++)
//    v4.list[i]=0;
//
//  //match same vector, different vectors but same size, different vectors with different size, a CPLM_IVector_t with a null CPLM_IVector_t AND a null CPLM_IVector_t with null vector
//  cr = isSameVector(&v1,&v2) || !isSameVector(&v1,&v3) || !isSameVector(&v2,&v4) || !isSameVector(&v0,&v4) || isSameVector(&v0,&v0); ok=ok||cr;
//  if(cr) eprintf("isSameVector");
//
//  cr = !loadVector("TestDir/foo",&buf,0) || loadVector("TestDir/testLoadVector.vec", &buf, 0) || isSameVector(&v1,&buf);ok=ok||cr;
//  if(cr) eprintf("loadVector");
//
//  cr = !saveVector(&v0,"TestDir/foo") || saveVector(&buf,"TestDir/erase_file") || loadVector("TestDir/erase_file", &comp, 0) || isSameVector(&buf,&comp);ok=ok||cr;
//  if(cr) eprintf("saveVector");
//
//  CPLM_IVector_t perm;
//  VectorCopy(&v3,&perm);
//  cr = isSameVector(&v3,&perm);
//  if(cr) eprintf("copy");
//
//  cr = isSameDVector(&Dcomp, &Dcomp);
//  if(cr) eprintf("isSameDVector");
//
//  cr = loadDVector("TestDir/b1_ss_b.mtx",&Dbuf, 0) || isSameDVector(&Dbuf, &Dcomp);
//  if(cr) eprintf("loadDVector");
//
//
//  if(!ok) printf("Tests of Object CPLM_IVector_t are ok\n");
//
//  free(v1.list);
//  free(v2.list);
//  free(v3.list);
//  free(v4.list);
/*  free(perm.list);*/
#endif
CPLM_END_TIME
CPLM_POP

}











int CPLM_DVectorAddSpace(CPLM_DVector_t *v_out, int length)
{
CPLM_PUSH
CPLM_BEGIN_TIME

  CPLM_ASSERT(v_out      != NULL);
  CPLM_ASSERT(v_out->val != NULL);

  v_out->nval  += length;
  v_out->val    = (double*)realloc(v_out->val,v_out->nval*sizeof(double));

CPLM_END_TIME
CPLM_POP
  return !(v_out->val != NULL);
}




int CPLM_DVectorRandom(CPLM_DVector_t *v, int generatorSeed){

  int ierr  = 0;

  CPLM_ASSERT(v->val != NULL);

  srand(generatorSeed);

  for(int i=0;i<v->nval;i++)
    v->val[i] = ((double) rand() / (double) RAND_MAX);


  return ierr;
}

int CPLM_DVectorConstant(CPLM_DVector_t* v, double value){

  int ierr = 0;

  CPLM_ASSERT(v->val != NULL);

  for(int i=0; i<v->nval;i++)
    v->val[i] = value;


  return ierr;
}





int CPLM_DVectorCopy(CPLM_DVector_t *v_in, CPLM_DVector_t *v_out)
{
CPLM_PUSH
  int ierr = 0;

  if(v_out->val == NULL)
  { 
  	ierr = CPLM_DVectorMalloc(v_out, v_in->nval);CPLM_CHKERR(ierr);
  }
  else if(v_in->nval > v_out->nval)
  {
  	ierr = CPLM_DVectorRealloc(v_out, v_in->nval);CPLM_CHKERR(ierr);
  }
  memcpy(v_out->val, v_in->val, v_in->nval * sizeof(double));
  
CPLM_POP
  return ierr;
}





int CPLM_DVectorCreate(CPLM_DVector_t *v, int length, double *val)
{
CPLM_PUSH
CPLM_BEGIN_TIME

  int ierr = 0;

  CPLM_ASSERT(v    != NULL);
  CPLM_ASSERT(val  != NULL);

  if(v->val == NULL)
  {
    ierr = CPLM_DVectorMalloc(v, length);CPLM_CHKERR(ierr);
  }
  else if(v->nval < length)
  {
    ierr = CPLM_DVectorRealloc(v, length);CPLM_CHKERR(ierr);
  }

  memcpy(v->val, val, length * sizeof(double));

CPLM_END_TIME
CPLM_POP
  return ierr;
}


int CPLM_DVectorCreateFromPtr(CPLM_DVector_t *v, int length, double *val){

  int ierr = 0;

  v->nval = length;
  v->val  = val;

  return ierr;
}

/*
 * \fn int VectorCopyData(CPLM_IVector_t *v1, CPLM_IVector_t *v2)
 * \brief This function copies data of v1 in v2. Condition v2 memory space is already allocated and have the same size as v1
 * \param *v1     (in)        The CPLM_IVector_t whose data will be copied into v2
 * \param *v2     (in/out)    The CPLM_IVector_t where the data will be copied
 * \return Error code
 * Computation complexity : O(size of v2)
 * Memory complexity : 0
 */
int CPLM_DVectorCopyData(CPLM_DVector_t *v1, CPLM_DVector_t *v2){

  int ierr = 0;

  CPLM_ASSERT(v2->nval==v1->nval);
  CPLM_ASSERT(v1->val != NULL);
  CPLM_ASSERT(v2->val != NULL);

  memcpy(v2->val,v1->val,v1->nval*sizeof(double));

  return ierr;

}

int CPLM_DVectorConcatInPlace(CPLM_DVector_t *v1, CPLM_DVector_t *v2, const char c){

  int ierr  = 0;
  int nv1   = v1->nval;

  ierr = CPLM_DVectorAddSpace(v1,v2->nval);CPLM_CHKERR(ierr);
  //Concat at right
  if(c == 'R'){
    memcpy(&(v1->val[nv1]),v2->val,v2->nval*sizeof(double));

  }else if(c == 'L'){//concat at left
    memcpy(&(v1->val[v2->nval]),v1->val,nv1*sizeof(double));
    memcpy(&(v1->val[0]),v2->val,v2->nval*sizeof(double));

  }else
    ierr = 1;

  return ierr;

}





int CPLM_DVectorSwap(CPLM_DVector_t *v1, CPLM_DVector_t *v2)
{
CPLM_PUSH
  int ierr = 0;
  double *swap = NULL;

  swap    = v1->val;
  v1->val = v2->val;
  v2->val = swap;

CPLM_POP
  return ierr;
}




int CPLM_DVector2NormSquared(CPLM_DVector_t* v_in, double* norm)
{
  int ierr = 0;
  CPLM_ASSERT(norm != NULL);
  *norm = 0.0;
  for (int i = 0; i < v_in->nval; ++i)
    *norm += pow(v_in->val[i],2);
  return ierr;
}





int CPLM_DVector2Norm(CPLM_DVector_t* v_in, double* norm)
{
  int ierr = CPLM_DVector2NormSquared(v_in,norm);
  *norm = sqrt(*norm);
  return ierr;
}





int CPLM_DVectorGetNorm1(CPLM_DVector_t* v_in, double* norm1)
{
CPLM_PUSH
  int ierr = 0;
  double sum = 0.0;

  CPLM_ASSERT(v_in->nval > 0);
  CPLM_ASSERT(v_in->val  != NULL);
  CPLM_ASSERT(norm1      != NULL);
  
  for(int i = 0; i < v_in->nval; i++)
  {
    sum += fabs(v_in->val[i]);
  }
  *norm1 = sum;

CPLM_POP
  return ierr;
}





int DVectorGetNormInf(CPLM_DVector_t* v_in, double* normInf)
{
CPLM_PUSH
  int ierr = 0;
  double max = 0.0;

  CPLM_ASSERT(v_in->nval > 0);
  CPLM_ASSERT(v_in->val  != NULL);
  CPLM_ASSERT(normInf    != NULL);
  
  max = v_in->val[0];
  for(int i = 1; i < v_in->nval; i++)
  {
    max = CPLM_MAX(max, fabs(v_in->val[i]));
  }
  *normInf = max;

CPLM_POP
  return ierr;
}





int CPLM_DVectorToMatDense(CPLM_DVector_t* v_in, CPLM_Mat_Dense_t* A_out, int m, int n, CPLM_storage_type_t stor_type)
{
  int ierr;
  ierr = CPLM_MatDenseSetInfo(A_out, m, n, m, n, stor_type);
  ierr = CPLM_MatDenseFill(A_out, v_in->val, v_in->nval);
  return ierr;
}





int CPLM_DVectorAbsDiff(CPLM_DVector_t *v_in, CPLM_DVector_t *w_in, double *sum)
{
  int ierr = 0;
  double lsum = 0.0;
  
  CPLM_ASSERT(v_in->nval == w_in->nval);

  for(int i = 0; i < CPLM_MIN(v_in->nval,w_in->nval); i++)
    lsum += fabs(v_in->val[i]) - fabs(w_in->val[i]);

  *sum = lsum;

  return ierr;
}





/*========================================
 *
 *        Memory check functions
 *
 *========================================*/




int CPLM_DVectorMallocChk( CPLM_DVector_t   *v_out,
                      int         length,
                      const char  *file,
                      int         line,
                      const char  *varName)
{
CPLM_PUSH
CPLM_BEGIN_TIME

  CPLM_ASSERT(v_out      != NULL);
  CPLM_ASSERT(v_out->val == NULL);

  v_out->nval = length;
  v_out->val  = (double*)CPLM_malloc(v_out->nval * sizeof(double),
      file,
      line,
      varName);

CPLM_END_TIME
CPLM_POP
  return !(v_out->val != NULL);
}





int CPLM_DVectorCallocChk( CPLM_DVector_t   *v_out,
                      int         length,
                      const char  *file,
                      int         line,
                      const char  *varName)
{
CPLM_PUSH
CPLM_BEGIN_TIME
  
  CPLM_ASSERT(v_out      != NULL);
  CPLM_ASSERT(v_out->val == NULL);

  v_out->nval = length;
  v_out->val  = (double*)CPLM_calloc(v_out->nval,
      sizeof(double),
      file,
      line,
      varName);

CPLM_END_TIME
CPLM_POP
  return !(v_out->val != NULL);
}





int CPLM_DVectorReallocChk(CPLM_DVector_t   *v_io,
                      int         length,
                      const char  *file,
                      int         line,
                      const char  *varName)
{
CPLM_PUSH
CPLM_BEGIN_TIME

  CPLM_ASSERT(v_io      != NULL);
  CPLM_ASSERT(v_io->val != NULL);

  v_io->nval = length;
  v_io->val  = (double*)CPLM_realloc(v_io->val,
      v_io->nval * sizeof(double),
      file,
      line,
      varName);

CPLM_END_TIME
CPLM_POP
  return !(v_io->val != NULL);
}





void CPLM_DVectorFreeChk(CPLM_DVector_t   *v_io,
                    const char  *file,
                    int         line,
                    const char  *varName)
{
CPLM_PUSH

  if(v_io) 
  {
    if(v_io->val)
    {
      CPLM_free(v_io->val, file, line, varName);
    }
    v_io->nval = 0;
    v_io->val  = NULL;
  }

CPLM_POP
}





/*
 *  Memory Allocation
 */
#ifndef MEMCHECK
int CPLM_DVectorMalloc(CPLM_DVector_t   *v_out,
                  int         length)
{
CPLM_PUSH
CPLM_BEGIN_TIME

  CPLM_ASSERT(v_out      != NULL);
  CPLM_ASSERT(v_out->val == NULL);

  v_out->nval = length;
  v_out->val  = (double*)malloc(v_out->nval * sizeof(double));

CPLM_END_TIME
CPLM_POP
  return !(v_out->val != NULL);
}





int CPLM_DVectorCalloc( CPLM_DVector_t   *v_out,
                    int         length)
{
CPLM_PUSH
CPLM_BEGIN_TIME
  
  CPLM_ASSERT(v_out      != NULL);
  CPLM_ASSERT(v_out->val == NULL);

  v_out->nval = length;
  v_out->val  = (double*)calloc(v_out->nval, sizeof(double));

CPLM_END_TIME
CPLM_POP
  return !(v_out->val != NULL);
}





int CPLM_DVectorRealloc( CPLM_DVector_t   *v_io,
                    int         length)
{
CPLM_PUSH
CPLM_BEGIN_TIME

  CPLM_ASSERT(v_io      != NULL);
  CPLM_ASSERT(v_io->val != NULL);

  v_io->nval = length;
  v_io->val  = (double*)realloc(v_io->val, v_io->nval * sizeof(double));

CPLM_END_TIME
CPLM_POP
  return !(v_io->val != NULL);
}





void CPLM_DVectorFree(CPLM_DVector_t   *v_io)
{
CPLM_PUSH

  if(v_io)
  {
    if(v_io->val)
    {
      free(v_io->val);
    }
    v_io->nval  = 0;
    v_io->val   = NULL;
  }

CPLM_POP
}
#endif
