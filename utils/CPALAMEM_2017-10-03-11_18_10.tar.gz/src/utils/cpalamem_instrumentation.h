/*
* This file contains functions used to manage the library : initialization, finalization
*
* Authors : Sebastien Cayrols
* Email   : sebastien.cayrols@[(gmail.com) | (inria.fr)]
*/
#ifndef CPALAMEM_INSTRUMENTATION_H
#define CPALAMEM_INSTRUMENTATION_H

#include <stdio.h>
#include <cpalamem_handler.h>
#include <cpalamem_timer.h>
#include <cpalamem_stacktrace.h>
#include <cpalamem_memcheck.h>
#include <cpalamem_utils.h>
#include <float.h>

#define CPLM_EPSILON DBL_EPSILON
#define CPLM_TRUE 1
#define CPLM_BUFSIZE 1024
#define CPLM_BANNERSIZE CPLM_BUFSIZE * 2
#define CPLM_LIBNAME "CPALAMEM"

/*
 * Redefine MIN and MAX to avoid problem of crossdefinition
 */
#define CPLM_MAX(_a, _b) ((_a) > (_b) ? (_a) : (_b))
#define CPLM_MIN(_a, _b) ((_a) < (_b) ? (_a) : (_b))

void CPLM_PrintBanner(FILE* fd);

void CPLM_Init(int *argc, char ***argv);

void CPLM_Finalize();

void CPLM_SetEnv();

void CPLM_GetEnv();

void CPLM_ResetTimer();

void CPLM_PrintTimer(const char* filename);

#endif /*CPALAMEM_INSTRUMENTATION_H*/
