/*
* This file contains functions used for tracking the stacktrace
*
* Authors : Sebastien Cayrols
* Email   : sebastien.cayrols@[(gmail.com) | (inria.fr)]
*/
/**
 * \file cpalamem_instrumentation.c
 * \brief Some functions used to develop and debug some codes
 * \author Sebastien Cayrols
 * \version 0.1
 * \date 21 june 2013
 *
 *
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef MPIACTIVATE
  #include <mpi.h>
#endif

#include <cpalamem_macro.h>
#include <cpalamem_stacktrace.h>
#include <cpalamem_handler.h>

/**************************************************************
*
*   GLOBAL VARIABLES
*
***************************************************************/
//Contain current stack
CPLM_Stack_t *curStack  = NULL;

//Addtitional variables
int pos_stack   = 0; //Used in print part

/**************************************************************
*
*                     STACKTRACE MANAGEMENT
*
***************************************************************/
void CPLM_pushStack(const char * format, ...)
{
  va_list v;
  va_start(v,format);

  if(curStack == NULL)
  {
    CPLM_initStack();
  }

#ifdef STACKTRACEPRINT
  char msg[1024];
  int rank = 0;

  #ifdef MPIACTIVATE
    MPI_Comm_rank(MPI_COMM_WORLD,&rank);
  #endif

  snprintf(msg,sizeof(msg),"%*s" "[Proc: %u]" "%s\n",pos_stack,"",rank,format);
  vprintf(msg,v);

  va_end(v);
  pos_stack+=2;
#endif

  //Additional part
#ifdef MEMCHECKCONSUMPTION
  char fun[128];
  char buf[1024];
  int funLen    = 0;
  int allFunLen = 0;
  CPLM_Stack_t *tmp  = NULL;

  tmp = (CPLM_Stack_t*)malloc(sizeof(CPLM_Stack_t));
  CPLM_ASSERT(tmp != NULL);

  //Get function name
  va_start(v,format);

  snprintf(fun,sizeof(fun),"%s:",format);
  vsnprintf(buf,sizeof(buf),fun,v);

  va_end(v);

  funLen      = strlen(buf);

  //Create new function space
  allFunLen = strlen(curStack->allFun);

  tmp->allFun = (char*)malloc((allFunLen+funLen+1)*sizeof(char));
  CPLM_ASSERT(tmp->allFun != NULL);

  //Copy new function name after all previous ones
  memcpy(tmp->allFun,curStack->allFun,allFunLen+1);
  tmp->fun    = tmp->allFun + allFunLen;
  memcpy(tmp->fun,buf,funLen+1);

  tmp->next   = curStack;

  curStack = tmp;
#endif

}





void CPLM_popStack()
{
#ifdef STACKTRACEPRINT
  pos_stack-=2;
#endif

  //Additional part
#ifdef MEMCHECKCONSUMPTION
  CPLM_Stack_t *tmp = NULL;
  tmp = curStack->next;
  free(curStack->allFun);
  free(curStack);
  curStack = tmp;
#endif
}





void CPLM_initStack()
{
  pos_stack = 2;

  //Additional part
#ifdef MEMCHECKCONSUMPTION
  if(curStack == NULL)
  {
    printf("Initialisation of the stack ...\n");
    char msg[1024];
#ifdef MPIACTIVATE
    int rank = 0;
    MPI_Comm_rank(MPI_COMM_WORLD,&rank);
    snprintf(msg,sizeof(msg),"[ROOT:%u]:",rank);
#else
    memcpy(msg,"[ROOT]:",strlen("[ROOT]:"+1);
#endif
    curStack = (CPLM_Stack_t*) malloc(sizeof(CPLM_Stack_t));
    CPLM_ASSERT(curStack != NULL);
    curStack->allFun = (char*)malloc((strlen(msg)+1)*sizeof(char));
    curStack->fun    = curStack->allFun;
    memcpy(curStack->fun,msg,strlen(msg)+1);
    curStack->next   = NULL;
  }
#endif
}
