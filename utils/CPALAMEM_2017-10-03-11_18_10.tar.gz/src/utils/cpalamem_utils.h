/*
* This file contains functions used as tools
*
* Authors : Sebastien Cayrols
* Email   : sebastien.cayrols@[(gmail.com) | (inria.fr)]
*/
#ifndef CPALAMEM_UTILS_H
#define CPALAMEM_UTILS_H

#include <stdarg.h>

#ifdef MPIACTIVATE
  double top(double t1, const char info[], int rank);
#else
  time_t top(time_t t1, const char info[], int rank);
#endif

void CPLM_extendName(char *fullFileName,
                char *pre_extension,
                char *post_extension,
                char **newName);

#define CPLM_myprintf(_format, _args...) CPLM_myfprintf(stdout, (_format), ##_args)
extern void CPLM_myfprintf(FILE *fd, const char * format, ...);

#endif /*CPALAMEM_UTILS_H*/
