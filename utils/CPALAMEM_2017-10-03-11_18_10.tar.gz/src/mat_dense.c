/*
* This file contains functions used to manipulate dense matrices
*
* Authors : Sebastien Cayrols
*         : Olivier Tissot
* Email   : sebastien.cayrols@[(gmail.com) | (inria.fr)]
*         : olivier.tissot@inria.fr
*/

/******************************************************************************/
/*                                  INCLUDE                                   */
/******************************************************************************/
/* std */
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
/* matcsr */
#include "cpalamem_macro.h"
#include "mat_dense.h"
#include "MPIutils.h"
#include "cpalamem_instrumentation.h"
/******************************************************************************/

/******************************************************************************/
/*                                    CODE                                    */
/******************************************************************************/
int CPLM_MatDenseInit(CPLM_Mat_Dense_t* A_out, CPLM_Info_Dense_t info)
{
CPLM_PUSH
  A_out->info = info;
  A_out->val  = NULL;
CPLM_POP
  return 0; // Success
}










int CPLM_MatDenseCreate(CPLM_Mat_Dense_t* A, CPLM_Info_Dense_t info)
{
CPLM_PUSH
CPLM_BEGIN_TIME
  int ierr = 0;
  ierr = CPLM_MatDenseInit(A, info);CPLM_CHKERR(ierr);
  ierr = CPLM_MatDenseMalloc(A);CPLM_CHKERR(ierr);
CPLM_END_TIME
CPLM_POP
  return ierr;
}





int CPLM_MatDenseCreateFromPtr(CPLM_Mat_Dense_t *A_io, double *val)
{
CPLM_PUSH
  int ierr = 0;

  A_io->val = val;

CPLM_POP
  return ierr;
}





int CPLM_MatDenseCreateZero(CPLM_Mat_Dense_t* A, CPLM_Info_Dense_t info)
{
CPLM_PUSH
CPLM_BEGIN_TIME
  int ierr = 0;

  ierr = CPLM_MatDenseInit(A, info);CPLM_CHKERR(ierr);
  ierr = CPLM_MatDenseCalloc(A);CPLM_CHKERR(ierr);
CPLM_END_TIME
CPLM_POP
  return ierr;
}





int CPLM_MatDenseCopy(CPLM_Mat_Dense_t* A_in, CPLM_Mat_Dense_t* B_out)
{
CPLM_PUSH
CPLM_BEGIN_TIME

  int ierr = 0;

	if(A_in->info.stor_type == COL_MAJOR)
	{
		CPLM_ASSERT(A_in->info.lda == A_in->info.m);
	}
	else
	{
		CPLM_ASSERT(A_in->info.lda == A_in->info.n);
	}
	if (B_out->val == NULL)
  {
    B_out->info = A_in->info;
    ierr = CPLM_MatDenseMalloc(B_out);CPLM_CHKERR(ierr);
  }
  else if (!CPLM_MatDenseIsSameLocalInfo(A_in,B_out))
  {
    B_out->info = A_in->info;
    ierr = CPLM_MatDenseRealloc(B_out);CPLM_CHKERR(ierr);
  }

  memcpy(B_out->val, A_in->val, B_out->info.m * B_out->info.n * sizeof(double));

CPLM_END_TIME
CPLM_POP
  return ierr;
}





//Function copies nval data from val into matDense A
int CPLM_MatDenseFill(CPLM_Mat_Dense_t* A, double* val, int nval) {
  int ierr = 0;
  if (A->val == NULL){
    ierr = CPLM_MatDenseMalloc(A);CPLM_CHKERR(ierr);
  }
  CPLM_ASSERT(A->info.m*A->info.n<=nval);
  memcpy(A->val,val,nval*sizeof(double));
  return ierr;
}





int CPLM_MatDenseAddRows(CPLM_Mat_Dense_t* A_io, int nbRowToAdd)
{
CPLM_PUSH
  int ierr = 0;

  if (A_io->info.stor_type == COL_MAJOR)
  {
    CPLM_Abort("Warning: Rows are added to a COL_MAJOR matrix(A(i,j) is not the same anymore...)\n");
  }
  A_io->info.m     +=  nbRowToAdd;
  A_io->info.nval  =   (A_io->info.m)*(A_io->info.n);

  ierr = CPLM_MatDenseRealloc(A_io);CPLM_CHKERR(ierr);
CPLM_POP
  return ierr;
}





int CPLM_MatDenseAddCols(CPLM_Mat_Dense_t* A_io, int nbColToAdd)
{
CPLM_PUSH
  int ierr = 0;


  if (A_io->info.stor_type == ROW_MAJOR)
  {
    CPLM_Abort("Cols are added to a ROW_MAJOR matrix (A(i,j) is not the same anymore...)\n");
  }

  A_io->info.n     +=  nbColToAdd;
  A_io->info.nval  =   (A_io->info.m)*(A_io->info.n);

  ierr = CPLM_MatDenseRealloc(A_io);CPLM_CHKERR(ierr);
CPLM_POP
  return ierr;
}





int CPLM_MatDenseToDVector(CPLM_Mat_Dense_t* A_in, CPLM_DVector_t* v_out)
{
  int ierr = CPLM_DVectorCreate(v_out, (A_in->info.m)*(A_in->info.n), A_in->val);
  return ierr;
}





int CPLM_MatDenseConstant(CPLM_Mat_Dense_t* A, double value)
{
  int ierr = 0;

  if(A->val == NULL)
  {
    ierr = CPLM_MatDenseMalloc(A);CPLM_CHKERR(ierr);
  }
  // memset does not work here because val is an array of double AND memset uses char only
  for (int i = 0; i < (A->info.m)*(A->info.n); i++)
    A->val[i] = value;
  return ierr;
}





int CPLM_MatDenseSetZeros(CPLM_Mat_Dense_t* A_io)
{
  int ierr = 0;

  if(A_io->val == NULL)
  {
    ierr = CPLM_MatDenseCalloc(A_io);CPLM_CHKERR(ierr);
  }
  else
  {
    memset(A_io->val, 0, A_io->info.nval * sizeof(double));
  }
  return ierr;
}





int CPLM_MatDenseRandom(CPLM_Mat_Dense_t* A_out, int generatorSeed)
{
CPLM_PUSH
CPLM_BEGIN_TIME

  int ierr = 0;
  if (A_out->val == NULL)
  {
    ierr = CPLM_MatDenseMalloc(A_out);CPLM_CHKERR(ierr);
  }
  srand(generatorSeed);
  for (int i = 0; i < (A_out->info.m)*(A_out->info.n); i++)
    A_out->val[i] = ((double) rand() / (double) RAND_MAX);

CPLM_END_TIME
CPLM_POP
  return ierr;
}





int CPLM_MatDenseVrtlConcat(CPLM_Mat_Dense_t *A, CPLM_Mat_Dense_t *B, CPLM_IVector_t *posB){
  int ierr = 0;

  if(A->info.stor_type != B->info.stor_type){
    fprintf(stderr,"Warning, Matrix A and Matrix B are not stored in the same way i.e. A.stor_type=%d and B.stor_type=%d\n",A->info.stor_type, B->info.stor_type);
    ierr = 1;
    return ierr;
  }
  if(A->info.stor_type == ROW_MAJOR){
    fprintf(stderr,"Warning, ROW_MAJOR not implemented\n");
    ierr = 1;
    return ierr;
  }
  CPLM_ASSERT(A->info.m ==  B->info.m);

  if(posB->val == NULL){
    ierr = CPLM_IVectorCalloc(posB,3);CPLM_CHKERR(ierr);
    posB->val[1] = A->info.m*A->info.n;
  }else{
    ierr = CPLM_IVectorRealloc(posB,posB->nval+1);CPLM_CHKERR(ierr);
  }

  //No assumption about B global structure
  if(A->info.n == B->info.N){
    A->info.N +=  B->info.n;
  }
  A->info.n +=  B->info.n;

  ierr = CPLM_MatDenseRealloc(A);CPLM_CHKERR(ierr);

  memcpy(A->val+posB->val[posB->nval-2], B->val, B->info.m*B->info.n*sizeof(double));

  posB->val[posB->nval-1] = A->info.m*A->info.n;

  return ierr;
}






int CPLM_MatDenseReplaceColBlock(CPLM_Mat_Dense_t *A,CPLM_Mat_Dense_t *B, CPLM_IVector_t *posB, int numBlock){

  int ierr = 0;

  if(A->info.stor_type != B->info.stor_type){
    fprintf(stderr,"Warning, Matrix A and Matrix B are not stored in the same way i.e. A.stor_type=%d and B.stor_type=%d\n",A->info.stor_type, B->info.stor_type);
    ierr = 1;
    return ierr;
  }
  if(A->info.stor_type == ROW_MAJOR){
    fprintf(stderr,"Warning, ROW_MAJOR not implemented\n");
    ierr = 1;
    return ierr;
  }
  CPLM_ASSERT(A->info.m == B->info.m);

  int delta = B->info.n-(posB->val[numBlock+1]-posB->val[numBlock])/A->info.m;
  if(delta !=0){
    A->info.n += delta;
    ierr = CPLM_MatDenseRealloc(A);CPLM_CHKERR(ierr);
  }

  if(numBlock<posB->nval-1 && delta != 0){
    memmove(&(A->val[posB->val[numBlock]+B->info.m*B->info.n]), &(A->val[posB->val[numBlock+1]]), (posB->val[posB->nval-1]-posB->val[numBlock+1])*sizeof(double));
  }

  memcpy(&(A->val[posB->val[numBlock]]),B->val,B->info.m*B->info.n*sizeof(double));

  for(int i=numBlock+1;i<posB->nval;i++)
    posB->val[i]+=delta*B->info.m;

  return ierr;
}





//This function returns a column panel subA from matrix A
int CPLM_MatDenseGetColPanel(CPLM_Mat_Dense_t *A_in, CPLM_Mat_Dense_t *B_out, CPLM_IVector_t *pos, CPLM_IVector_t *colPos, int numBlock)
{
CPLM_PUSH
CPLM_BEGIN_TIME

  int ierr = 0;
  int ncol = 0;

  if(A_in->info.stor_type == ROW_MAJOR){
    fprintf(stderr,"Warning, ROW_MAJOR not implemented\n");
    ierr = 1;
CPLM_END_TIME
CPLM_POP
    return ierr;
  }
  CPLM_ASSERT(B_out != NULL);

  ncol = colPos->val[numBlock+1] - colPos->val[numBlock];

  ierr = CPLM_MatDenseSetInfo( B_out,
                          A_in->info.m,
                          A_in->info.n,
                          A_in->info.m,
                          ncol,
                          A_in->info.stor_type);CPLM_CHKERR(ierr)

  ierr = CPLM_MatDenseMalloc(B_out);CPLM_CHKERR(ierr);

  //COL_MAJOR CASE
  memcpy(B_out->val,&(A_in->val[colPos->val[numBlock]]),ncol*B_out->info.m*sizeof(double));

CPLM_END_TIME
CPLM_POP
  return ierr;
}





int CPLM_MatDenseGetRowPanel(CPLM_Mat_Dense_t *A_in, CPLM_Mat_Dense_t *B_out, CPLM_IVector_t *pos, int numBlock)
{
CPLM_PUSH
CPLM_BEGIN_TIME
  int ierr    = 0;
  int nrow    = 0;
  int nval    = 0;
  int offset  = 0;

  nrow = pos->val[numBlock + 1] - pos->val[numBlock];

  if(B_out->val != NULL)
  {
    if(B_out->info.nval < A_in->info.n*nrow)
    {
      ierr = CPLM_MatDenseSetInfo( B_out,
                              A_in->info.m,
                              A_in->info.n,
                              nrow,
                              A_in->info.n,
                              A_in->info.stor_type);CPLM_CHKERR(ierr)
      ierr = CPLM_MatDenseRealloc(B_out);CPLM_CHKERR(ierr);
    }
  }
  else
  {
    ierr = CPLM_MatDenseSetInfo( B_out,
                            A_in->info.m,
                            A_in->info.n,
                            nrow,
                            A_in->info.n,
                            A_in->info.stor_type);CPLM_CHKERR(ierr)

    ierr = CPLM_MatDenseMalloc(B_out);CPLM_CHKERR(ierr);
  }

  if(A_in->info.stor_type == COL_MAJOR)
  {
    offset  = pos->val[numBlock];
    for(int i = 0; i < A_in->info.n; i++)
    {
      memcpy(B_out->val + nval, A_in->val + offset, nrow * sizeof(double));
      nval    +=  nrow;
      offset  +=  A_in->info.lda;
    }
  }
  else
  {
    offset  = pos->val[numBlock] * A_in->info.lda;
    CPLM_debug("Offset = %d\n",offset);
    memcpy(B_out->val, A_in->val + offset, nrow * A_in->info.lda * sizeof(double));
  }

CPLM_END_TIME
CPLM_POP
  return ierr;
}




//DO NOT USED!
int CPLM_MatDenseGetColBlockPos(CPLM_Mat_Dense_t *A_in, CPLM_IVector_t *pos, CPLM_IVector_t *colPos)
{
CPLM_PUSH

  int ierr    = 0;
  int nblock  = 0;

  CPLM_Abort("DO NO USED!\n");


  nblock = pos->nval-1;

  if(A_in->info.stor_type == ROW_MAJOR)
  {
    ierr = CPLM_IVectorMalloc(colPos, A_in->info.m * (nblock + 1) );CPLM_CHKERR(ierr);
    colPos->val[0] = 0;
    for(int i = 1; i < colPos->nval; i++)
    {
      colPos->val[i] = colPos->val[i-1] + pos->val[(i + 1) % nblock] - pos->val[i % nblock];
    }
  }
  else
  {
    ierr = CPLM_IVectorCopy(pos,colPos);CPLM_CHKERR(ierr);
  }

CPLM_POP
  return ierr;
}





//Keep in mind the A_in->val has to point to the first diagonal element
int CPLM_MatDenseGetDiag(CPLM_Mat_Dense_t *A_in, double **diag)
{
  int ierr = 0;

  if(*diag == NULL)
  {
    (*diag) = (double*) malloc(CPLM_MIN(A_in->info.m,A_in->info.n) * sizeof(double));
    CPLM_ASSERT(*diag  != NULL);
  }

  for(int i = 0; i < CPLM_MIN(A_in->info.m, A_in->info.n); i++)
    (*diag)[i] = A_in->val[i * A_in->info.lda + i];

  return ierr;
}





int CPLM_MatDenseGetRInplace(CPLM_Mat_Dense_t* A_io)
{
CPLM_PUSH
CPLM_BEGIN_TIME

  int ierr  = 0;
  int m     = 0;
  int n     = 0;

  m = A_io->info.m;
  n = A_io->info.n;

  if(A_io->info.stor_type == ROW_MAJOR)
  {
    //Set lower part to 0
    for (int i = 1; i < CPLM_MIN(m,n); i++)
    {
      memset(A_io->val + i * A_io->info.lda, 0, i * sizeof(double));
    }

    CPLM_ASSERT(((m - 1) * A_io->info.lda + n) <= A_io->info.nval);
    //Remove extra lines
    for(int i = n; i < m; i++)
    {
      memset(A_io->val + i * A_io->info.lda, 0,  n * sizeof(double));
    }
  }
  else
  {
    //Set lower part to 0
    for (int i = 0; i < n; i++)
    {
      memset(A_io->val + i * A_io->info.lda + i + 1, 0, (A_io->info.lda - i - 1) * sizeof(double));
    }
  }
CPLM_END_TIME
CPLM_POP
  return ierr;
}





int CPLM_MatDenseIdentity(CPLM_Mat_Dense_t* A_out)
{
CPLM_PUSH
  int ierr    = 0;

  CPLM_ASSERT(A_out->val == NULL);

  ierr = CPLM_MatDenseCalloc(A_out);CPLM_CHKERR(ierr);

  //Add 1. on diagonal entries
  for (int i = 0; i < CPLM_MIN(A_out->info.m, A_out->info.n); i++)
  {
    A_out->val[i * A_out->info.lda + i] = 1.0;
  }
CPLM_POP
  return ierr;
}





int CPLM_MatDenseSetIdentity(CPLM_Mat_Dense_t *A_io)
{
CPLM_PUSH
  int ierr = 0;

  //Reset memory to 0
  memset(A_io->val,0,A_io->info.nval * sizeof(double));

  //Add 1. on diagonal entries
  for(int i = 0; i < CPLM_MIN(A_io->info.m,A_io->info.n); i++)
  {
    A_io->val[i * A_io->info.lda + i] = 1.;
  }

CPLM_POP
  return ierr;
}





//ADD a test to call it if nnz > cst i.e. here cst = limit*limit
//Cons : in that case, we can remove MINI() tests
void CPLM_MatDensePrintPartial2D(CPLM_Mat_Dense_t* A)
{
  int loop_index_1 = 0;
  int loop_index_2 = 0;

  if (A->info.stor_type == ROW_MAJOR)
  {
    loop_index_1 = A->info.n;
    loop_index_2 = 1;
  }
  else
  {
    loop_index_1 = 1;
    loop_index_2 = A->info.m;
  }
  for (int i = 0; i < CPLM_MIN(A->info.m,PRINT_PARTIAL_M); i++)
  {
    printf("[ ");
    for (int j = 0; j < CPLM_MIN(A->info.n-1,PRINT_PARTIAL_N); j++)
      printf("%.10f\t", A->val[i*loop_index_1 + j*loop_index_2]);
    if(A->info.n>2*PRINT_PARTIAL_N)
    {
      printf("...");
      for (int j = A->info.n-1-PRINT_PARTIAL_N; j < A->info.n-1 ; j++)
        printf("%.10f\t", A->val[i*loop_index_1 + j*loop_index_2]);
    }
    printf("%.10f ]\n", A->val[i*loop_index_1 + (A->info.n - 1)*loop_index_2]);
  }

  printf("...\n");

  if(A->info.m>2*PRINT_PARTIAL_M)
  {
    for (int i = A->info.m-PRINT_PARTIAL_M; i < A->info.m; i++) {
      printf("[ ");
      for (int j = 0; j < CPLM_MIN(A->info.n-1,PRINT_PARTIAL_N); j++)
        printf("%.10f\t", A->val[i*loop_index_1 + j*loop_index_2]);
      if(A->info.n>2*PRINT_PARTIAL_N)
      {
        printf("...");
        for (int j = A->info.n-1-PRINT_PARTIAL_N; j < A->info.n-1 ; j++)
          printf("%.10f\t", A->val[i*loop_index_1 + j*loop_index_2]);
      }
      printf("%.10f ]\n", A->val[i*loop_index_1 + (A->info.n - 1)*loop_index_2]);
    }
  }
}

void CPLM_MatDensePrint2D(CPLM_Mat_Dense_t* A) {
  int loop_index_1 = 0;
  int loop_index_2 = 0;

  if (A->info.stor_type == ROW_MAJOR) {
    loop_index_1 = A->info.lda;
    loop_index_2 = 1;
  }
  else {
    loop_index_1 = 1;
    loop_index_2 = A->info.lda;
  }
  for (int i = 0; i < A->info.m; i++) {
    printf("[ ");
    for (int j = 0; j < A->info.n - 1; j++)
      printf("%.10f\t", A->val[i*loop_index_1 + j*loop_index_2]);
    printf("%.10f ]\n", A->val[i*loop_index_1 + (A->info.n - 1)*loop_index_2]);
  }
}





int CPLM_MatDenseReset(CPLM_Mat_Dense_t *A)
{
  CPLM_ASSERT(A->val == NULL);

  A->info.M         = 0;
  A->info.N         = 0;
  A->info.m         = 0;
  A->info.n         = 0;
  A->info.stor_type = ROW_MAJOR;

  return 0;
}





int CPLM_MatDenseSetInfo(CPLM_Mat_Dense_t* A_out, int M, int N, int m, int n, CPLM_storage_type_t storage)
{
  A_out->info.M = M;
  A_out->info.N = N;
  A_out->info.m = m;
  A_out->info.n = n;
  A_out->info.stor_type = storage;
  A_out->info.lda = (storage == COL_MAJOR) ? m : n;
  A_out->info.nval = m * n;

  return 0;
}

void CPLM_MatDensePrintInfo(CPLM_Mat_Dense_t* A)
{
  printf("Dense Matrix %dx%d\tLocal Data: %dx%d\t%s\tLeading Dimension Array %d\tNumber of elements of array %d\n",
          A->info.M,
          A->info.N,
          A->info.m,
          A->info.n,
          (A->info.stor_type==ROW_MAJOR) ? "Storage: Row major\n" : "Storage: Col major\n",
          A->info.lda,
          A->info.nval);
}





// A function that takes a matrix A and a matrix B, it copies R the upper triangular of A in B with B(i,j) as a point of departure. we treat only the colmajor case
int CPLM_MatDenseTriangularFillBlock(CPLM_Mat_Dense_t* A_in, CPLM_Mat_Dense_t *B_io, int index_i, int index_j, int Size_R)
{
CPLM_PUSH
CPLM_BEGIN_TIME

#if 1
  int ierr      = 0;
  int dataSet   = 0;  //Number of values either in one line or one column
  int offset    = 0;  //Offset to be in first position in B_io
  int nset      = 0;  //Number of rows or columns to copy
  int minIter   = 0;
  CPLM_Mat_Dense_t A_remain_s  = CPLM_MatDenseNULL();

  CPLM_ASSERT(A_in->val  != NULL);
  CPLM_ASSERT(B_io->val  != NULL);
  CPLM_ASSERT(index_i    >= 0);
  CPLM_ASSERT(index_j    >= 0);
  CPLM_ASSERT(index_i    < B_io->info.m);
  CPLM_ASSERT(index_j    < B_io->info.n);


  if(B_io->info.stor_type != A_in->info.stor_type)
  {
    CPLM_Abort("Matrix storage type are not the same the storage type of "
        "the first matrix is %d and that of the second matrix is %d \n",
        B_io->info.stor_type,
        A_in->info.stor_type);
  }


  if(B_io->info.stor_type == COL_MAJOR)
  {
    //CPLM_ASSERT((index_j + ) <= B_io->info.n);

    offset  = index_j * B_io->info.lda + index_i;
    dataSet = 1;
    nset    = A_in->info.n;
  }
  else
  {
    CPLM_ASSERT((index_i + nset) <= B_io->info.m);

    offset  = index_i * B_io->info.lda + index_j;
    dataSet =  A_in->info.n;
    nset    = CPLM_MIN(A_in->info.m,A_in->info.n);
  }

  minIter = CPLM_MIN(nset,A_in->info.n);

  if(B_io->info.stor_type == COL_MAJOR)
  {
    for(int i = 0; i < minIter; i++)
    {
      CPLM_ASSERT((i * B_io->info.lda + offset + (dataSet + i)) <= B_io->info.nval);
      CPLM_ASSERT((i * A_in->info.lda + (dataSet + i)) <= A_in->info.nval);
      memcpy(B_io->val + i * B_io->info.lda + offset,
          A_in->val + i * A_in->info.lda,
          (dataSet + i )* sizeof(double));
    }
  }
  else
  {
    for(int i = 0; i < minIter; i++)
    {
      memcpy(B_io->val + i * B_io->info.lda + offset + i,
          A_in->val + i * A_in->info.lda + i,
          (dataSet - i )* sizeof(double));
    }
  }

  //Copy the remaining rectangular block if needed
  if(minIter != A_in->info.n)
  {
    CPLM_MatDenseSetInfo(&A_remain_s,
      A_in->info.M,
      A_in->info.N,
      A_in->info.m,
      A_in->info.n-minIter,
      A_in->info.stor_type);CPLM_CHKERR(ierr);
    A_remain_s.val = A_in->val + minIter *minIter;

    ierr = CPLM_MatDenseBlockFill( &A_remain_s,
        B_io,
        index_i,
        index_j + minIter);CPLM_CHKERR(ierr);
  }

//CPLM_MatDensePrintf2D("A_in",A_in);
//CPLM_MatDensePrintf2D("B_io",B_io);
#else
//*
  int mA = 0;
  int nA = 0;
  int mB = 0;
  int nB = 0;

  mA = B_io->info.m;
  nA = B_io->info.n;
  mB = A_in->info.m;
  nB = A_in->info.n;

  CPLM_ASSERT(A_in->val != NULL);
  CPLM_ASSERT(B_io->val != NULL);

  if(Size_R + index_i > mA || Size_R + index_j > nA )
  {
    CPLM_Abort("There is not enough space in the filling in matrix\n The triangular matrix is of size %dx%d and the block to be filled is of size %dx%d \n",Size_R, Size_R, mA - index_i , nA - index_j);
  }

  if( B_io->info.stor_type == ROW_MAJOR)
  {
    for(int i = 0; i < Size_R; i++)
    {
      for(int j = i; j < Size_R; j++)
      {
        CPLM_ASSERT((nA * (index_i + i) + index_j +j)  < B_io->info.nval);
        CPLM_ASSERT((nB * i + j)                       < A_in->info.nval);

        B_io->val[nA * (index_i + i) + index_j + j] = A_in->val[nB * i + j];
      }
    }
  }
  else
  {
    for(int j = 0; j < Size_R; j++)
    {
      for(int i = 0; i <= j; i++)
      {
        CPLM_ASSERT((mA * (index_j + j) + index_i + i) < B_io->info.nval);
        CPLM_ASSERT((mB * j + i)                       < A_in->info.nval);

        B_io->val[mA * (index_j + j) + index_i + i] = A_in->val[mB * j + i];
      }
    }
  }
//*/
#endif
CPLM_END_TIME
CPLM_POP
  return 0;
}





int CPLM_MatDenseGetSymRowPanel(CPLM_Mat_Dense_t *A_in, CPLM_Mat_Dense_t *B_out_s, CPLM_IVector_t *pos, int numBlock)
{
CPLM_PUSH
CPLM_BEGIN_TIME

  int ierr = 0;
  int nrow = 0;

  if(A_in->info.stor_type == COL_MAJOR)
  {
    printf("WARNING, this case is not implemented\n");
    return 1;
  }

  nrow = pos->val[numBlock+1] - pos->val[numBlock];

  ierr = CPLM_MatDenseInit(B_out_s,A_in->info);CPLM_CHKERR(ierr);
  B_out_s->info.m     = nrow;
  B_out_s->info.nval  = nrow * B_out_s->info.n;

  //create the pointer to the concerned memory location
  B_out_s->val        = &(A_in->val[ pos->val[numBlock] * A_in->info.lda]);

CPLM_END_TIME
CPLM_POP
  return ierr;
}





int CPLM_MatDenseGetSymColPanel(CPLM_Mat_Dense_t *A_in, CPLM_Mat_Dense_t *B_out_s, CPLM_IVector_t *pos, int numBlock)
{
CPLM_PUSH
CPLM_BEGIN_TIME

  int ierr = 0;

  if(A_in->info.stor_type == ROW_MAJOR)
  {
    printf("WARNING, this case is not implemented\n");
    return 1;
  }

  int ncol = pos->val[numBlock+1] - pos->val[numBlock];

  ierr = CPLM_MatDenseInit(B_out_s,A_in->info);CPLM_CHKERR(ierr);
  B_out_s->info.n     = ncol;
  B_out_s->info.nval  = ncol * B_out_s->info.m;

  //create the pointer to the concerned memory location
  B_out_s->val        = &(A_in->val[ pos->val[numBlock] * A_in->info.lda]);

CPLM_END_TIME
CPLM_POP
  return ierr;
}





int CPLM_MatDenseIsSameLocalInfo(CPLM_Mat_Dense_t *A_in, CPLM_Mat_Dense_t *B_in)
{
  int ok = CPLM_TRUE;

  CPLM_Info_Dense_t f1 = A_in->info;
  CPLM_Info_Dense_t f2 = B_in->info;

  return (f1.m          == f2.m     &&
          f1.n          == f2.n     &&
          f1.nval       == f2.nval  &&
          f1.lda        == f2.lda   &&
          f1.stor_type  == f2.stor_type) ? ok : !ok ;

}





int CPLM_MatDenseIsSameInfo(CPLM_Mat_Dense_t *A_in, CPLM_Mat_Dense_t *B_in)
{
  int ok = CPLM_TRUE;

  CPLM_Info_Dense_t f1 = A_in->info;
  CPLM_Info_Dense_t f2 = B_in->info;

  return (f1.M          == f2.M     &&
          f1.N          == f2.N     &&
          f1.m          == f2.m     &&
          f1.n          == f2.n     &&
          f1.nval       == f2.nval  &&
          f1.lda        == f2.lda   &&
          f1.stor_type  == f2.stor_type) ? ok : !ok ;
}





int CPLM_MatDenseToMatCSR(CPLM_Mat_Dense_t *A_in, CPLM_Mat_CSR_t *B_out)
{
CPLM_PUSH
CPLM_BEGIN_TIME

  int ierr  = 0;
  int nnz   = 0;
  int cpt   = 0;
  int elem  = 0;
  CPLM_Mat_Dense_t A = CPLM_MatDenseNULL();

  //Count how many nnz are in A_in
  for(int i=0;i<A_in->info.nval;i++)
  {
    if(A_in->val[i] != 0.0 )
      nnz++;
  }

  if(B_out->val == NULL)
  {
    ierr = CPLM_MatCSRSetInfo( B_out,
        A_in->info.M,
        A_in->info.N,
        nnz,
        A_in->info.m,
        A_in->info.n,
        nnz,
        1);CPLM_CHKERR(ierr);

    ierr = CPLM_MatCSRMalloc(B_out);CPLM_CHKERR(ierr);
  }
  else
  {
    if(B_out->info.lnnz < nnz)
    {
      ierr = CPLM_MatCSRSetInfo( B_out,
          A_in->info.M,
          A_in->info.N,
          nnz,
          A_in->info.m,
          A_in->info.n,
          nnz,
          1);CPLM_CHKERR(ierr);
      ierr = CPLM_MatCSRRealloc(B_out);CPLM_CHKERR(ierr);
    }
  }

  B_out->rowPtr[0] = cpt;
  if(A_in->info.stor_type == COL_MAJOR)
  {
    ierr = CPLM_MatDenseConvertMajor(A_in, &A);CPLM_CHKERR(ierr);
  }
  else
  {
    A = *A_in;
  }

  for(int i = 0; i < A.info.m; i++)
  {
    for(int j = 0; j < A.info.n; j++)
    {
      elem = i * A.info.lda + j;
      if(A.val[elem] != 0.0 )
      {
        B_out->colInd[cpt]  = j;
        B_out->val[cpt++]   = A.val[elem];
      }
    }
    B_out->rowPtr[i + 1]  = cpt;
  }

  if(A_in->info.stor_type == COL_MAJOR)
  {
    CPLM_MatDenseFree(&A);
  }

CPLM_END_TIME
CPLM_POP
  return ierr;

}





int CPLM_MatDenseSetColumn(CPLM_Mat_Dense_t * M_out, CPLM_DVector_t *v_in, int index_j)
{
    CPLM_ASSERT(M_out->val != NULL);
    if (index_j > M_out->info.n)
    {
        printf("MatDenseSetColumn : Error : Please enter a column index smaller than the dimension of the matrix\n");
        return 1;
    }
    if (v_in->nval != M_out->info.m)
    {
        printf("MatDenseSetColumn : Error : Matrix and CPLM_IVector_t dimensions don't match\n");
        return 2;
    }
    if (M_out->info.stor_type == COL_MAJOR)
        memcpy(M_out->val + M_out->info.lda * index_j,
               v_in->val,
               v_in->nval * sizeof(double));
    if (M_out->info.stor_type == ROW_MAJOR)
        for (int j = 0; j < M_out->info.m; j++)
            M_out->val[index_j + M_out->info.n * j] = v_in->val[j];
    return 0;
}





//This function returns a copy of a column
int CPLM_MatDenseGetColumn(CPLM_Mat_Dense_t *M_in, CPLM_DVector_t *v_out, int index_j)
{
CPLM_PUSH
CPLM_BEGIN_TIME

  int ierr = 0;

  //Check column index is in the matrix
  if(index_j >= M_in->info.n)
  {
      CPLM_MatDensePrintfInfo("Info M_in",M_in);
      CPLM_Abort("index_j %d is bigger than matrix dimension", index_j);
  }

  CPLM_ASSERT(v_out->val == NULL);

  ierr = CPLM_DVectorMalloc(v_out, M_in->info.m);CPLM_CHKERR(ierr);

  if (M_in->info.stor_type == COL_MAJOR)
  {
      CPLM_ASSERT(M_in->info.lda * index_j                < M_in->info.nval);
      CPLM_ASSERT(M_in->info.lda * index_j + v_out->nval  < M_in->info.nval);
      CPLM_ASSERT(M_in->info.lda * index_j + v_out->nval  < v_out->nval);

      memcpy(v_out->val,
             M_in->val + M_in->info.lda * index_j,
             v_out->nval * sizeof(double));
  }
  else if(M_in->info.stor_type == ROW_MAJOR)
  {
    CPLM_ASSERT(M_in->info.m < v_out->nval);

    for(int j = 0; j < M_in->info.m; j++)
    {
      CPLM_ASSERT(index_j + M_in->info.n * j < M_in->info.nval );

      v_out->val[j] = M_in->val[index_j + M_in->info.n * j];
    }
  }
  else
    ierr = 1;

CPLM_END_TIME
CPLM_POP
    return ierr;
}





// Function that fills M2 in a block of M1 that starts on M1->val[index_i][index_j];
int CPLM_MatDenseBlockFill(CPLM_Mat_Dense_t* A_in, CPLM_Mat_Dense_t* B_io, int index_i, int index_j)
{
CPLM_PUSH
CPLM_BEGIN_TIME
CPLM_OPEN_TIMER
#if 1
  int ierr      = 0;
  int dataSet   = 0;  //Number of values either in one line or one column
  int offset    = 0;  //Offset to be in first position in B_io
  int nset      = 0;  //Number of rows or columns to copy

  CPLM_ASSERT(A_in->val  != NULL);
  CPLM_ASSERT(B_io->val  != NULL);
  CPLM_ASSERT(index_i    >= 0);
  CPLM_ASSERT(index_j    >= 0);
  CPLM_ASSERT(index_i    < B_io->info.m);
  CPLM_ASSERT(index_j    < B_io->info.n);
  CPLM_ASSERT((index_i + A_in->info.m) <= B_io->info.m);
  CPLM_ASSERT((index_j + A_in->info.n) <= B_io->info.n);

  if(B_io->info.stor_type != A_in->info.stor_type)
  {
      CPLM_Abort("Matrix storage type are not the same the storage type of the first matrix is %d and that of the second matrix is %d \n",B_io->info.stor_type, A_in->info.stor_type);
  }

  offset    = (B_io->info.stor_type == COL_MAJOR) ?
    index_j * B_io->info.lda + index_i:
    index_i * B_io->info.lda + index_j;

  dataSet  = (B_io->info.stor_type == COL_MAJOR) ?
    A_in->info.m:
    A_in->info.n;

  nset      = (B_io->info.stor_type == COL_MAJOR) ?
    A_in->info.n:
    A_in->info.m;

  for(int i = 0; i < nset; i++)
  {
    memcpy(B_io->val + i * B_io->info.lda + offset,
      A_in->val + i * A_in->info.lda,
      dataSet * sizeof(double));
  }

//CPLM_MatDensePrintf2D("A_in",A_in);
//CPLM_MatDensePrintf2D("B_io",B_io);
#else
//*
  int ierr  = 0;
  int i     = 0;
  int j     = 0;
  int m1    = 0;
  int m2    = 0;
  int n1    = 0;
  int n2    = 0;

  if(B_io->info.stor_type != A_in->info.stor_type)
  {
      CPLM_Abort("Matrix storage type are not the same the storage type of the first matrix is %d and that of the second matrix is %d \n",B_io->info.stor_type, A_in->info.stor_type);
  }

  m1  = B_io->info.m;
  m2  = A_in->info.m;
  if(A_in->info.stor_type == COL_MAJOR)
  {
      n2=A_in->info.n;
      for(j=0 ; j < n2 ; j++)
          for(i=0 ; i < m2 ; i++)
              B_io->val[m1 * (j + index_j) + i + index_i] = A_in->val[m2 * j + i];
  }
  else
  {
      n1=B_io->info.n;
      n2=A_in->info.n;
      for(i=0 ; i < m2 ; i++)
          for(j=0 ; j < n2 ; j++)
              B_io->val[n1 * (i + index_i) + j + index_j] = A_in->val[n2 * i + j];
  }
//*/
#endif
CPLM_CLOSE_TIMER
CPLM_END_TIME
CPLM_POP
  return ierr;
}





int CPLM_MatDenseSwap(CPLM_Mat_Dense_t *A_io, CPLM_Mat_Dense_t *B_io)
{
CPLM_PUSH
  int ierr = 0;
  double *swap = NULL;

  swap      = A_io->val;
  A_io->val = B_io->val;
  B_io->val = swap;
CPLM_POP
  return ierr;
}





int CPLM_MatDenseRowPerm(CPLM_Mat_Dense_t* A, CPLM_IVector_t* rowPerm)
{
CPLM_PUSH
CPLM_BEGIN_TIME

  int ierr    = 0;
  int offset  = 0;
  double buffer = 0.0;
  CPLM_IVector_t isPermuted = CPLM_IVectorNULL();

  CPLM_ASSERT(rowPerm->val != NULL);

  if (A->info.stor_type == ROW_MAJOR)
  {
    CPLM_Abort("only COL_MAJOR storage type!\n");
  }

  ierr = CPLM_IVectorCalloc(&isPermuted, A->info.m);CPLM_CHKERR(ierr);
  for (int i = 0; i < A->info.m; i++)
  {
    if(!isPermuted.val[i])
    {
      for (int j = 0; j < A->info.n; j++)
      {
        offset = j * A->info.m;
        buffer                            = A->val[offset + rowPerm->val[i]];
        A->val[offset + rowPerm->val[i]]  = A->val[offset + i];
        A->val[offset + i]                = buffer;
      }
      isPermuted.val[i]               = 1;
      isPermuted.val[rowPerm->val[i]] = 1;
    }
  }
  CPLM_IVectorFree(&isPermuted);

CPLM_END_TIME
CPLM_POP
  return ierr;
}





int CPLM_MatDenseColPerm(CPLM_Mat_Dense_t*  A_io,
                    CPLM_IVector_t*    colPerm,
                    double        **work,
                    size_t        *workSize)
{
CPLM_PUSH
CPLM_BEGIN_TIME

  int ierr    = 0;
  int cpt     = 0;
  int j       = 0;
  int m       = 0;
  int ndest   = 0;
  int norigin = 0;
  int next    = 0;
  int c       = 0;
  int d       = 0;
  size_t  ndata           = 0;
  size_t  workSizeNeeded  = 0;
  CPLM_DVector_t buf_s   = CPLM_DVectorNULL();
  CPLM_IVector_t pos_s   = CPLM_IVectorNULL();
  CPLM_IVector_t ipos_s  = CPLM_IVectorNULL();

  CPLM_ASSERT(colPerm->val   != NULL);
  CPLM_ASSERT(colPerm->nval  == A_io->info.n);
  CPLM_ASSERT(work           != NULL);
  CPLM_ASSERT(workSize       != NULL);

  if (A_io->info.stor_type == ROW_MAJOR)
  {
    CPLM_Abort("only COL_MAJOR storage type!\n");
  }

  m = A_io->info.m;

  workSizeNeeded = (size_t)(m + 2 * colPerm->nval); //Overestimated since work is also used for
                                                    // pos and ipos of type integer

  if(*work == NULL)
  {
    *workSize = workSizeNeeded;
    *work = (double*)malloc(*workSize * sizeof(double));
  }
  else if(*workSize < workSizeNeeded)
  {
    *workSize = workSizeNeeded;
    *work = (double*)realloc(*work, *workSize * sizeof(double));
  }
  CPLM_ASSERT(*work != NULL);

  ierr = CPLM_DVectorCreateFromPtr(&buf_s, m, *work);CPLM_CHKERR(ierr);
  ierr = CPLM_IVectorCreateFromPtr(&pos_s, colPerm->nval, (int*)(buf_s.val + buf_s.nval));CPLM_CHKERR(ierr);
  ierr = CPLM_IVectorCreateFromPtr(&ipos_s, colPerm->nval, pos_s.val + pos_s.nval);CPLM_CHKERR(ierr);

  //Contains position at iteration cpt of each column
  ierr = CPLM_IVectorSequence(&pos_s, 0, colPerm->nval - 1, 1);CPLM_CHKERR(ierr);
  ierr = CPLM_IVectorCopyData(&ipos_s, &pos_s);CPLM_CHKERR(ierr);

  ndata = (size_t)(m * sizeof(double));

  while(cpt < pos_s.nval)
  {
    if(pos_s.val[cpt] == colPerm->val[cpt])
    {
      cpt++;
      continue;
    }

    j = colPerm->val[cpt];
    ndest   = cpt * A_io->info.lda;
    norigin = ipos_s.val[j] * A_io->info.lda;

    memcpy(buf_s.val, A_io->val + ndest, ndata);
    memcpy(A_io->val + ndest, A_io->val + norigin, ndata);
    memcpy(A_io->val + norigin, buf_s.val, ndata);

    CPLM_debug("EXCHANGE %d (in pos %d) with %d (in pos %d)\n",
        cpt,pos_s.val[cpt],j,ipos_s.val[j]);

    //Swap pos and ipos
    c                         = pos_s.val[cpt];
    pos_s.val[cpt]            = j;
    pos_s.val[ipos_s.val[j]]  = c;
    d                         = ipos_s.val[j];
    ipos_s.val[j]             = cpt;
    ipos_s.val[c]             = d;

    cpt++;
  }
//CPLM_IVectorFree(&pos);
//CPLM_IVectorFree(&ipos);
CPLM_END_TIME
CPLM_POP
  return ierr;
}




int CPLM_MatDenseTestFunction(int rank) {
 // Dirty...

#ifndef MPIACTIVATE
  rank = 0;
#endif
  CPLM_Mat_Dense_t A = CPLM_MatDenseNULL();
  CPLM_Mat_Dense_t B = CPLM_MatDenseNULL();
  CPLM_Info_Dense_t infoB;
  int ierr = 0;
  if (rank == 0) {
    printf("::: Testing CPLM_Mat_Dense_t functions :::\n");
    ierr = CPLM_MatDenseSetInfo(&A, 4, 2, 4, 2, ROW_MAJOR);
    if (ierr != 0)
      printf(" MatDenseSetInfo::Error!\n");
    else
      printf(" MatDenseSetInfo::Passed!\n");
    ierr = CPLM_MatDenseConstant(&A, 1.0);
    if (ierr != 0)
      printf(" MatDenseConstant::Error!\n");
    else
      printf(" MatDenseConstant::Passed!\n");
    printf(" Testing printing functions:\n");
    CPLM_MatDensePrintInfo(&A);
    CPLM_MatDensePrint2D(&A);

    infoB.M    = 4;
    infoB.N    = 2;
    infoB.m    = 4;
    infoB.n    = 2;
    infoB.nval = 8;
    infoB.lda  = 2;
    infoB.stor_type = ROW_MAJOR;
    ierr = CPLM_MatDenseInit(&B, infoB);
    if (ierr != 0)
      printf(" MatDenseInit::Error!\n");
    else
      printf(" MatDenseInit::Passed!\n");
    ierr = CPLM_MatDenseConstant(&B, 2.0);
    if (ierr != 0)
      printf(" MatDenseCalloc::Error!\n");
    else
      printf(" MatDenseCalloc::Passed!\n");
    CPLM_Mat_Dense_t C = CPLM_MatDenseNULL();

    //TEST  MatDenseVrtlConcat
    CPLM_Mat_Dense_t mA  = CPLM_MatDenseNULL();
    CPLM_Mat_Dense_t mB  = CPLM_MatDenseNULL();
    CPLM_IVector_t posB     = CPLM_IVectorNULL();

    ierr = CPLM_MatDenseSetInfo(&mA, 4, 2, 4, 2, COL_MAJOR);
    ierr = CPLM_MatDenseSetInfo(&mB, 4, 2, 4, 2, COL_MAJOR);
    ierr = CPLM_MatDenseConstant(&mA,1.0);CPLM_CHKERR(ierr);
    ierr = CPLM_MatDenseConstant(&mB,2.0);CPLM_CHKERR(ierr);
    ierr = CPLM_MatDenseVrtlConcat(&mA,&mB,&posB);CPLM_CHKERR(ierr);
    if (ierr != 0)
      printf( " MatDenseVrtlConcat::Error!\n");
    else
      printf( " MatDenseVrtlConcat::Passed!\n");

    //TEST MatDenseReplaceColBlock
    CPLM_MatDenseFree(&mB);
    CPLM_MatDenseReset(&mB);
    ierr = CPLM_MatDenseSetInfo(&mB, 4, 3, 4, 3, COL_MAJOR);
    ierr = CPLM_MatDenseConstant(&mB,-3.0);CPLM_CHKERR(ierr);
    ierr = CPLM_MatDenseReplaceColBlock(&mA,&mB,&posB,0);CPLM_CHKERR(ierr);
    if (ierr != 0)
      printf( " MatDenseReplaceColBlock::Error!\n");
    else
      printf( " MatDenseReplaceColBlock::Passed!\n");

    CPLM_Mat_Dense_t M1=CPLM_MatDenseNULL();
    CPLM_Info_Dense_t infoM1;
    infoM1.M    = 6;
    infoM1.N    = 4;
    infoM1.m    = 6;
    infoM1.n    = 4;
    infoM1.nval = 24;
    infoM1.lda  = 4;
    infoM1.stor_type = ROW_MAJOR;
    CPLM_MatDenseInit(&M1, infoM1);
    CPLM_MatDenseCalloc(&M1);
    printf("Matrix M1 before filling a part of it\n" );
    CPLM_MatDensePrint2D(&M1);
    CPLM_Mat_Dense_t M2=CPLM_MatDenseNULL();
    CPLM_MatDenseSetInfo(&M2, 3, 2, 3, 2, ROW_MAJOR);
    CPLM_MatDenseConstant(&M2, 2.0);
    ierr=CPLM_MatDenseBlockFill(&M1, &M2, 1, 2);
    if(ierr != 0)
        printf("MatDenseBlockFill::Error!\n");
    else
        printf("MatDenseBlockFill::Passed!\n");
    printf("Matrix M2\n" );
    CPLM_MatDensePrint2D(&M2);
    printf("Matrix M1 after filling a part of it\n" );
    CPLM_MatDensePrint2D(&M1);

    CPLM_MatDenseFree(&A);
    CPLM_MatDenseFree(&B);
    CPLM_MatDenseFree(&C);
    CPLM_MatDenseFree(&M1);
    CPLM_MatDenseFree(&M2);
    CPLM_Mat_Dense_t A = CPLM_MatDenseNULL();
    CPLM_Mat_Dense_t H = CPLM_MatDenseNULL();
    CPLM_MatDenseSetInfo(&A,4,2,4,2,COL_MAJOR);
    CPLM_MatDenseMalloc(&A);
    CPLM_MatDenseSetInfo(&H,3,2,3,2,COL_MAJOR);
    CPLM_MatDenseCalloc(&H);
    A.val[0] = 1 ;
    A.val[1] = 1 ;
    A.val[2] = 1 ;
    A.val[3] = 1 ;
    A.val[4] = 2 ;
    A.val[5] = 2 ;
    A.val[6] = 2 ;
    A.val[7] = 2 ;
    printf("Matrix A\n" );
    CPLM_MatDensePrint2D(&A);
    printf("Matrix H\n" );

    CPLM_MatDensePrint2D(&H);
    ierr = CPLM_MatDenseTriangularFillBlock(&H, &A, 0, 0, 2);
    printf("Matrix A\n" );
    CPLM_MatDensePrint2D(&A);
    printf("Matrix H\n" );
    CPLM_MatDensePrint2D(&H);
    //ierr = CPLM_MatDenseKernelQR(&A, &H, 0, 0);
    printf("A after orthogonalization \n");
    CPLM_MatDensePrint2D(&A);
    printf("factor R\n" );
    CPLM_MatDensePrint2D(&H);

    A.val[0] = 1 ;
    A.val[1] = 1 ;
    A.val[2] = 1 ;
    A.val[3] = 1 ;
    A.val[4] = 2 ;
    A.val[5] = 2 ;
    A.val[6] = 2 ;
    A.val[7] = 2 ;
    printf("Matrix A\n" );
    A.info.stor_type = ROW_MAJOR;
    A.info.lda = A.info.n;
    CPLM_MatDensePrint2D(&A);

    CPLM_DVector_t u = CPLM_DVectorNULL();
    CPLM_MatDenseGetColumn(&A, &u, 1);
    CPLM_DVectorPrintf("Uvector",&u);

    CPLM_DVector_t v = CPLM_DVectorNULL();
    CPLM_DVector_t u1 = CPLM_DVectorNULL();
    CPLM_DVectorMalloc(&u1, 2);
    u1.val[0] = 1;
    u1.val[1] = 1;
    CPLM_DVectorPrintf("U1vector", &u1);
    CPLM_DVectorMalloc(&v, 4);
    CPLM_MatDensePrintInfo(&A);
    //CPLM_MatDenseKernelMatVec(&A, &u1, &v, 1., 0.);
    CPLM_MatDenseSetColumn(&A, &v, 0);
    CPLM_DVectorPrintf("Vvector", &v);

    CPLM_MatDensePrintf2D("Matrix A\n",&A);

  }

  // MPI part
//#ifdef MPIACTIVATE
  // CPLM_Mat_Dense_t C = CPLM_MatDenseNULL();
  // MPI_Request* req_send = (MPI_Request*) malloc(2*sizeof(MPI_Request));
  // if (rank == 0) {
  //   printf(" ::Begin MPI Tests::\n");
  //   ierr = CPLM_MatDenseISend(&A, 1, MPI_COMM_WORLD, &req_send);
  //   MPI_Status status;
  //   MPI_Waitall(1, req_send, &status);
  //   int number_amount;
  //   MPI_Get_count(&status, MPI_INT, &number_amount);
  //   printf("    0 sent to 1:\n");
  //   CPLM_MatDensePrintInfo(&A);
  //   CPLM_MatDensePrint2D(&A);
  //   CPLM_MatDenseFree(&A);
  // }
  // if (rank == 1) {
  //   ierr = CPLM_MatDenseSetInfo(&B, 8, 2, 8, 2, ROW_MAJOR);
  //   ierr = CPLM_MatDenseConstant(&B, 3.0);
  //   int offset = 2;
  //   CPLM_MatDenseIRecvRowConcat(&B, offset, 0, MPI_COMM_WORLD, &req_recv);
  //   MPI_Status status;
  //   MPI_Wait(&req_recv, &status);
  //   printf("    1 received from 0:\n");
  //   CPLM_MatDensePrintInfo(&B);
  //   CPLM_MatDensePrint2D(&B);
  //   CPLM_MatDenseFree(&B);
  //   printf(" ::End MPI Tests::\n");
  // }
//   int size;
//   MPI_Comm_size(MPI_COMM_WORLD, &size);
//   CPLM_MatDenseSetInfo(&A, 4*size, 2, 4, 2, ROW_MAJOR);
//   CPLM_MatDenseConstant(&A, 1.0);
//   CPLM_MatDenseSetInfo(&B, 4*size, 2, 4, 2, ROW_MAJOR);
//   CPLM_MatDenseConstant(&B, 2.0);
//   //ierr = CPLM_MatDenseMatDotProd(&A, &B, &C, MPI_COMM_WORLD);
//   if (rank == 0) {
//     if (ierr != 0)
//       printf(" MatDenseMatDotProd::Error!\n");
//     else
//       printf(" MatDenseMatDotProd::Passed!\n");
//     CPLM_MatDensePrint2D(&C);
//   }
//   CPLM_MatDenseFree(&A);
//   CPLM_MatDenseFree(&B);
//   CPLM_MatDenseFree(&C);
//   if (req_send) free(req_send);
// #endif
  if (rank == 0)
    printf("::: End Tests CPLM_Mat_Dense_t functions :::\n");

  return ierr;

}





int CPLM_MatDenseConvertMajor(CPLM_Mat_Dense_t *A_in, CPLM_Mat_Dense_t *B_out)
{
CPLM_PUSH
CPLM_BEGIN_TIME
  int ierr  = 0;
  int cpt   = 0;

//CPLM_MatDensePrintf2D("Original", A_in);
//CPLM_printVec(A_in->val, A_in->info.nval,  "RAW A_in", "%f ");

  if(B_out->val == NULL)
  {
    B_out->info = A_in->info;
    ierr = CPLM_MatDenseMalloc(B_out);CPLM_CHKERR(ierr);
  }
  else
  {
    if(B_out->info.nval != A_in->info.nval)
    {
      B_out->info = A_in->info;
      ierr = CPLM_MatDenseRealloc(B_out);CPLM_CHKERR(ierr);
    }
  }

  if(A_in->info.stor_type == COL_MAJOR)
  {
    for(int i = 0; i < A_in->info.m; i++)
    {
      for(int j = 0; j < A_in->info.n; j++)
      {
        B_out->val[cpt++] = A_in->val[j * A_in->info.lda + i];
      }
    }
    B_out->info.stor_type = ROW_MAJOR;
    B_out->info.lda = B_out->info.n;
  }
  else
  {
    for(int i = 0; i < A_in->info.n; i++)
    {
      for(int j = 0; j < A_in->info.m; j++)
      {
        B_out->val[cpt++] = A_in->val[j * A_in->info.lda + i];
      }
    }
    B_out->info.stor_type = COL_MAJOR;
    B_out->info.lda = B_out->info.m;
  }

//CPLM_printVec(B_out->val, B_out->info.nval,  "RAW transpose", "%f ");
//CPLM_MatDensePrintf2D("Transpose", B_out);

CPLM_END_TIME
CPLM_POP
  return ierr;
}




#ifdef MPIACTIVATE

  int CPLM_MatDenseSend(CPLM_Mat_Dense_t* A_in, int dest, int tag, MPI_Comm comm)
  {
  CPLM_PUSH
  CPLM_BEGIN_TIME

    int ierr = 0;

    MPI_Datatype MPI_INFO_DENSE = initMPI_StructDenseInfo();

    // Broadcast the matrix to all processes included into MPI comm group
    if (dest == -1)
    {
      fprintf(stderr,"Broadcast is not managed for the moment\n");
      return 1;
    }
    else
    {
      // Send information of the matrix
      ierr = MPI_Send(&(A_in->info),1,MPI_INFO_DENSE,dest,tag,comm);
      CPLM_checkMPIERR(ierr,"send_dense_info");

      // Send values
      ierr = MPI_Send(A_in->val,(A_in->info.n)*(A_in->info.m),MPI_DOUBLE,dest,tag+1,comm);
      CPLM_checkMPIERR(ierr,"send_dense_val");
    }
  CPLM_END_TIME
  CPLM_POP
    return ierr;
  }





  int CPLM_MatDenseISend(CPLM_Mat_Dense_t* A_in, int dest, int tag, MPI_Comm comm, MPI_Request **request)
  {
  CPLM_PUSH
  CPLM_BEGIN_TIME

    int ierr = 0;
    MPI_Datatype MPI_INFO_DENSE = initMPI_StructDenseInfo();

    if(*request == NULL)
    {
      *request = (MPI_Request *)malloc(2*sizeof(MPI_Request));
      CPLM_ASSERT(*request != NULL);
    }


    // Send dense info
    ierr = MPI_Isend(&A_in->info,1,MPI_INFO_DENSE,dest,tag,comm,&((*request)[0]));
    CPLM_checkMPIERR(ierr,"send_dense_info");

    // Send data
    CPLM_debug("Will send %d data\n",A_in->info.m*A_in->info.n);
    ierr = MPI_Isend(A_in->val,(A_in->info.m)*(A_in->info.n),MPI_DOUBLE,dest,tag+1,comm,&((*request)[1]));
    CPLM_checkMPIERR(ierr,"send_vec");
  CPLM_END_TIME
  CPLM_POP
    return ierr;
  }





  int CPLM_MatDenseISendData(CPLM_Mat_Dense_t* A_in, int dest, int tag, MPI_Comm comm, MPI_Request **request)
  {
  CPLM_PUSH
  CPLM_BEGIN_TIME

    int ierr = 0;
    if(*request == NULL)
    {
      *request = (MPI_Request *)malloc(1*sizeof(MPI_Request));
      CPLM_ASSERT(*request != NULL);
    }

    // Send data
    CPLM_debug("Will send %d data\n",A_in->info.m*A_in->info.n);
    ierr = MPI_Isend(A_in->val,(A_in->info.m)*(A_in->info.n),MPI_DOUBLE,dest,tag,comm,*request);
    CPLM_checkMPIERR(ierr,"send_vec");
  CPLM_END_TIME
  CPLM_POP
    return ierr;
  }





  int CPLM_MatDenseRecv(CPLM_Mat_Dense_t* A_io, int source, int tag, MPI_Comm comm)
  {
  CPLM_PUSH
  CPLM_BEGIN_TIME

    int ierr  = 0;
    CPLM_Info_Dense_t info;
    MPI_Status status;

    MPI_Datatype MPI_INFO_DENSE = initMPI_StructDenseInfo();

    //recv information of the matrix
    ierr = MPI_Recv(&info,1,MPI_INFO_DENSE,source,tag,comm,&status);
    CPLM_checkMPIERR(ierr,"recv_dense_info");

    if(A_io->val == NULL)
    {
      ierr = CPLM_MatDenseCreate(A_io, info);CPLM_CHKERR(ierr);
    }
    else if(A_io->info.nval < info.nval)
    {
      A_io->info = info;
      ierr = CPLM_MatDenseRealloc(A_io);CPLM_CHKERR(ierr);
    }
    //recv values
    ierr = MPI_Recv(A_io->val,(A_io->info.m)*(A_io->info.n), MPI_DOUBLE,source,tag+1,comm,&status);
    CPLM_checkMPIERR(ierr,"recv_dense_val");

  CPLM_END_TIME
  CPLM_POP
    return ierr;
  }




  //Only _in because no work used
  int MatDenseIRecv(CPLM_Mat_Dense_t* A_in, int source, int tag, MPI_Comm comm, MPI_Request *request)
  {
  CPLM_PUSH
  CPLM_BEGIN_TIME

    printf("Not implemented AT ALL!!!!!\nIf you really want to use it, please check the function first :)\n");

    int ierr = 0;
#if 1
    CPLM_Info_Dense_t info;
    MPI_Status status;

    MPI_Datatype MPI_INFO_DENSE = initMPI_StructDenseInfo();

    //recv information of the matrix
    ierr = MPI_Irecv(&info,1,MPI_INFO_DENSE,source,tag,comm,request);
    CPLM_checkMPIERR(ierr,"recv_dense_info");
    MPI_Wait(request,&status);

    ierr = CPLM_MatDenseCreate(A_in, info);CPLM_CHKERR(ierr);

    //recv values
    ierr = MPI_Irecv(A_in->val,A_in->info.nval,MPI_DOUBLE,source,tag+1,comm,request);
    CPLM_checkMPIERR(ierr,"recv_dense_val");

#endif
  CPLM_END_TIME
  CPLM_POP
    return ierr;
  }





  int CPLM_MatDenseIRecvData(CPLM_Mat_Dense_t* A_in, int source, int tag, MPI_Comm comm, MPI_Request *request)
  {
  CPLM_PUSH
  CPLM_BEGIN_TIME
    int ierr = 0;
    //recv values
    ierr = MPI_Irecv(A_in->val,A_in->info.nval,MPI_DOUBLE,source,tag,comm,request);
    CPLM_checkMPIERR(ierr,"recv_dense_data");
  CPLM_END_TIME
  CPLM_POP
    return ierr;
  }





  int CPLM_MatDenseRecvInfo(CPLM_Mat_Dense_t* A_io, int source, int tag, MPI_Comm comm)
  {
  CPLM_PUSH
  CPLM_BEGIN_TIME

    int ierr  = 0;
    MPI_Status status;

    MPI_Datatype MPI_INFO_DENSE = initMPI_StructDenseInfo();

    //broadcast the matrix over all processes included into MPI comm group
    if (source == -1)
    {
      fprintf(stderr,"Broadcast is not managed for the moment\n");
      return 1;
    }
    else
    {
      //recv information of the matrix
      ierr = MPI_Recv(&(A_io->info),1,MPI_INFO_DENSE,source,tag,comm,&status);
      CPLM_checkMPIERR(ierr,"recv_dense_info");
    }
  CPLM_END_TIME
  CPLM_POP
    return ierr;
  }





  int CPLM_MatDenseRecvData(CPLM_Mat_Dense_t* A_io, int source, int tag, MPI_Comm comm)
  {
  CPLM_PUSH
  CPLM_BEGIN_TIME
  CPLM_OPEN_TIMER

    int ierr  = 0;
    MPI_Status status;

    CPLM_ASSERT(A_io->val != NULL);

    ierr = MPI_Recv(A_io->val,A_io->info.nval,MPI_DOUBLE,source,tag,comm,&status);
    CPLM_checkMPIERR(ierr,"recv_dense_val");

  CPLM_CLOSE_TIMER
  CPLM_END_TIME
  CPLM_POP
    return ierr;
  }





  int MatDenseIRecvInfo(CPLM_Mat_Dense_t* A_in, int source, int tag, MPI_Comm comm, MPI_Request *request)
  {
  CPLM_PUSH
  CPLM_BEGIN_TIME

    int ierr  = 0;
    CPLM_Info_Dense_t info;

    MPI_Datatype MPI_INFO_DENSE = initMPI_StructDenseInfo();

    //broadcast the matrix over all processes included into MPI comm group
    if (source == -1)
    {
      fprintf(stderr,"Broadcast is not managed for the moment\n");
      return 1;
    }
    else
    {
      //recv information of the matrix
      ierr = MPI_Irecv(&info,1,MPI_INFO_DENSE,source,tag,comm,request);
      CPLM_checkMPIERR(ierr,"recv_dense_info");
      CPLM_MatDenseInit(A_in,info);
    }
  CPLM_END_TIME
  CPLM_POP
    return ierr;
  }





  int CPLM_MatDenseIRecvRowConcat(CPLM_Mat_Dense_t* A_io, int offset, int source, int tag, MPI_Comm comm, MPI_Request *request)
  {
  CPLM_PUSH
  CPLM_BEGIN_TIME
    int ierr = 0;
    MPI_Status status;
    CPLM_Info_Dense_t info;
    MPI_Datatype MPI_INFO_DENSE = initMPI_StructDenseInfo();

    // Safety checks
    if (A_io == NULL)
    {
      CPLM_Abort("the matrix A must be allocated!\n");
    }

    if (offset%A_io->info.n != 0)
    {
      CPLM_Abort("the offset must correpond to the begining of a row!\n");
    }

    ierr = MPI_Irecv(&info,1,MPI_INFO_DENSE,source,tag,comm,request);
    CPLM_checkMPIERR(ierr,"irecv_dense_info");
    MPI_Wait(request,&status);

    if (A_io->info.stor_type == COL_MAJOR || info.stor_type == COL_MAJOR)
    {
      CPLM_Abort("COL_MAJOR storage is not supported yet!\n");
    }

    if (A_io->info.n != info.n)
    {
      CPLM_MatDensePrintInfo(A_io);
      CPLM_Abort("the received matrix has not the same number of cols as the matrix you want to fill!\n");
    }

    // We need to realloc memory
    if( offset + (info.m)*(info.n) > (A_io->info.m)*(A_io->info.n) ) {
      // OT:
      // this is not optimal: we could realloc less but it would be more
      // complicated
      CPLM_MatDenseSetInfo(A_io, A_io->info.M, A_io->info.N, A_io->info.m + info.m, A_io->info.n, A_io->info.stor_type);
      CPLM_MatDenseRealloc(A_io);
    }

    // Receive data of the value vector
    ierr = MPI_Irecv(&(A_io->val[offset]),(info.m)*(info.n),MPI_DOUBLE,source,tag+1,comm,request);
    CPLM_checkMPIERR(ierr,"irecv_mat_dense");

  CPLM_END_TIME
  CPLM_POP
    return ierr;
  }

#endif
/******************************************************************************/

/*
 *  Memory check allocation
 */
int CPLM_MatDenseMallocChk(CPLM_Mat_Dense_t *A_io,
                      const char  *file,
                      int         line,
                      const char  *varName)
{
CPLM_PUSH
CPLM_BEGIN_TIME

  A_io->val = (double*) CPLM_malloc(A_io->info.nval * sizeof(double),
    file,
    line,
    varName);

CPLM_END_TIME
CPLM_POP
  return !(A_io->val != NULL);
}





int CPLM_MatDenseCallocChk(CPLM_Mat_Dense_t *A_io,
                      const char  *file,
                      int         line,
                      const char  *varName)
{
CPLM_PUSH
CPLM_BEGIN_TIME

  A_io->val = (double*) CPLM_calloc(A_io->info.nval,
      sizeof(double),
      file,
      line,
      varName);

CPLM_END_TIME
CPLM_POP
  return !(A_io->val != NULL);
}





int CPLM_MatDenseReallocChk( CPLM_Mat_Dense_t  *A_io,
                        const char   *file,
                        int          line,
                        const char   *varName)
{
CPLM_PUSH
CPLM_BEGIN_TIME

  A_io->val = (double*) CPLM_realloc(A_io->val,
      A_io->info.nval * sizeof(double),
      file,
      line,
      varName);

CPLM_END_TIME
CPLM_POP
  return !(A_io->val != NULL);
}





void CPLM_MatDenseFreeChk( CPLM_Mat_Dense_t  *A_io,
                      const char   *file,
                      int          line,
                      const char   *varName)
{
CPLM_PUSH
  int ierr = 0;

  if(A_io)
  {
    if(A_io->val)
    {
      CPLM_free(A_io->val, file, line, varName);
    }
    A_io->val = NULL;
    ierr = CPLM_MatDenseReset(A_io);
    CPLM_ASSERT( ierr == 0);
  }
CPLM_POP
}



#ifndef MEMCHECK
int CPLM_MatDenseMalloc( CPLM_Mat_Dense_t *A_io)
{
CPLM_PUSH
CPLM_BEGIN_TIME

  A_io->val = (double*) malloc(A_io->info.nval * sizeof(double));

CPLM_END_TIME
CPLM_POP
  return !(A_io->val != NULL);
}





int CPLM_MatDenseCalloc(CPLM_Mat_Dense_t *A_io)
{
CPLM_PUSH
CPLM_BEGIN_TIME

  A_io->val = (double*) calloc(A_io->info.nval, sizeof(double));

CPLM_END_TIME
CPLM_POP
  return !(A_io->val != NULL);
}





int CPLM_MatDenseRealloc(CPLM_Mat_Dense_t  *A_io)
{
CPLM_PUSH
CPLM_BEGIN_TIME

  A_io->val = (double*) realloc(A_io->val, A_io->info.nval * sizeof(double));

CPLM_END_TIME
CPLM_POP
  return !(A_io->val != NULL);
}





void CPLM_MatDenseFree(CPLM_Mat_Dense_t  *A_io)
{
CPLM_PUSH
  int ierr = 0;

  if(A_io)
  {
    if(A_io->val)
    {
      free(A_io->val);
    }
    A_io->val = NULL;
    ierr = CPLM_MatDenseReset(A_io);
    CPLM_ASSERT( ierr == 0);
  }
CPLM_POP
}
#endif
