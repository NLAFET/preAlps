/*
* This file contains functions used to manipulate dense matrices
*
* Authors : Sebastien Cayrols
*         : Olivier Tissot
* Email   : sebastien.cayrols@[(gmail.com) | (inria.fr)]
*         : olivier.tissot@inria.fr
*/
#ifndef MAT_DENSE_H
#define MAT_DENSE_H

/******************************************************************************/
/*                                  STRUCT                                    */
/******************************************************************************/
/* Storage type of a dense matrix */
typedef enum {
  ROW_MAJOR,
  COL_MAJOR
} CPLM_storage_type_t;
/* Information about a dense matrix */
typedef struct {
  int M; // Global num of rows
  int N; // Global num of cols
  int m; // Local num of rows
  int n; // Local num of cols
  int lda; // Leading dimension of the matrix
  int nval; //  m*n ;
  CPLM_storage_type_t stor_type; // Row Major or Col Major storage
} CPLM_Info_Dense_t;
/* Dense Matrix structure */
typedef struct {
  double* val;
  CPLM_Info_Dense_t info;
} CPLM_Mat_Dense_t;
/******************************************************************************/


/******************************************************************************/
/*                                  INCLUDE                                   */
/******************************************************************************/
/* matcsr */
#include "mat_csr.h"
#include "ivector.h"
#include "dvector.h"
/* mpi */
#ifdef MPIACTIVATE
  #include <mpi.h>
#endif
#include <stddef.h>
/******************************************************************************/


#define PRINT_PARTIAL_M 10
#define PRINT_PARTIAL_N 10

/******************************************************************************/
/*                                    CODE                                    */
/******************************************************************************/

/* CPLM_Mat_Dense_t functions */
// Mem management
int CPLM_MatDenseSetInfo(CPLM_Mat_Dense_t* A, int M, int N, int m, int n, CPLM_storage_type_t stor_type);
int CPLM_MatDenseIsSameInfo(CPLM_Mat_Dense_t *A_in, CPLM_Mat_Dense_t *B_in);
int CPLM_MatDenseIsSameLocalInfo(CPLM_Mat_Dense_t *A_in, CPLM_Mat_Dense_t *B_in);
int CPLM_MatDenseInit(CPLM_Mat_Dense_t* A, CPLM_Info_Dense_t info);
/*
 *  Memory management
 */
#ifndef MEMCHECK
int CPLM_MatDenseMalloc( CPLM_Mat_Dense_t *A_io);

int CPLM_MatDenseCalloc( CPLM_Mat_Dense_t *A_io);

int CPLM_MatDenseRealloc(CPLM_Mat_Dense_t *A_io);

void CPLM_MatDenseFree(CPLM_Mat_Dense_t   *A_io);
#endif

int CPLM_MatDenseMallocChk(CPLM_Mat_Dense_t *A_io,
                      const char  *file,
                      int         line,
                      const char  *varName);

int CPLM_MatDenseCallocChk(CPLM_Mat_Dense_t *A_io,
                      const char  *file,
                      int         line,
                      const char  *varName);

int CPLM_MatDenseReallocChk(CPLM_Mat_Dense_t  *A_io,
                      const char    *file,
                      int           line,
                      const char    *varName);

void CPLM_MatDenseFreeChk( CPLM_Mat_Dense_t   *A_io,
                      const char  *file,
                      int         line,
                      const char  *varName);
#ifdef MEMCHECK
  #define CPLM_MatDenseMalloc(_m)  CPLM_MatDenseMallocChk((_m) , __FILE__, __LINE__, #_m)
  #define CPLM_MatDenseCalloc(_m)  CPLM_MatDenseCallocChk((_m) , __FILE__, __LINE__, #_m)
  #define CPLM_MatDenseRealloc(_m) CPLM_MatDenseReallocChk((_m), __FILE__, __LINE__, #_m)
  #define CPLM_MatDenseFree(_m)    CPLM_MatDenseFreeChk((_m)   , __FILE__, __LINE__, #_m)
#endif

int CPLM_MatDenseCreate(CPLM_Mat_Dense_t* A, CPLM_Info_Dense_t info);
int CPLM_MatDenseCreateZero(CPLM_Mat_Dense_t* A, CPLM_Info_Dense_t info);
int CPLM_MatDenseCreateFromPtr(CPLM_Mat_Dense_t *A_io, double *val);
int CPLM_MatDenseReset(CPLM_Mat_Dense_t* A);
int CPLM_MatDenseAddRows(CPLM_Mat_Dense_t* A, int nbRowToAdd);
int CPLM_MatDenseAddCols(CPLM_Mat_Dense_t* A, int nbColToAdd);
int CPLM_MatDenseCopy(CPLM_Mat_Dense_t* A_in, CPLM_Mat_Dense_t* B_out);
int CPLM_MatDenseFill(CPLM_Mat_Dense_t* A, double* val, int nval);
int CPLM_MatDenseVrtlConcat(CPLM_Mat_Dense_t *A, CPLM_Mat_Dense_t *B, CPLM_IVector_t *posB);
int CPLM_MatDenseReplaceColBlock(CPLM_Mat_Dense_t *A,CPLM_Mat_Dense_t *B, CPLM_IVector_t *posB, int numBlock);
int CPLM_MatDenseGetColPanel(CPLM_Mat_Dense_t *A_in, CPLM_Mat_Dense_t *B_out, CPLM_IVector_t *pos, CPLM_IVector_t *colPos, int numBlock);
int CPLM_MatDenseGetRowPanel(CPLM_Mat_Dense_t *A_in, CPLM_Mat_Dense_t *B_out, CPLM_IVector_t *pos, int numBlock);
int CPLM_MatDenseGetColBlockPos(CPLM_Mat_Dense_t *A, CPLM_IVector_t *pos, CPLM_IVector_t *colPos);
int CPLM_MatDenseGetDiag(CPLM_Mat_Dense_t *A_in, double **diag);
int CPLM_MatDenseGetRInplace(CPLM_Mat_Dense_t* A_io);
//Get a symbolic mat_dense_t matrix which is a subpart of the original one. WARNING Forbidden to free it!!!!
int CPLM_MatDenseGetSymRowPanel(CPLM_Mat_Dense_t *A_in, CPLM_Mat_Dense_t *B_out_s, CPLM_IVector_t *pos, int numBlock);
//Get a symbolic mat_dense_t matrix which is a subpart of the original one. WARNING Forbidden to free it!!!!
int CPLM_MatDenseGetSymColPanel(CPLM_Mat_Dense_t *A_in, CPLM_Mat_Dense_t *B_out_s, CPLM_IVector_t *pos, int numBlock);
// Initialization (it allocates memory)
int CPLM_MatDenseConstant(CPLM_Mat_Dense_t* A, double value);
int CPLM_MatDenseIdentity(CPLM_Mat_Dense_t* A);
int CPLM_MatDenseSetIdentity(CPLM_Mat_Dense_t* A);
int CPLM_MatDenseSetZeros(CPLM_Mat_Dense_t* A_io);
int CPLM_MatDenseRandom(CPLM_Mat_Dense_t* A_out, int generatorSeed);
// Printing
#define CPLM_MatDensePrintf2D(_msg,_A) { printf("%s\n",(_msg));                                              \
                                    ( ((_A)->info.m<PRINT_PARTIAL_M && (_A)->info.n<PRINT_PARTIAL_N) ?  \
                                        CPLM_MatDensePrint2D((_A))     :                                     \
                                        CPLM_MatDensePrintPartial2D((_A)) );}

void CPLM_MatDensePrintInfo(CPLM_Mat_Dense_t* A);
#define CPLM_MatDensePrintfInfo(_msg,_A) { printf("%s\n",(_msg));    \
                                      CPLM_MatDensePrintInfo((_A)); }

void CPLM_MatDensePrintPartial2D(CPLM_Mat_Dense_t* A);
void CPLM_MatDensePrint2D(CPLM_Mat_Dense_t* A);
// Function that copies a CPLM_IVector_t v into the index_jth column of a matrix M
// it stops if M is not allocated, returns 1 if index_j > M->info.n, returns 2 if the size of v and M doesn't match. It returns 0 otherwise.
int CPLM_MatDenseSetColumn(CPLM_Mat_Dense_t * M, CPLM_DVector_t *v, int index_j);

// Function gets a column of a matrix M and copies it to a CPLM_IVector_t v. it asserts that dimensions match
int CPLM_MatDenseGetColumn(CPLM_Mat_Dense_t *M, CPLM_DVector_t *v, int index_j);

// copies upper triangular of B in A starting from element A(i,j)
int CPLM_MatDenseTriangularFillBlock(CPLM_Mat_Dense_t *A_in, CPLM_Mat_Dense_t* B_io, int index_i, int index_j, int Size_R); //to be verified

// Utils
int CPLM_MatDenseRowPerm(CPLM_Mat_Dense_t* A, CPLM_IVector_t* rowPerm);

int CPLM_MatDenseColPerm(CPLM_Mat_Dense_t*  A_io, 
                    CPLM_IVector_t*    colPerm, 
                    double        **work, 
                    size_t        *workSize);

// Function that fills B_io in a block of A_in that starts on B_io[index_i][index_j];
int CPLM_MatDenseBlockFill(CPLM_Mat_Dense_t* A_in, CPLM_Mat_Dense_t* B_io, int index_i, int index_j);

int CPLM_MatDenseToDVector(CPLM_Mat_Dense_t* A, CPLM_DVector_t* v);

int CPLM_MatDenseToMatCSR(CPLM_Mat_Dense_t *A_in, CPLM_Mat_CSR_t *B_out);

//Convert a row_major matrix into a column one or vice-versa
int CPLM_MatDenseConvertMajor(CPLM_Mat_Dense_t *A_in, CPLM_Mat_Dense_t *B_out);

int CPLM_MatDenseSwap(CPLM_Mat_Dense_t *A_io, CPLM_Mat_Dense_t *B_io);

// Test
int CPLM_MatDenseTestFunction(int rank); // Some tests
// MPI wrappers
#ifdef MPIACTIVATE
  int CPLM_MatDenseSend(CPLM_Mat_Dense_t* A, int dest, int tag, MPI_Comm comm);
  int CPLM_MatDenseISend(CPLM_Mat_Dense_t* A, int dest, int tag, MPI_Comm comm, MPI_Request **request);
  int CPLM_MatDenseRecv(CPLM_Mat_Dense_t* A_io, int source, int tag, MPI_Comm comm);
  int CPLM_MatDenseIRecvRowConcat(CPLM_Mat_Dense_t* A,
                             int offset,
                             int source,
                             int tag,
                             MPI_Comm comm,
                             MPI_Request *request);
  int CPLM_MatDenseRecvInfo(CPLM_Mat_Dense_t* A_io,
                       int          source,
                       int          tag,
                       MPI_Comm     comm);
  // Send val only
  int CPLM_MatDenseISendData(CPLM_Mat_Dense_t*  A_io,
                        int           source,
                        int           tag,
                        MPI_Comm      comm,
                        MPI_Request **request);
  // Recv val only
  int CPLM_MatDenseRecvData(CPLM_Mat_Dense_t* A_io,
                       int          source,
                       int          tag,
                       MPI_Comm     comm);
  int CPLM_MatDenseIRecvData(CPLM_Mat_Dense_t* A_in,
                        int          source,
                        int          tag,
                        MPI_Comm     comm,
                        MPI_Request *request);
#endif

#define CPLM_MatDenseNULL() { .val = NULL, .info = {.M=0, .N=0, .m=0, .n=0, .stor_type=ROW_MAJOR, .lda = 0, .nval = 0} }

/******************************************************************************/

#endif
