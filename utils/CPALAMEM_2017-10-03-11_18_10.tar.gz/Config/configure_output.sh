#######################################
#title            : configure_output.sh
#description      : This file handles the output of the configure i.e creates Makefile
#authors          : Sebastien Cayrols
#email            : sebastien.cayrols@[\(gmail.com\)|\(inria.fr\)]
#date             : 12/29/2016
#version          : 0.1
#usage            : source configure_output.sh in another file
#notes            :
#######################################

#LIBRARY PATH
CONFIG_OUTPUT="#==============================\n"
#CONFIG_OUTPUT+="PATHS to the main folders\n\n"
CONFIG_OUTPUT+="CPALAMEM_ROOT=$ROOT\n"
CONFIG_OUTPUT+="CPALAMEM_LIB=${ROOT}/${LIB}\n"
CONFIG_OUTPUT+="CPALAMEM_INC=${ROOT}/${INC}\n"
CONFIG_OUTPUT+="CPALAMEM_BIN=${ROOT}/$BIN\n"

#Internal structure folder
CONFIG_OUTPUT+="BIN=$BIN\n"
CONFIG_OUTPUT+="INC=$INC\n"
CONFIG_OUTPUT+="LIB=$LIB\n"
CONFIG_OUTPUT+="BUILD=${ROOT}/${SRC}/build\n"

#EXEC modes : DEBUG/DEV/BENCHMARK
CONFIG_OUTPUT+="CPALAMEM_X_DEBUG=CPALAMEM_DEBUG\n"
CONFIG_OUTPUT+="CPALAMEM_X_DEV=CPALAMEM_DEV\n"
CONFIG_OUTPUT+="CPALAMEM_X_BENCH=CPALAMEM_BENCHMARK\n"

CONFIG_OUTPUT+="DEBUGFOLDER=debug\n"
CONFIG_OUTPUT+="DEVFOLDER=dev\n"
CONFIG_OUTPUT+="RELEASEFOLDER=release\n"

CONFIG_OUTPUT+="CORELIBNAME=${LIBNAME}_core\n"

if [ "$DEBUG" -eq 1 ];then
  CONFIG_OUTPUT+="COMPILMODE=DEBUG\n"
  CONFIG_OUTPUT+="EXEC_MODE=CPALAMEM_DEBUG\n"
elif [ "$OPTIM" -eq 1 ];then
  CONFIG_OUTPUT+="COMPILMODE=BENCH\n"
  CONFIG_OUTPUT+="EXEC_MODE=CPALAMEM_BENCHMARK\n"
else
  CONFIG_OUTPUT+="COMPILMODE=DEV\n"
  CONFIG_OUTPUT+="EXEC_MODE=CPALAMEM_DEV\n"
fi

#Package informations
CONFIG_OUTPUT+=$pkgOutput
CONFIG_OUTPUT+="LIBMPI=${LIBMPI}\n"
if [ ! -z "${MKL_FLAGS}" ]; then
  CONFIG_OUTPUT+="MKL_FLAGS=${MKL_FLAGS}\n"
fi

CONFIG_OUTPUT+="CC=$lCC\n"
CONFIG_OUTPUT+="CFLAGS=$lCFLAGS\n"
CONFIG_OUTPUT+="CFLAGS_CPALAMEM=$DEFINE\n"
CONFIG_OUTPUT+="CFLAGS_OPT=$lOPTFLAGS\n"
CONFIG_OUTPUT+="CFLAGS_DEBUG=$lCFLAGSDEBUG\n"

echo -e "------------------------------------------------\n"
echo -e "\nPARAMETERS set up :\n$CONFIG_OUTPUT"

for dir in ${makeDirList[*]} ; do
  i=$ROOT/$dir
  (cd $i && touch Makefile && touch Makefile.env &&
    echo -e "$CONFIG_OUTPUT" >Makefile.env &&
    echo "include Makefile.env" >Makefile &&
    echo "include Makefile.in" >>Makefile &&
    echo "Makefile created in $i")\
  || echo "Error during configuration of Makefile in $i"
done

echo -e "\n===============================\n"
echo -e "End of configuration\nNext step is make\n"
