#######################################
#title            : CPALAMEM_config_env.sh
#description      : This file contains environment variables used by the configure
#authors          : Sebastien Cayrols
#email            : sebastien.cayrols@[\(gmail.com\)|\(inria.fr\)]
#date             : 12/29/2016
#version          : 0.1
#usage            : source CPALAMEM_config_env.sh in another file
#notes            :
#######################################
#Index of a package in PKG_DATA
MPI_ID=0
MKL_ID=1
LAPACK_ID=2
PETSC_ID=3
METIS_ID=4
SUITESPARSE_ID=5
CPALAMEM_ID=6


#Position of package info in temporary DATA
PKGNAME=0
PKGHEADERFILE=1
PKGLIBFILE=2
PKGINCPATH=3
PKGLIBPATH=4
PKGHEADERFILE2=5
PKGLIBFILE2=6
PKGINCPATH2=7
PKGLIBPATH2=8

