#!/bin/bash
#######################################
#title            : configure_stdfun.sh
#description      : This file contains all standard functions I use
#authors          : Sebastien Cayrols
#email            : sebastien.cayrols@[\(gmail.com\)|\(inria.fr\)]
#date             : 12/29/2016
#version          : 0.1
#usage            : source configure_stdfun.sh in another file
#notes            :
#######################################
#LIST OF FUNCTIONS
#function exists()
#function checkDep()
#function search()
#function innerSearch()
#function selectOne()
#function bold()
#function error()
#######################################




#check if program exists
#PARAM
# $1  is the executable to test
function exists(){

  (`which $1 &>/dev/null`) || ( (`ls $1 &>/dev/null`) || (echo "Error, $1 can not be found in the PATH" && exit 1) )

}

#Check if a library has the include and the library given in parameter
#PARAM
# $1 the name of the library
# $2 the header to search in the folder
# $3 the library name to search in the folder
# $4 the include path
# $5 the library path
function checkDep(){
  #Store param locally
  local LIBNAME=$1
  local header=$2
  local libfile=$3
  local LIB_INC=$4
  local LIB_LIB=$5

 #echo "checkDep :: $LIBNAME $header $libfile $LIB_INC $LIB_LIB"


  echo -ne "\tSearch $LIBNAME env ... \n"

  if [ -z ${LIB_INC} -a -z ${LIB_LIB} ]; then
    error "the ${LIBNAME}_ROOT variable is not set"
    read -e -p "Provide the right path to ${LIBNAME} dir " LPATH
    LIB_INC=$LPATH
    LIB_LIB=$LPATH

    echo -n "Trying to locate ${LPATH} "
    if [ ! -d ${LPATH} ]; then
      error "${LPATH} is not a directory" 1
    else
      echo "[DONE]"
    fi
  fi

  innerSearch $header $LIB_INC
  RTN_INC=${RTN}

  innerSearch $libfile $LIB_LIB
  RTN_LIB=${RTN}

  echo -e "$LIBNAME env \t\t[SET]"
}



function search(){
  local file=$1
  local NAME_ROOT=$2
  if [ $# -eq 3 ];then
    NAME_DIR=$3 #OPTIONAL
  else
    NAME_DIR=
  fi

  if [ ! -z ${NAME_DIR} ];then
    list=( $(find -L ${NAME_DIR} -name "${file}" -exec dirname {} \;) )
  else
    list=( $(find -L ${NAME_ROOT} -name "${file}" -exec dirname {} \;) )
  fi
  ndir=${#list[@]}
  if [ ${ndir} -eq 0 ];then
    if [ ! -z ${NAME_DIR} ];then
      error "Can not find ${file} from ${NAME_DIR}" 1
    else
      error "Can not find ${file} from ${NAME_ROOT}" 1
    fi
  fi

  if [ ${ndir} -eq 1 ];then
    NAME_DIR=${list[0]}
  else
    echo "Several directories contain ${file}"
    for i in `seq ${ndir}`; do
      echo "[${i}] ${list[((${i}-1))]}"
    done
    read -p "Which one to select? " ANSWER
    if [ ! -z ${ANSWER} ] && [ ${ANSWER} -gt 0 ] && [ ${ANSWER} -le ${ndir} ]; then
      NAME_DIR=${list[((${ANSWER}-1))]}
    else
      error "Wrong choice" 1
    fi
  fi

}




#This function searches a file in a path
#PARAM
# $1 the wondered file
# $2 the path where to search
function innerSearch(){
  local file=$1
  local DIR=$2

  local list=($(find -L ${DIR} -name "${file}" -exec dirname {} \; | sort -u))
  if [ ${#list[@]} -gt 0 ];then
    selectOne "Several directories containing ${file}" "${list[@]}"
  else
    error "${DIR} does not contain ${file}" 1
  fi
}





#$1 message to print if greater than 1 choice
#$2 list of element whom to choose one
function selectOne(){
  local msg=$1
  shift
  local list=("$@")
  local answer=""
 #echo "selectOne :: msg ${msg} list ${list[@]}"

  if [ ${#list[@]} -eq 1 ]; then
    RTN=${list[0]}
  else
    echo "${msg}"
    for j in `seq ${#list[@]}`; do
      echo "[${j}] ${list[$((j-1))]}"
    done
    read -p "Which one to select? " answer
    if [ ! -z "${answer}" ] && [ "${answer}" -gt 0 ] && [ "${answer}" -le "${#list[@]}" ]; then
      RTN=${list[((${answer}-1))]}
    else
      error "Wrong choice" 1
    fi
  fi
 #echo "selectOne :: RTN ${RTN}"
}




#print in bold text
function bold(){

  echo -e "\033[1m$1\033[0m"

}





#print error message and can exit if two parameters are given
#PARAM
# $1    is the message to be displayed
# $2    is the exit code (OPTIONAL)
function error(){

  echo -e "\nError,\t${1}\n"
  if [ $# -eq 2 ]; then
    echo -e "\t\tConfiguration aborted\n"
    rm ${LOGFILE}_tmp
    exit $2
  fi

}





#Function removes word from a string and optionally the following one
#PARAM
# $1 is the string to clean up
# $2 is the pattern to remove
# $3 is used to say : I would like to remove the word after the pattern search
function cleanStr(){
  local str1="$1"

  if [ -z "$str1" ]; then 
    RETURN_STR=""
    return
  fi 

  local match=$2
  if [ $# -eq 3 ];then
    local pattern="\ [a-zA-Z0-9_\-]*"
  fi

  #Find the match into the string
  matching=$(echo $str1 | grep -ow -e "${match}${pattern}" | grep -m 1 -e "${match}${pattern}")
  if [ ! -z "$matching" ]; then
    echo "Remove $matching FROM $str1"
    RETURN_STR=$(echo "$str1" | sed 's/'"${matching}"'//g')
  else
    RETURN_STR=$str1
  fi
}



#Function updates a list of param by removing the old one and adding the new one
#PARAM
# $1 is the parameter list
# $2 is the pattern to remove
# $3 is used to say : I would like to remove the word after the pattern search
function updateParamList(){
  local str=$1
  local match=$2
  local newParam="$match"
  if [ $# -eq 3 ];then
    local value=$3
    cleanStr "$str" "$match" "$value"
    newParam="$newParam $value"
  else
    cleanStr "$str" "$match"
  fi

  RETURN_UPDATEPARAMLIST="$RETURN_STR $newParam"

}













