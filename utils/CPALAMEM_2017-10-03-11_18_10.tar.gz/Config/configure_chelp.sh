#######################################
#title            : configure_chelp.sh
#description      : This file contains generic help print message to configure the library
#authors          : Sebastien Cayrols
#email            : sebastien.cayrols@[\(gmail.com\)|\(inria.fr\)]
#date             : 12/29/2016
#version          : 0.1
#usage            : source configure_chelp.sh in another file
#notes            :
#######################################

#========================
#       print help
# If you include the standard function,
#you can use the bold function to print
#========================

#USAGE
#To add a new library here, please add a XXXPrintHelp function and add it 
# into the case part like other examples
#----------------------


DEFAULT="[DEFAULT]"

#This function print library message description and usage
#Take in param 
# $1 : the name of the option
# $2 : the 'with' message
# $3 : the 'without' message
# $4 : without one is default <0|1>
# $5 : OPTIONAL a remark
function printHelpMsg(){
  optionName=$1
  with=$2
  without=$3
  msg1=""
  msg2=""

  if [ "$4" -ne 0 ]; then msg1="${DEFAULT}"; else msg2="${DEFAULT}"; fi

  bold    "\t--with-${optionName}"
  echo -e "\t\t${with}${msg1}"
  bold    "\t--without-${optionName}"
  echo -e "\t\t${without}${msg2}"

  #Useless for the moment
  if [ $# -gt 4 ]; then echo -e "\t\t\tREMARK : $2\n"; fi
}

#==========================================
#
#             MAIN
#
#==========================================
#This function print the help for the program. It takes in param
# an array of library to print and the default usage like
# $@ : mpi 1 petsc 0 
# which means mpi and petsc are set and only mpi is activated by default
function chelp {
# echo "$# param given to chelp : $@"
  echo -e "\t\t\t\tGeneral Commands Manual\t\t\t\t"
  bold    "NAME"
  echo -e "\t$0 - sets environment variables and creates Makefiles"
  bold    "SYNOPSIS"
  echo -e "\t$0 [OPTIONS]"
  bold    "DESCRIPTION"
  echo -e "\tNone"
  bold    "OPTIONS"
  while [ $# -gt 0 ]; do
    case $1 in
      debug)
        debugPrintHelp "disabled"
        shift
        ;;
      optimize)
        optimizePrintHelp "disabled"
        shift
        ;;
      compiler)
        compilerPrintHelp "Default compiler is ${CC:-"empty"}"
        shift
        ;;
      mkl| lapack| mpi| suitesparse| metis| petsc| openmp| cpalamem)
        ${1}PrintHelp ${2}
        shift
        shift
        ;;
      *)
        error "$1 is an unknown library" 1
        ;;
    esac
 done
 bold    "\t-h,\t--help"
 echo -e "\t\tThis option prints the help\n"
 echo    " "
}


#========================================
#         Message of libraries
#========================================

function mpiPrintHelp(){
  printHelpMsg  "mpi"\
  "This option activates parallel parts of the code"\
  "This option disables parallel parts of the code"\
  $1
}

function mklPrintHelp(){
  printHelpMsg  "mkl"\
  "This option activates MKL management"\
  "This option disables MKL management"\
  $1
}

function petscPrintHelp(){
  printHelpMsg "petsc"\
  "This option activates PETSC environment"\
  "This option disables PETSC environment"\
  $1
}

function suitesparsePrintHelp(){
  printHelpMsg "suitesparse"\
  "This option activates SUITESPARSE environment"\
  "This option disablees SUITESPARSE environment"\
  $1
}

function metisPrintHelp(){
  printHelpMsg "metis"\
  "This option activates METIS environment"\
  "This option disables METIS environment"\
  $1
}

function openmpPrintHelp(){
  printHelpMsg "openmp"\
  "This option activates OPENMP flags"\
  "This option disables OPENMP flags"\
  $1
}

function optimizePrintHelp(){
  bold    "\t-O,\t--Optimize"
  echo -e "\t\tThis option activates BENCHMARK mode\n"
  if [ $# -gt 0 ]; then echo -e "\t\t\tREMARK : $1\n"; fi
}

function debugPrintHelp(){
  bold    "\t-d,\t--debug"
  echo -e "\t\tThis option activates DEBUG mode\n"
  if [ $# -gt 0 ]; then echo -e "\t\t\tREMARK : $1\n"; fi
}

function compilerPrintHelp(){
  bold    "\t--cc <C compiler>"
  echo -e "\t\tThis option sets the C compiler\n"
  if [ $# -gt 0 ]; then echo -e "\t\t\tREMARK : $1\n"; fi
}

function lapackPrintHelp(){
  printHelpMsg "lapack"\
  "This option activates LAPACK management"\
  "This option disables LAPACK management"\
  $1
}

function cpalamemPrintHelp(){
  printHelpMsg "cpalamem"\
  "This option activates CPALAMEM management"\
  "This option disables CPALAMEM management"\
  $1
}


