/*
* This file contains functions used to manipulate sparse matrices 
*
* Authors : Sebastien Cayrols
*         : Remi Lacroix
* Email   : sebastien.cayrols@[(gmail.com) | (inria.fr)]
*/
/**
 * \file mat_csr.h
 * \brief Structure to store a matrix into a CSR format
 * \author Sebastien Cayrols and Remi Lacroix
 * \version 0.2
 * \date 20 june 2013
 *
 * Structure which manipulate the CSR format
 *
 *  For any question, email :  sebastien.cayrols@[(gmail.com) | (inria.fr)]
 *  DO NOT DISTRIBUTE
 */
#ifndef MAT_CSR_H
#define MAT_CSR_H

/******************************************************************************/
/*                                  STRUCT                                    */
/******************************************************************************/
/**
 *  \enum
 *
 */
typedef enum {
  FORMAT_CSR,
  FORMAT_BCSR,
  FORMAT_BCSR_VAR // strange BCRS variant used by PETSc, the values aren't stored by block
} CPLM_Mat_CSR_format_t;

/**
 *  \enum Struct_Type
 *  \brief This enumeration contains information about structure
 */
typedef enum {
  UNSYMMETRIC,
  SYMMETRIC
} Struct_Type;

typedef enum{
  SEQUENTIAL,
  PARALLEL
} Distribution;

/**
 *  \enum Choice_permutation
 *
 */
typedef enum {
  AVOID_PERMUTE,
  PERMUTE
} Choice_permutation;

/**
 *  \struct CPLM_Info_t
 *  \brief Structure which represents the structure of the CSR matrix
 */
/*Structure represents main informations from a CPLM_Mat_CSR_t*/
typedef struct{
  int M;                  //Global num of rows
  int N;                  //Global num of cols
  int nnz;                //Global non-zeros entries
  int m;                  //Local num of rows
  int n;                  //Local num of cols
  int lnnz;               //Local non-zeros entries
  int blockSize;          //Local block size
  CPLM_Mat_CSR_format_t format;//Local storage format : block or not
  Struct_Type structure;  //Local symmetric or unsymmetric pattern
} CPLM_Info_t;

/**
 *  \struct CPLM_Mat_CSR_t
 *  \brief Structure which represents a CSR format to store a matrix with the smallest size in memory
 *
 */
typedef struct {
  CPLM_Info_t info;
  int* rowPtr; //A pointer to an array of size M+1 or m+1
  int* colInd; //A pointer to an array of size nnz or lnnz
  double* val; //A pointer to an array of size nnz or lnnz
} CPLM_Mat_CSR_t;

/******************************************************************************/


/******************************************************************************/
/*                                  INCLUDE                                   */
/******************************************************************************/

#include <stddef.h>
#include "ivector.h"
#include "dvector.h"
#include "mat_dense.h"

/******************************************************************************/


#define PRINT_PARTIAL_M 10
#define PRINT_PARTIAL_N 10
#define _PRECISION 4

void CPLM_MatCSRConvertTo0BasedIndexing(CPLM_Mat_CSR_t *mat);
void CPLM_MatCSRConvertTo1BasedIndexing(CPLM_Mat_CSR_t *mat);

//the following part has been added by Sebastien Cayrols 18/06/2013

#define CPLM_MatCSRNULL() { .info={ .M=0, .N=0, .nnz=0, .m=0, .n=0, .lnnz=0, .blockSize=0, .format=FORMAT_CSR, .structure=UNSYMMETRIC }, .rowPtr=NULL, .colInd=NULL, .val=NULL }

/*Function dupplicates a CPLM_Mat_CSR_t matrix*/
int CPLM_MatCSRCopy(CPLM_Mat_CSR_t *m1, CPLM_Mat_CSR_t *m2);

/*Function dupplicates the structure of a CPLM_Mat_CSR_t matrix*/
int CPLM_MatCSRCopyStruct(CPLM_Mat_CSR_t *m1, CPLM_Mat_CSR_t *m2);

/*Function prints a matrix in 2D format*/
void CPLM_MatCSRPrint2D(CPLM_Mat_CSR_t *m);

void CPLM_MatCSRPrintPartial2D(CPLM_Mat_CSR_t *m);
/*Function prints informations of the matrix*/
void CPLM_MatCSRPrintInfo(CPLM_Mat_CSR_t *m);

/*Function prints a matrix in CSR format*/
void CPLM_MatCSRPrint(CPLM_Mat_CSR_t *m);

/*Function prints a matrix in CSR format*/
#define CPLM_MatCSRPrintf(_msg,_m) { printf("%s\n",(_msg));    \
                                    CPLM_MatCSRPrint((_m)); }

#define CPLM_MatCSRPrintf2D(_msg,_A) { printf("%s\n",(_msg));                                              \
                                  ( ((_A)->info.m<PRINT_PARTIAL_M && (_A)->info.n<PRINT_PARTIAL_N) ?  \
                                      CPLM_MatCSRPrint2D((_A))     :                                       \
                                      CPLM_MatCSRPrintPartial2D((_A))  ); }

#define CPLM_MatCSRPrintfInfo(_msg,_m) { printf("%s\n",(_msg));  \
                                    CPLM_MatCSRPrintInfo((_m)); }

/*Function saves a CPLM_Mat_CSR_t matrix in a file*/
int CPLM_MatCSRSave(CPLM_Mat_CSR_t *m, const char *filename);

/*Function deletes diagonal element from a CPLM_Mat_CSR_t matrix*/
int CPLM_MatCSRDelDiag(CPLM_Mat_CSR_t *m1, CPLM_Mat_CSR_t *m2);

/*
 * Create a general CSR matrix m2 from a symetric CSR matrix m1.
 */
int CPLM_MatCSRUnsymStruct(CPLM_Mat_CSR_t *m1, CPLM_Mat_CSR_t *m2);

/*Function symmetrizes a CPLM_Mat_CSR_t matrix and delete its diagonal*/
int CPLM_MatCSRSymStruct(CPLM_Mat_CSR_t *m1, CPLM_Mat_CSR_t *m2);

/*Function which permutes CPLM_Mat_CSR_t matrix with vec and ivec vector*/
int CPLM_MatCSRPermute(CPLM_Mat_CSR_t *A_in, CPLM_Mat_CSR_t *B_out, int *rowPerm, int *colPerm, Choice_permutation permute_values);

//function which returns a submatrice at CSR format from an original matrix (in CSR format too) and filtered by parts
//num_parts corresponds to the number which selects rows from original matrix and interval allows to select the specific rows
int CPLM_MatCSRGetSub(CPLM_Mat_CSR_t *m1, CPLM_Mat_CSR_t *m2, int *interval, int num_parts);

//This version assumes that the row splitting is also applied on the columns otherwise, use MatCSRGetSubBlock instead
int CPLM_MatCSRGetSubMatrix( CPLM_Mat_CSR_t *A_in,
                        CPLM_Mat_CSR_t *B_out,
                        CPLM_IVector_t *pos,
                        CPLM_IVector_t *colPos,
                        int       numRBlock,
                        int       numCBlock,
                        CPLM_IVector_t *work);

//This version extracts a block
int CPLM_MatCSRGetSubBlock ( CPLM_Mat_CSR_t *A_in,
                        CPLM_Mat_CSR_t *B_out,
                        CPLM_IVector_t *posR,
                        CPLM_IVector_t *posC,
                        int       numRBlock,
                        int       numCBlock,
                        int       **work,
                        size_t    *workSize);

int CPLM_MatCSRGetPartialColBlockPos(CPLM_Mat_CSR_t *m,
                                CPLM_IVector_t *posR,
                                int       numBlock,
                                CPLM_IVector_t *posC,
                                CPLM_IVector_t *colPos);

//Normally, this version is faster than matCSRGetSub
int CPLM_MatCSRGetRowPanel(CPLM_Mat_CSR_t *m1, CPLM_Mat_CSR_t *m2, CPLM_IVector_t *interval, int num_parts);

int CPLM_MatCSRGetColPanel(CPLM_Mat_CSR_t *m1, CPLM_Mat_CSR_t *m2, CPLM_IVector_t *pos, CPLM_IVector_t *colPos, int num_parts);

int CPLM_MatCSRGetDiagBlock(CPLM_Mat_CSR_t *A_in, CPLM_Mat_CSR_t *B_out, CPLM_IVector_t *pos, CPLM_IVector_t *colPos, int structure);
//function which returns a submatrice at CSR format from an original matrix (in CSR format too) and filtered by parts
int CPLM_MatCSRGetSubFromVector(CPLM_Mat_CSR_t *m1, CPLM_Mat_CSR_t *m2, CPLM_IVector_t *v);

//function which returns a submatrice at CSR format from an original matrix (in CSR format too) and filtered by parts but not square
int CPLM_MatCSRGetRectFromInt(CPLM_Mat_CSR_t *m1, CPLM_Mat_CSR_t *m2, int begin, int end);

int CPLM_MatCSRGetSubFromInterval(CPLM_Mat_CSR_t *m1, CPLM_Mat_CSR_t *m2, int begin, int end);

int CPLM_MatCSRGetRecFromVector(CPLM_Mat_CSR_t *m1, CPLM_Mat_CSR_t *m2, CPLM_IVector_t *v);

//function which returns a square submatrice at CSR format from a rectangular matrix (in CSR format too) and filtered by parts
int CPLM_MatCSRGetSqrtFromVector(CPLM_Mat_CSR_t *m1, CPLM_Mat_CSR_t *m2, CPLM_IVector_t *v);

//function which returns a submatrice at CSR format from an original matrix (in CSR format too) and filtered by two vectors
int CPLM_MatCSRGetSubFromVectors(CPLM_Mat_CSR_t *m1, CPLM_Mat_CSR_t *m2, CPLM_IVector_t *vl, CPLM_IVector_t *vc);//

//Function which test if these two CSR matrices are the same
int CPLM_MatCSRIsEqual(CPLM_Mat_CSR_t *m1, CPLM_Mat_CSR_t *m2);

int CPLM_MatCSRIsAbsEqual(CPLM_Mat_CSR_t *m1, CPLM_Mat_CSR_t *m2);

//Function which test if these two CSR matrices have the same structure
int CPLM_MatCSRIsSameStruct(CPLM_Mat_CSR_t *m1, CPLM_Mat_CSR_t *m2);

int CPLM_MatCSRIsSym(CPLM_Mat_CSR_t *m);

//function which test all functions written here
void CPLM_MatCSRTestFunction();

int CPLM_MatCSRChkDiag(CPLM_Mat_CSR_t *m);

int CPLM_MatCSRGetDiagInd(CPLM_Mat_CSR_t *m, CPLM_IVector_t *v);

int CPLM_MatCSRGetDiagIndOfPanel(CPLM_Mat_CSR_t *A_in, CPLM_IVector_t *d_out, CPLM_IVector_t *pos, CPLM_IVector_t *colPos, int numBlock);

#ifdef MPIACTIVATE
  int CPLM_MatCSRSend(CPLM_Mat_CSR_t *m, int dest, MPI_Comm comm);

  int CPLM_MatCSRBcastInfo(CPLM_Info_t *info, int source, MPI_Comm comm);

  int CPLM_MatCSRRecv(CPLM_Mat_CSR_t *m, int source, MPI_Comm comm);
#endif

int CPLM_MatCSRSetInfo(CPLM_Mat_CSR_t *A_out, int M, int N, int nnz, int m, int n, int lnnz, int blockSize);

int CPLM_MatCSRCreate(CPLM_Mat_CSR_t *m, int *rows, int *cols, double *vals);

int CPLM_MatCSRCreateFromPtr(CPLM_Mat_CSR_t *A_in, int *rowPtr, int *colInd, double *val );

/*
 *  Memory management
 */
#ifndef MEMCHECK
int CPLM_MatCSRMalloc(CPLM_Mat_CSR_t *A_io);

int CPLM_MatCSRRealloc(CPLM_Mat_CSR_t *A_io);

void CPLM_MatCSRFree(CPLM_Mat_CSR_t *A_io);
#endif

int CPLM_MatCSRMallocChk(CPLM_Mat_CSR_t   *A_io,
                    const char  *file,
                    int         line,
                    const char  *varName);

int CPLM_MatCSRReallocChk( CPLM_Mat_CSR_t   *A_io,
                      const char  *file,
                      int         line,
                      const char  *varName);

void CPLM_MatCSRFreeChk( CPLM_Mat_CSR_t   *A_io,
                    const char  *file,
                    int         line,
                    const char  *varName);

#ifdef MEMCHECK
  #define CPLM_MatCSRMalloc(_m)  CPLM_MatCSRMallocChk( (_m) , __FILE__, __LINE__, #_m)
  #define CPLM_MatCSRRealloc(_m) CPLM_MatCSRReallocChk( (_m), __FILE__, __LINE__, #_m)
  #define CPLM_MatCSRFree(_m)    CPLM_MatCSRFreeChk( (_m)   , __FILE__, __LINE__, #_m)
#endif

int CPLM_MatCSRInit(CPLM_Mat_CSR_t *m, CPLM_Info_t *info);

//Get column starting index of each block in m
int CPLM_MatCSRGetColBlockPos(CPLM_Mat_CSR_t *m, CPLM_IVector_t *pos, CPLM_IVector_t *colPos);

int CPLM_MatCSRConvertToDenseDVector(CPLM_Mat_CSR_t *m_in, CPLM_DVector_t *v_out);

int CPLM_MatCSRToMatDense(CPLM_Mat_CSR_t *A_in, CPLM_Mat_Dense_t *B_out);

int CPLM_MatCSRConvertFromDenseDVector(CPLM_Mat_CSR_t *m, CPLM_DVector_t *v, int M, int N);

int CPLM_MatCSRGetCommDep(CPLM_IVector_t *colPos, int m, int nblock, int bi, CPLM_IVector_t *dep);

int CPLM_MatCSRGetColPanels(CPLM_Mat_CSR_t *m1, CPLM_Mat_CSR_t *m2, CPLM_IVector_t *pos, CPLM_IVector_t *colPos, CPLM_IVector_t *numBlock);

int CPLM_MatCSRAddExplicitZeros(CPLM_Mat_CSR_t *m1, CPLM_Mat_CSR_t *m2);

int CPLM_MatCSRGetNormInf(CPLM_Mat_CSR_t *A_in, double *normInf);

int CPLM_MatCSRGetLUFactors(CPLM_Mat_CSR_t *A_in,
    CPLM_Mat_CSR_t *L_out,
    CPLM_Mat_CSR_t *U_out,
    CPLM_IVector_t *diagPtr);
#endif /* MAT_CRS_H */
