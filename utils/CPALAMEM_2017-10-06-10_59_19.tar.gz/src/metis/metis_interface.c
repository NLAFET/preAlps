/*
* This file contains functions used for interfacing metis
*
* Authors : Sebastien Cayrols
* Email   : sebastien.cayrols@[(gmail.com) | (inria.fr)]
*/
/**
 * \file ordering_matCSR.c
 * \brief File contains methods to reorder a CSR matrix
 * \author Sebastien Cayrols
 * \version 0.1
 * \date 24 june 2013
 *
 *
 */


#include <stdio.h>
#include <stdlib.h>

#include <cpalamem_macro.h>
#include <metis_interface.h>
#include <cpalamem_instrumentation.h>

idx_t* callKway(CPLM_Mat_CSR_t *matCSR, idx_t nbparts)
{
CPLM_PUSH
CPLM_BEGIN_TIME

  int ierr  = 0;
  idx_t nvtxs   = 0;
	idx_t ncon    = 1;
  idx_t *parts  = NULL;
	idx_t *xadj   = NULL;
  idx_t *adjncy = NULL;
  idx_t objval  = 0;

  //variable utilisée pour Kway donc recopie au bon type
	nvtxs = (idx_t)matCSR->info.M;

	//test if malloc has succeed
	parts   = (idx_t*)malloc (nvtxs             * sizeof(idx_t));
	xadj    = (idx_t*)malloc((nvtxs + 1)        * sizeof(idx_t));
	adjncy  = (idx_t*)malloc((matCSR->info.nnz) * sizeof(idx_t));

  CPLM_ASSERT(parts  != NULL);
  CPLM_ASSERT(xadj   != NULL);
  CPLM_ASSERT(adjncy !=  NULL);

	//copy the value of the matrix which is in CSR format int to CSR format idx_t
	for(int i = 0; i < nvtxs + 1; i++)
		xadj[i] = matCSR->rowPtr[i];

	for(int i = 0; i < matCSR->info.nnz; i++)
		adjncy[i] = matCSR->colInd[i];

	//call Metis function to get _NBPARTS blocks from the matrix represented by xadj and adjncy array
	ierr = METIS_PartGraphKway(&nvtxs,&ncon,xadj,adjncy,NULL,NULL,NULL,&nbparts,NULL,NULL,NULL,&objval,parts);

	//Match the return value of METIS_PartGraphKway function
	switch(ierr)
  {
	  case METIS_ERROR:
	  	fprintf(stderr,"Error\n");
	  	exit(1);
	  	break;
	  case METIS_ERROR_INPUT:
	  	fprintf(stderr,"Error INPUT\n");
	  	exit(1);
	  	break;
	  case METIS_ERROR_MEMORY:
	  	fprintf(stderr,"Error MEMORY\n");
	  	exit(1);
	  case METIS_OK:
	  	break;
	  default:
	  	fprintf(stderr,"Unknown value returned by METIS_PartGraphKway\n");
	  	exit(1);
	}

	free(xadj);
	free(adjncy);

CPLM_END_TIME
CPLM_POP
	return parts;

}

/**
 * \fn int CPLM_metisKwayOrdering(CPLM_Mat_CSR_t *matCSR, CPLM_IVector_t *perm, int _nbparts, CPLM_IVector_t *interval_vec)
 * \brief Function calls Kway partitionning algorithm and return a new matrix permuted
 * \param *m1 The original matrix
 * \param *perm This vector contains data of permutation
 * \param nbparts Number of partition for Kway
 * \param *posB This vector contains first index of each block
 * \return TODO
 */
int CPLM_metisKwayOrdering(CPLM_Mat_CSR_t *m1,
    CPLM_IVector_t *perm,
    int nblock,
    CPLM_IVector_t *posB)
{
CPLM_PUSH
CPLM_BEGIN_TIME

  CPLM_Mat_CSR_t m2 = CPLM_MatCSRNULL();
  int ierr  = 0;
  int M     = 0;
  idx_t nvtxs   = 0;
  idx_t *parts  = NULL;

  M = m1->info.M;

  // If nothing to do
  if(nblock == 1)
  {
    ierr = CPLM_IVectorMalloc(posB, nblock + 1);CPLM_CHKERR(ierr);

    posB->val[0]  = 0;
    posB->val[1]  = M;//[WARNING] It could be with -1

CPLM_END_TIME
CPLM_POP
    return ierr;
  }

  // The matrix has to be symmetric and without diagonal elements
  if(m1->info.structure==UNSYMMETRIC)
  {
    ierr = CPLM_MatCSRSymStruct(m1, &m2);CPLM_CHKERR(ierr);
	}
  else
  {
	  ierr = CPLM_MatCSRDelDiag(m1, &m2);CPLM_CHKERR(ierr);
	}

  nvtxs = (idx_t)M;
  parts = callKway(&m2,nblock);

  ierr = CPLM_getBlockPosition(M, parts, nblock, posB);CPLM_CHKERR(ierr);
	ierr = CPLM_getIntPermArray(nblock, nvtxs, parts, perm);CPLM_CHKERR(ierr);

  if (parts != NULL) 
    free(parts);

  CPLM_MatCSRFree(&m2);

CPLM_END_TIME
CPLM_POP
  return ierr;
}
