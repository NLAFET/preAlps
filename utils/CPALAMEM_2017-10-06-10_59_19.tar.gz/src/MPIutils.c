/*
* This file contains functions used to manipulate dvector
*
* Authors : Sebastien Cayrols
*         : Olivier Tissot
* Email   : sebastien.cayrols@[(gmail.com) | (inria.fr)]
*         : olivier.tissot@inria.fr
*/
/**
 * \file MPIutils.c
 * \brief File which contains methods and function used in codes
 * \author Sebastien Cayrols
 * \version 0.1
 * \date 21 june 2013
 *
 */
#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>

#include "cpalamem_macro.h"
#include "MPIutils.h"
#include "mat_csr.h"
#include "mat_dense.h"
#include "cpalamem_instrumentation.h"


/**
 * \fn void CPLM_checkMPIERR(int cr, int rank, const char *action)
 * \brief Method which checks the returned code returned by MPI
 * Note : This method is more explicit if DEBUG is defined
 * \param cr The value returned by MPI call
 * \param rank The rank of the process which calls a MPI function
 * \param *action The name of the action
 */
/*Function which checks the return of an MPI call*/
void CPLM_checkMPIERR(int cr, const char *action){

#ifdef DEBUG
	switch(cr){
		case MPI_SUCCESS :
				printf("%s -- SUCCESS\n",action);
				break;
		case MPI_ERR_COMM :
				printf("ERR_COMM of %s\n",action);
				break;
		case MPI_ERR_COUNT :
				printf("ERR_COUNT of %s\n",action);
				break;
		case MPI_ERR_TYPE :
				printf("ERR_TYPE of %s\n",action);
				break;
		case MPI_ERR_TAG :
				printf("ERR_TAG of %s\n",action);
				break;
		case MPI_ERR_RANK :
				printf("ERR_RANK of %s\n",action);
				break;
		default :
			fprintf(stderr,"(%d) unknown value of cr for %s\n",cr,action);
			exit(2);
	}
#else

	switch(cr){
		case MPI_SUCCESS :
/*		    printf("[%d]%s\n",rank,action);*/
				break;
		default :
			fprintf(stderr,"(%d) unknown value of cr for %s\nYou have to compile again with -DDEBUG\n",cr,action);
			exit(2);
	}

#endif
}



MPI_Datatype initMPI_StructCSR(){

  CPLM_Mat_CSR_t m;

  MPI_Datatype MPI_MAT_CSR;
	MPI_Datatype type[_NB_CHAMPS]={MPI_INT,//M
											 MPI_INT,//N
											 MPI_INT,//nnz
											 MPI_INT,//m
											 MPI_INT,//n
											 MPI_INT,//lnnz
											 MPI_INT,//blockSize
											 MPI_INT,//type has to change and check with right struct called CPLM_Mat_CSR_format_t
											 MPI_INT
											 };

	int blocklen[_NB_CHAMPS];
	for(int i=0;i<_NB_CHAMPS;i++)
		blocklen[i]=1;

	MPI_Aint disp[_NB_CHAMPS];
	MPI_Aint addr[_NB_CHAMPS+1];

	MPI_Get_address(&m,               &addr[0]);
	MPI_Get_address(&m.info.M,        &addr[1]);
	MPI_Get_address(&m.info.N,        &addr[2]);
	MPI_Get_address(&m.info.nnz,      &addr[3]);
	MPI_Get_address(&m.info.m,        &addr[4]);
	MPI_Get_address(&m.info.n,        &addr[5]);
	MPI_Get_address(&m.info.lnnz,     &addr[6]);
	MPI_Get_address(&m.info.blockSize,&addr[7]);
	MPI_Get_address(&m.info.format,   &addr[8]);
	MPI_Get_address(&m.info.structure,&addr[9]);

  for(int i=0;i<_NB_CHAMPS;i++)
    disp[i] = addr[i+1] - addr[0];

	MPI_Type_create_struct(_NB_CHAMPS,blocklen,disp,type,&MPI_MAT_CSR);
  MPI_Type_commit(&MPI_MAT_CSR);

  return MPI_MAT_CSR;
}

MPI_Datatype initMPI_StructDenseInfo(){
  CPLM_Info_Dense_t info;

  MPI_Datatype MPI_DENSE_INFO;
  MPI_Datatype type[_NB_CHAMPS_DENSE] = {MPI_INT,//M
                                         MPI_INT,//N
                                         MPI_INT,//m
                                         MPI_INT,//n
                                         MPI_INT,//lda
                                         MPI_INT,//nval
                                         MPI_INT//type has to change and check with right struct called CPLM_storage_type_t
                                 };

  int blocklen[_NB_CHAMPS_DENSE];
  for(int i=0;i<_NB_CHAMPS_DENSE;i++)
    blocklen[i]=1;

  MPI_Aint disp[_NB_CHAMPS_DENSE];
  MPI_Aint addr[_NB_CHAMPS_DENSE+1];

  MPI_Get_address(&info,           &addr[0]);
  MPI_Get_address(&info.M,         &addr[1]);
  MPI_Get_address(&info.N,         &addr[2]);
  MPI_Get_address(&info.m,         &addr[3]);
  MPI_Get_address(&info.n,         &addr[4]);
  MPI_Get_address(&info.lda,       &addr[5]);
  MPI_Get_address(&info.nval,      &addr[6]);
  MPI_Get_address(&info.stor_type, &addr[7]);

  for(int i=0;i<_NB_CHAMPS_DENSE;i++)
    disp[i] = addr[i+1] - addr[0];

  MPI_Type_create_struct(_NB_CHAMPS_DENSE,blocklen,disp,type,&MPI_DENSE_INFO);
  MPI_Type_commit(&MPI_DENSE_INFO);

  return MPI_DENSE_INFO;
}
