/*
* This file contains functions used to manipulate ivector
*
* Authors : Sebastien Cayrols
* Email   : sebastien.cayrols@[(gmail.com) | (inria.fr)]
*/
/**
 * \file ivector.c
 * \brief Structure to store an Integer Vector with an array of values and its size
 * \author Sebastien Cayrols
 * \version 0.1
 * \date 21 june 2013
 *
 *  For any question, email :  sebastien.cayrols@[(gmail.com) | (inria.fr)]
 *  DO NOT DISTRIBUTE
 */
#ifndef IVECTOR_H
#define IVECTOR_H

#ifdef MPIACTIVATE
  #include <mpi.h>
#endif

/**
 *	\struct CPLM_IVector_t
 *	\brief Structure which represents a CPLM_IVector_t with its values and its size
 *
 */
/*Structure utilized to store an array of values and a length*/
typedef struct{
	int *val;
	int nval;
  int size;
} CPLM_IVector_t;

#define IVECTOR_MAXVAL_PRINT 10

int CPLM_IVectorPermute(CPLM_IVector_t *in, CPLM_IVector_t *perm, CPLM_IVector_t *out);

/*Function which inverts a vector*/
int CPLM_IVectorInvert(CPLM_IVector_t *in, CPLM_IVector_t *out);

#define CPLM_IVectorPrintfWork(_msg,_v)  { printf("%s of %d/%d : ",\
    (_msg),(_v)->nval,(_v)->size);   \
    CPLM_IVectorPrintWorkPartial((_v)); }

#define CPLM_IVectorPrintf(_msg,_v)  { printf("%s of %d/%d : ",\
    (_msg),(_v)->nval,(_v)->size);   \
    CPLM_IVectorPrintPartial((_v)); }

#define CPLM_IVectorPrintfFull(_msg,_v)  { printf("%s of %d/%d : ",\
    (_msg),(_v)->nval,(_v)->size);   \
    CPLM_IVectorPrint((_v)); }

#define CPLM_IVectorPrintfWorkFull(_msg,_v)  { printf("%s of %d/%d : ",\
    (_msg),(_v)->nval,(_v)->size);   \
    CPLM_IVectorPrintWork((_v)); }

/*Function prints a CPLM_IVector_t called name*/
void CPLM_IVectorPrint(CPLM_IVector_t *v);

void CPLM_IVectorPrintPartial(CPLM_IVector_t *v);

void CPLM_IVectorPrintWork(CPLM_IVector_t *v);

void CPLM_IVectorPrintWorkPartial(CPLM_IVector_t *v);

#ifdef MPIACTIVATE
  /*Function sends a CPLM_IVector_t to send_to*/
  int CPLM_IVectorSend(CPLM_IVector_t *vec, int dest, int tag, MPI_Comm comm);

  /*Function returns a CPLM_IVector_t received from source*/
  int CPLM_IVectorRecv(CPLM_IVector_t *v, int source, int tag, MPI_Comm comm);

  /*Function sends a CPLM_IVector_t to All proc*/
  int CPLM_IVectorBcast(CPLM_IVector_t *v, MPI_Comm comm, int root);

  int CPLM_IVectorISend(CPLM_IVector_t *v, int dest, int tag, MPI_Comm comm, MPI_Request **request);

  int CPLM_IVectorIRecv(CPLM_IVector_t *v, int source, int tag, MPI_Comm comm, MPI_Request *request);

  int CPLM_IVectorWait( CPLM_IVector_t   *v,
                   MPI_Request *request,
                   MPI_Status  *status);
#endif

/*Function returns True if v1 and v2 contain the same value*/
int CPLM_IVectorIsSame(CPLM_IVector_t *v1, CPLM_IVector_t *v2);

/*Function returns an union of two vectors*/
int CPLM_IVectorFusion(CPLM_IVector_t *v1, CPLM_IVector_t *v2, CPLM_IVector_t *v3);

int CPLM_IVectorConcatInPlace(CPLM_IVector_t *v1, CPLM_IVector_t *v2, const char c);

int CPLM_IVectorOffsetCopy(CPLM_IVector_t *v1, CPLM_IVector_t *v2, int offset);

int CPLM_IVectorSort(CPLM_IVector_t *v);

/*Function returns a copy of v*/
int CPLM_IVectorCopy(CPLM_IVector_t *v1, CPLM_IVector_t *v2);

int CPLM_IVectorCountNNZ(CPLM_IVector_t *v, int *sum);

int CPLM_IVectorReduce(CPLM_IVector_t *v, int *sum);

int CPLM_IVectorSum(CPLM_IVector_t *u_in, CPLM_IVector_t *v_in, CPLM_IVector_t *w_out, int op);

int CPLM_IVectorSub(CPLM_IVector_t *v1, int begin, int size, CPLM_IVector_t *v2);

int CPLM_IVectorGetPos(CPLM_IVector_t *v, int a, int *pos);

int CPLM_IVectorLoad(const char *fileName, CPLM_IVector_t *buf, int size);

int CPLM_IVectorSave(CPLM_IVector_t *v,const char *fileName, const char *header);

/*
 *  Memory management
 */
#ifndef MEMCHECK
int CPLM_IVectorMalloc(CPLM_IVector_t   *v,
                  int         length);

int CPLM_IVectorRealloc( CPLM_IVector_t *v,
                    int       length);

int CPLM_IVectorCalloc(CPLM_IVector_t *v,
                  int       length);

void CPLM_IVectorFree(CPLM_IVector_t *v);
#endif

int CPLM_IVectorMallocChk( CPLM_IVector_t   *v,
                      int         length,
                      const char  *file,
                      int         line,
                      const char  *varName);

int CPLM_IVectorReallocChk(CPLM_IVector_t   *v,
                      int         length,
                      const char  *file,
                      int         line,
                      const char  *varName);

int CPLM_IVectorCallocChk( CPLM_IVector_t   *v,
                      int         length,
                      const char  *file,
                      int         line,
                      const char  *varName);

void CPLM_IVectorFreeChk(CPLM_IVector_t   *v,
                    const char  *file,
                    int         line,
                    const char  *varName);

#ifdef MEMCHECK
  #define CPLM_IVectorMalloc(_v, _length)   CPLM_IVectorMallocChk((_v) , (_length), __FILE__, __LINE__, #_v)
  #define CPLM_IVectorCalloc(_v, _length)   CPLM_IVectorCallocChk((_v) , (_length), __FILE__, __LINE__, #_v)
  #define CPLM_IVectorRealloc(_v, _length)  CPLM_IVectorReallocChk((_v), (_length), __FILE__, __LINE__, #_v)
  #define CPLM_IVectorFree(_v)              CPLM_IVectorFreeChk((_v)   ,            __FILE__, __LINE__, #_v)
#endif

int CPLM_IVectorAddSpace(CPLM_IVector_t *v, int length);

int CPLM_IVectorConstant(CPLM_IVector_t *v, int cst);

int CPLM_IVectorSequence(CPLM_IVector_t *v, int begin, int end, int step);

int CPLM_IVectorRandom(CPLM_IVector_t *v, int generatorSeed);

int CPLM_IVectorRemove(CPLM_IVector_t *v, CPLM_IVector_t *r);

int CPLM_IVectorCreateFromPtr(CPLM_IVector_t *v, int length, int *val);

int CPLM_IVectorCreate(CPLM_IVector_t *v, int length, int *val);

int CPLM_IVectorShiftValues(CPLM_IVector_t *v, int shift);

int CPLM_IVectorSwap(CPLM_IVector_t *v1, CPLM_IVector_t *v2);

/* \brief This function copies data of v1 in v2. Condition v2 memory space is already allocated and have the same size as v1 */
int CPLM_IVectorCopyData(CPLM_IVector_t *v1, CPLM_IVector_t *v2);

void CPLM_IVectorTestFunction();

#define CPLM_IVectorNULL() { .nval=0, .size=0, .val=NULL }

#endif
