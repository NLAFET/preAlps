/*
* This file contains functions used to perform SpMM in parallel
*
* Authors : Sebastien Cayrols
*         : Olivier Tissot
* Email   : sebastien.cayrols@[(gmail.com) | (inria.fr)]
*         : olivier.tissot@inria.fr
*/

/******************************************************************************/
/*                                  INCLUDE                                   */
/******************************************************************************/
#ifndef MATMULT_H
#define MATMULT_H

/* STD */
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
/* MPI */
#include <mpi.h>
/* CPaLAMeM */
#include <mat_dense.h>
#include <ivector.h>
/******************************************************************************/

/******************************************************************************/
/*                                    CODE                                    */
/******************************************************************************/
// C = sum_{i = 0:nb_procs} (A^t)*B
  //This function computes in parallel C_out = alpha * A_in * B_in + beta * C_out
  int CPLM_MatDenseMatMult(  CPLM_Mat_Dense_t* A_in,
                        char         transa,
                        CPLM_Mat_Dense_t* B_in,
                        char         transb,
                        CPLM_Mat_Dense_t* C_io,
                        double       alpha,
                        double       beta,
                        MPI_Comm comm);

  int CPLM_MatDenseMatDotProd(CPLM_Mat_Dense_t* A_in,
                         CPLM_Mat_Dense_t* B_in,
                         CPLM_Mat_Dense_t* C_out,
                         MPI_Comm comm);

  // matMultVersion:
  // 0: Standard Iprobe
  // 1: Ignore diagonal block Iprobe
  // 2: Standard Irecv
  // 3: Ignore diagonal block Irecv
  int CPLM_MatCSRMatMult(CPLM_Mat_CSR_t   *A_in,
                    CPLM_Mat_Dense_t *RHS_in,
                    CPLM_IVector_t   *dest,
                    int          nrecv,
                    CPLM_Mat_Dense_t *C_out,
                    CPLM_IVector_t   *pos,
                    CPLM_IVector_t   *colPos,
                    CPLM_IVector_t   *rowPtr_io,
                    MPI_Comm     comm,
                    int          matMultVersion);

  // Convert colPos and shift colInd in order to extract more easily
  // col panels of A during matmult
  int CPLM_MatCSRInitializeMatMult(CPLM_Mat_CSR_t* A_io,
                              CPLM_IVector_t* pos_in,
                              CPLM_IVector_t* colPos_io,
                              CPLM_IVector_t* rowPtr_out,
                              CPLM_storage_type_t stor_type,
                              CPLM_IVector_t* dest,
                              int nrecv);

  // Convert back to get the initial A_io
  int CPLM_MatCSRFinalizeMatMult(CPLM_Mat_CSR_t* A_io,
                            CPLM_IVector_t* pos_in,
                            CPLM_IVector_t* colPos_io,
                            CPLM_storage_type_t stor_type,
                            CPLM_IVector_t* dest,
                            int nrecv);

/******************************************************************************/

#endif
