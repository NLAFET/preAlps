/*
* This file contains functions used to manipulate dvector
*
* Authors : Sebastien Cayrols
*         : Olivier Tissot
* Email   : sebastien.cayrols@[(gmail.com) | (inria.fr)]
*         : olivier.tissot@inria.fr
*/
#ifndef MPIUTILS_H
#define MPIUTILS_H

#ifdef MPIACTIVATE
#include <mpi.h>

//define the number of champ in the structure Partial_CPLM_Mat_CSR_t
#define _NB_CHAMPS 9
#define _NB_CHAMPS_DENSE 7
/*Function which checks the return of an MPI call*/
void CPLM_checkMPIERR(int cr, const char *action);

MPI_Datatype initMPI_StructCSR();

MPI_Datatype initMPI_StructDenseInfo();
#endif
#endif
