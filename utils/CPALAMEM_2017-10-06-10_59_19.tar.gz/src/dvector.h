/*
* This file contains functions used to manipulate dvector
*
* Authors : Sebastien Cayrols
*         : Olivier Tissot
* Email   : sebastien.cayrols@[(gmail.com) | (inria.fr)]
*         : olivier.tissot@inria.fr
*/
#ifndef DVECTOR_H
#define DVECTOR_H

typedef struct{
	double *val;
	int nval;
} CPLM_DVector_t;

#include <math.h>
#ifdef MPIACTIVATE
  #include <mpi.h>
#endif
#include <ivector.h>
#include <mat_dense.h>

int CPLM_DVectorPermute(CPLM_DVector_t *in, CPLM_IVector_t *perm, CPLM_DVector_t *out);

#define CPLM_DVectorPrintf(_msg,_v)  { printf("%s of size %d : ",(_msg),(_v)->nval);   \
                                    CPLM_DVectorPrint((_v));  }
/*Function prints a CPLM_IVector_t called name*/
void CPLM_DVectorPrint(CPLM_DVector_t *v);

void CPLM_DVectorPrint2D(CPLM_DVector_t *v, int m, int lda, const char *name, int sumUp);

#ifdef MPIACTIVATE
  /*Function sends a CPLM_IVector_t to send_to*/
  int CPLM_DVectorSend(CPLM_DVector_t *v, int dest,   int tag, MPI_Comm comm);
  /*Function returns a CPLM_IVector_t received from recv_from*/
  int CPLM_DVectorRecv(CPLM_DVector_t *v, int source, int tag, MPI_Comm comm);
  /*Function all gathers local vectors into a new  global one and*/
  /*send it to all proc*/
  int CPLM_DVectorAllGather(CPLM_DVector_t *loc_v, CPLM_DVector_t *glo_v, MPI_Comm comm);

  int CPLM_DVectorIRecv(CPLM_DVector_t *v, int source, int tag, MPI_Comm comm, MPI_Request *request);

  int CPLM_DVectorIRecvConcat( CPLM_DVector_t   *v_io,
                          int         offset,
                          int         source,
                          int         tag,
                          MPI_Comm    comm,
                          int         nvalRecvd,
                          MPI_Request *request);

  int CPLM_DVectorISend(CPLM_DVector_t *v, int dest, int tag, MPI_Comm comm, MPI_Request **request);

  int CPLM_DVectorLoadAndDistribute(const char *filename,
                               CPLM_DVector_t *bufLocal_out,
                               CPLM_IVector_t* pos_in,
                               MPI_Comm comm);

#endif

/*Function returns True if v1 and v2 contain the same value*/
int CPLM_DVectorIsSame(CPLM_DVector_t *v1, CPLM_DVector_t *v2);

int CPLM_DVectorSave(CPLM_DVector_t *v,const char *fileName, const char *header);

int CPLM_DVectorLoad(const char *fileName, CPLM_DVector_t *buf, int size);

int CPLM_DVectorIsNAN(CPLM_DVector_t *v);

int CPLM_DVectorAddSpace(CPLM_DVector_t *v, int length);


/*
 *  Memory allocation
 */
#ifndef MEMCHECK
int CPLM_DVectorMalloc(CPLM_DVector_t   *v_out,
                  int         length);

int CPLM_DVectorCalloc(CPLM_DVector_t *v_out,
                  int       length);

int CPLM_DVectorRealloc( CPLM_DVector_t *v_io,
                    int       length);

void CPLM_DVectorFree(CPLM_DVector_t   *v_io);
#endif
/*
 *  Memory allocation checkers
 */
int CPLM_DVectorMallocChk( CPLM_DVector_t   *v_out,
                      int         length,
                      const char  *file,
                      int         line,
                      const char  *varName);

int CPLM_DVectorCallocChk( CPLM_DVector_t *v_out,
                    int         length,
                    const char  *file,
                    int         line,
                    const char  *varName);

int CPLM_DVectorReallocChk(CPLM_DVector_t   *v_io,
                      int         length,
                      const char  *file,
                      int         line,
                      const char  *varName);

void CPLM_DVectorFreeChk(CPLM_DVector_t   *v_io,
                    const char  *file,
                    int         line,
                    const char  *varName);

#if defined MEMCHECK
  #define CPLM_DVectorMalloc(_v, _length)  CPLM_DVectorMallocChk((_v) , (_length), __FILE__, __LINE__, #_v);
  #define CPLM_DVectorCalloc(_v, _length)  CPLM_DVectorCallocChk((_v) , (_length), __FILE__, __LINE__, #_v);
  #define CPLM_DVectorRealloc(_v, _length) CPLM_DVectorReallocChk((_v), (_length), __FILE__, __LINE__, #_v);
  #define CPLM_DVectorFree(_v)             CPLM_DVectorFreeChk((_v)   ,            __FILE__, __LINE__, #_v);
#endif
/*
 *  Fill-in
 */
int CPLM_DVectorRandom(CPLM_DVector_t *v, int generatorSeed);

int CPLM_DVectorConstant(CPLM_DVector_t* v, double value);

int CPLM_DVectorCopy(CPLM_DVector_t *vin, CPLM_DVector_t *vout);

int CPLM_DVectorCreate(CPLM_DVector_t *v, int length, double *val);

int CPLM_DVectorCreateFromPtr(CPLM_DVector_t *v, int length, double *val);

int CPLM_DVectorConcatInPlace(CPLM_DVector_t *v1, CPLM_DVector_t *v2, const char c);

int CPLM_DVectorAbsDiff(CPLM_DVector_t *v_in, CPLM_DVector_t *w_in, double *sum);

int CPLM_DVector2NormSquared(CPLM_DVector_t* v, double* norm);

int CPLM_DVector2Norm(CPLM_DVector_t* v, double* norm);

int CPLM_DVectorGetNorm1(CPLM_DVector_t* v_in, double* norm1);

void CPLM_DVectorTestFunction();

/* v -> A */
int CPLM_DVectorToMatDense(CPLM_DVector_t* v, CPLM_Mat_Dense_t* A, int m, int n, CPLM_storage_type_t stor_type);

/* \brief This function copies data of v1 in v2. Condition v2 memory space is already allocated and have the same size as v1 */
int CPLM_DVectorCopyData(CPLM_DVector_t *v1, CPLM_DVector_t *v2);

int CPLM_DVectorSwap(CPLM_DVector_t *v1, CPLM_DVector_t *v2);

#define CPLM_DVectorNULL() { .nval=0, .val=NULL }

#endif
