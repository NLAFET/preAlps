#if 1
/*
* This file contains functions used for tracking symbolic pointer in a workspace
*
* Authors : Sebastien Cayrols
* Email   : sebastien.cayrols@[(gmail.com) | (inria.fr)]
*/

  //---------------------------------
  //STATIC PART * Do not modify *
  //---------------------------------

  /*
  CHANGEPRINT       //Formate print messages with rank
  CHECK             //Activate some checking as ASSERT and CHKERR functions
  CHRONO            //Allow to get time for each function
  MEMCHECK          //Check if memory is correctly allocated
  STACKTRACE        //Get the way of call
  */

  //Used as standard development
  #ifdef CPALAMEM_DEV
    #define MEMCHECK
    #define CHECK
    #define STACKTRACE
  #endif

  //Used to debug code
  #ifdef CPALAMEM_DEBUG
    #define STACKTRACE
    #define STACKTRACEPRINT
    #define MEMCHECK
    #define CHECK
    #define DEBUG
  #endif

  //Used as production mode
  #ifdef CPALAMEM_BENCHMARK
    #undef STACKTRACE
    #undef STACKTRACEPRINT
    #undef MEMCHECK
    #undef CHECK
    #undef CHANGEPRINT
    #undef CHRONO
    #define TIMERACTIVATE
  #endif

//#ifdef STACKTRACE
//  //This macro handle the stacktrace printing
//  #define STACKTRACEPRINT
//#endif

  #ifdef MEMCHECK
    //This macro allows to print memory statement as address, size and origin
    #define PRINTMEMSTATE
    //This macro allows to check if all memory allocated by the program has been freed
    #define MEMCHECKCONSUMPTION
  #endif

#endif
