/*
* This file contains functions used for handling errors of the library
*
* Authors : Sebastien Cayrols
* Email   : sebastien.cayrols@[(gmail.com) | (inria.fr)]
*/
/**
 * \file cpalamem_instrumentation.c
 * \brief Some functions used to develop and debug some codes
 * \author Sebastien Cayrols
 * \version 0.1
 * \date 21 june 2013
 *
 *
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <libgen.h>
#include <stdarg.h>
#ifdef MPIACTIVATE
  #include <mpi.h>
#else
  #include <time.h>
#endif
#ifdef PETSCACTIVATE
  #include <petscsys.h>
#endif
#include <cpalamem_handler.h>
#include <cpalamem_stacktrace.h>
#include <cpalamem_macro.h>


void CPLM_efprintf(const char *signal, const char *fun, const char *format, va_list va)
{
  int rank = 0;
  char msg[1024];

  #ifdef MPIACTIVATE
    MPI_Comm_rank(MPI_COMM_WORLD,&rank);
  #endif

  vsnprintf(msg, sizeof(msg), format, va);
  snprintf(msg, sizeof(msg), "[Proc: %u]" " %s\n", rank, format);

  fprintf(stderr,"\n%s from %s : %s\n"
  #ifdef STACKTRACE
                  "\tStackTrace::%s\n"
  #endif
                  ,signal
                  ,fun
                  ,msg
  #ifdef STACKTRACE
                  ,curStack->allFun
  #endif
                  );
}





void CPLM_FAbort(const char *fun,  const char *format, ...)
{
  int ierr = 1;
  va_list v;

  va_start(v, format);

  CPLM_efprintf(CPALAMEMSIGABRT, fun, format, v);

  va_end(v);

  #ifdef MPIACTIVATE
  MPI_Abort(MPI_COMM_WORLD, ierr);
  #else
  abort();
  #endif
}





void CPLM_esprintf( const char *signal,
                        const char *fun,
                        const char *format,
                        ...)
{
  va_list v;

  va_start(v, format);

  CPLM_efprintf(signal, fun, format, v);

  va_end(v);
}





void CPLM_stdFErr(const char  *fun,
                      const char  *file,
                      const int   line,
                      const int   ierr)
{

  CPLM_esprintf(CPALAMEMSIGERR, fun, "Error in %s, line %d\tcode : %d\n",
      file,
      line,
      ierr);

}
