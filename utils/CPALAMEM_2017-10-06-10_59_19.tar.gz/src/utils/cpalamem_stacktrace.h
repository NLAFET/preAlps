/*
* This file contains functions used for tracking the stacktrace
*
* Authors : Sebastien Cayrols
* Email   : sebastien.cayrols@[(gmail.com) | (inria.fr)]
*/
#ifndef CPALAMEM_STACKTRACE_H
#define CPALAMEM_STACKTRACE_H

#define CPLM_printCurrentStack()  printf(  "STACK : \tallFun %s\n" \
                                      "\t\tfun %s\n"          \
                                      "\t\tnext %p\n"         \
                                      ,curStack->allFun       \
                                      ,curStack->fun          \
                                      ,(void*)curStack->next);


#ifdef STACKTRACE
  #define CPLM_PUSH  CPLM_pushStack("%s", __FUNCTION__);
  #define CPLM_POP   CPLM_popStack();
#else
  #define CPLM_PUSH
  #define CPLM_POP
#endif /*STACKTRACE*/


typedef struct stack{
  //Symbolic usage of fun. All informations are in allFun
  char *fun;          //Current function name
  char *allFun;       //List of the previous functions in the stack
  struct stack *next;
} CPLM_Stack_t;

extern CPLM_Stack_t *curStack;

extern void CPLM_pushStack(const char * format, ...);

extern void CPLM_popStack();

void CPLM_initStack();

#endif /*CPALAMEM_STACKTRACE_H*/
