/*
* This file contains functions used for handling errors
*
* Authors : Sebastien Cayrols
* Email   : sebastien.cayrols@[(gmail.com) | (inria.fr)]
*/
#ifndef CPALAMEM_HANDLER_H
#define CPALAMEM_HANDLER_H

#include <stdarg.h>

#define CPALAMEMSIGERR  "ERROR"
#define CPALAMEMSIGWRN  "WARNING"
#define CPALAMEMSIGABRT "ABORTING"

#ifdef DEBUG
  #define CPLM_debug(_format, _args...) printf((_format), ##_args)

  #define CPLM_printVec(_v, _len, _name, _pattern) {       \
            printf("\t%s : [", (_name));              \
            for(int _cpt = 0; _cpt< (_len);_cpt++){  \
              printf((_pattern), (_v)[_cpt]);         \
            }                                         \
            printf("]\n");                            \
          }
#else
  #define CPLM_debug(_format, _args...)
  #define CPLM_printVec(_v, _len, _name, _pattern)
#endif

#ifdef CHECK
  #define CPLM_ASSERT(_t)  if(!(_t))\
    { CPLM_Abort(" wrong test '" #_t "' line %d", __LINE__);}

  #define CPLM_CHKERR(_e) \
    if((_e) != 0){\
      if(CPALAMEM_curFun) { CPALAMEM_curFun((_e)); }\
      CPLM_stdErr((_e));\
      CPLM_popStack();\
      return (_e);\
    } CPALAMEM_curFun = NULL;
  #define CPLM_HANDLER(_f) CPALAMEM_curFun = (_f);
#else
  #define CPLM_ASSERT(_t)
  #define CPLM_CHKERR(_e)
  #define CPLM_HANDLER(_f)
#endif

void (*CPALAMEM_curFun)(int);

#ifdef CHANGEPRINT
#   define printf(_format, _args...) CPLM_myprintf(_format, ##_args) /* not indexed */
#endif /*CHANGEPRINT*/


#define CPLM_stdErr(_ierr) CPLM_stdFErr(__FUNCTION__, __FILE__, __LINE__, (_ierr))
void CPLM_stdFErr(const char *fun, const char *file, const int line, const int ierr);

#define CPLM_Abort(_format, _args...) CPLM_FAbort((__FUNCTION__),(_format),##_args)
void CPLM_FAbort(const char *fun, const char *format, ...);

#define CPLM_eprintf(_format, _args...) { CPLM_esprintf(CPALAMEMSIGWRN, __FUNCTION__, _format, ##_args);}
void CPLM_esprintf( const char *signal,
                        const char *fun,
                        const char *format,
                        ...);
void CPLM_efprintf( const char *signal,
                        const char *fun,
                        const char *msg,
                        va_list va);

#endif /*CPALAMEM_HANDLER_H*/
