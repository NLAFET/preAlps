/*
* This file contains functions used for tracking memory leaks
*
* Authors : Sebastien Cayrols
* Email   : sebastien.cayrols@[(gmail.com) | (inria.fr)]
*/
/**
 * \file cpalamem_instrumentation.c
 * \brief Some functions used to develop and debug some codes
 * \author Sebastien Cayrols
 * \version 0.1
 * \date 21 june 2013
 *
 *
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef MPIACTIVATE
  #include <mpi.h>
#else
  #include <time.h>
#endif

#include <cpalamem_memcheck.h>
#include <cpalamem_macro.h>
#include <cpalamem_stacktrace.h>
#include <cpalamem_handler.h>
#include <cpalamem_utils.h>

/**************************************************************
*
*   GLOBAL VARIABLES
*
***************************************************************/
CPLM_MemBlock_t *memAllocated    = NULL;
size_t total_size  = 0; //Count amount of memory currently used

/**************************************************************************
*
*                               SECTION : Print (Part 1)
*
***************************************************************************/

#define printPartialMemBlockInfo(_p) \
                                printf("------> %20s of %4zu bytes @ %p from %s\n",\
                                  (_p)->varName,\
                                  (_p)->size,\
                                  (void*)(_p)->p,\
                                  (_p)->stackCurState)

#ifdef PRINTMEMSTATE
  #ifdef STACKTRACE
      #define printMemBlock(_p)                                 \
                      CPLM_myprintf( "\t\t%s of %zu bytes\n"         \
                                "\t\t\tin file %s at line %d\n" \
                                "\t\t\taddress: %p\n"           \
                                "\t\t\tStackTrace: %s\n",       \
                                (_p)->varName,                  \
                                (_p)->size,                     \
                                (_p)->file,                     \
                                (_p)->line,                     \
                                (void*)(_p)->p,                 \
                                (_p)->stackCurState             \
                              );
  #else
      #define printMemBlock(_p)                                     \
                      CPLM_myprintf( "\t\t%zu bytes\n"               \
                                "\t\t\tin file %s at line %d\n" \
                                "\t\t\taddress: %p\n",          \
                                (_p)->size,                     \
                                (_p)->file,                     \
                                (_p)->line,                     \
                                (void*)(_p)->p                  \
                              );
  #endif
#endif


/**************************************************************
*
*           MEMORY ALLOCATION MANAGEMENT
*
***************************************************************/
void* CPLM_malloc(size_t n, char const *file, int line, const char *varName)
{

#ifdef MEMCHECKCONSUMPTION
  CPLM_MemBlock_t *p = NULL;

  if(( p = malloc(sizeof(CPLM_MemBlock_t)) ) != NULL)
  {
    if(( p->p = malloc(n) ) != NULL)
    {
      p->varName  = varName;
      p->file     = file;
      p->line     = line;
      p->size     = n;
      p->next     = memAllocated;
  #ifdef MPIACTIVATE
      p->time       = MPI_Wtime();
      p->time_free  = 0.0;
  #else
      time(&(p->time));// May not work
  #endif
      total_size         += n;
      p->total_size       = total_size;
      p->total_size_free  = 0;

      //Copy of the stack state in Node
  #ifdef STACKTRACE
      size_t len = strlen(curStack->allFun);
      p->stackCurState = (char*)malloc((len + 1) * sizeof(char));
      CPLM_ASSERT(p->stackCurState != NULL);
      memcpy(p->stackCurState, curStack->allFun, len);
      p->stackCurState[len] = '\0';
  #endif
      memAllocated = p;
    }
    else
    {
      free(p);
      fprintf(stderr, "Error during malloc of a size %zu line %d in %s\n",
          n,
          line,
          file);
      exit(1);
    }
  }
/*  printMemBlock(p);*/
  return (p) ? p->p : NULL;
#else
  char *p = NULL;

  if(( p = (char*)malloc(n) ) == NULL)
  {
    fprintf(stderr, "Error during malloc of a size %zu line %d in %s\n",
        n,
        line,
        file);
    exit(1);
  }
  return p;
#endif
}





void* CPLM_calloc(size_t      n,
                      size_t      size,
                      char const  *file,
                      int         line,
                      const char  *varName)
{

#ifdef MEMCHECKCONSUMPTION
  CPLM_MemBlock_t *p=NULL;

  if(( p = malloc(sizeof(CPLM_MemBlock_t)) ) != NULL)
  {
    if(( p->p = calloc(n,size) ) != NULL)
    {
      p->varName  = varName;
      p->file     = file;
      p->line     = line;
      p->size     = n * size;
  #ifdef MPIACTIVATE
      p->time       = MPI_Wtime();
      p->time_free  = 0.0;
  #else
      time(&(p->time));// May not work
  #endif
      total_size         += n * size;
      p->total_size       = total_size;
      p->total_size_free  = 0;

  #ifdef STACKTRACE
      size_t len = strlen(curStack->allFun);
      p->stackCurState = (char*)malloc((len + 1) * sizeof(char));
      CPLM_ASSERT(p->stackCurState != NULL);
      memcpy(p->stackCurState, curStack->allFun, len);
      p->stackCurState[len]='\0';
  #endif

      p->next=memAllocated;
      memAllocated=p;
    }
    else
    {
      free(p);
      fprintf(stderr,"Error during calloc of a size %zu line %d in %s\n",
          n,
          line,
          file);
      exit(1);
    }
  }
/*  printMemBlock(p);*/
  return (p) ? p->p : NULL;
#else
  char *p = NULL;
  if(( p = (char*)calloc(n,size) ) == NULL)
  {
    fprintf(stderr,"Error during calloc of a size %zu line %d in %s\n",
        n,
        line,
        file);
    exit(1);
  }
  return p;
#endif
}





void* CPLM_realloc( void        *p,
                        size_t      n,
                        char const  *file,
                        int         line,
                        const char  *varName)
{
#ifdef MEMCHECKCONSUMPTION
  CPLM_MemBlock_t *q = NULL;
  const char *varNameP = NULL;//Keep tracking on the varName from p

  for(q = memAllocated; q != NULL; q = q->next)
  {
    if(q->p == p)
    {
/*      printMemBlock(q);*/
      total_size          -= q->size;
      q->total_size_free  = total_size;

  #ifdef MPIACTIVATE
      q->time_free = MPI_Wtime();
  #else
      time(&(q->time));// May not work
  #endif
      q->p            = NULL;
      varNameP        = q->varName;
      break;
    }
  }

  if(( q = malloc(sizeof(CPLM_MemBlock_t)) ) != NULL)
  {
    if(( q->p = realloc(p,n)) != NULL)
    {
      q->varName  = varName;
      q->file     = file;
      q->line     = line;
      q->size     = n;
  #ifdef MPIACTIVATE
      q->time       = MPI_Wtime();
      q->time_free  = 0.0;
  #else
      time(&(q->time));// May not work
  #endif
      total_size         += n;
      q->total_size       = total_size;
      q->total_size_free  = 0;

  #ifdef STACKTRACE
      size_t len = strlen(curStack->allFun);
      q->stackCurState = (char*)malloc((len + 1) * sizeof(char));
      CPLM_ASSERT(q->stackCurState != NULL);
      memcpy(q->stackCurState, curStack->allFun, len);
      q->stackCurState[len] = '\0';
  #endif

      q->next = memAllocated;
      memAllocated = q;
    }
    else
    {
      free(q);
      fprintf(stderr, "Error during realloc of a size %zu line %d in %s\n",
          n,
          line,
          file);
      exit(1);
    }
  }
/*  printMemBlock(q);*/

  return (q) ? q->p : NULL;
#else
  char *pp = NULL;
  if(( pp = (char*)realloc(p,n) ) == NULL)
  {
    fprintf(stderr, "Error during realloc of a size %zu line %d in %s\n",
        n,
        line,
        file);
    exit(1);
  }
  return pp;
#endif

}





void CPLM_free(void *p, char const *file, int line, const char *varName)
{
#ifdef MEMCHECKCONSUMPTION
  CPLM_MemBlock_t *q = NULL;

  for( q = memAllocated; q != NULL; q = q->next)
  {
    if(q->p)
    {
      if(q->p == p)
      {
        free(q->p);
//#ifdef STACKTRACE
//      free(q->stackCurState);
//#endif

  #ifdef MPIACTIVATE
        q->time_free = MPI_Wtime();
  #else
        time_free(&(q->time));// May not work
  #endif
        total_size         -= q->size;
        q->total_size_free  = total_size;
        // printPartialMemBlockInfo(q);
        q->p = NULL;
        break;
      }
    }
  }

  if(q == NULL)
  {
    if(varName == NULL)
    {
      fprintf(stderr,
          "=======> ERROR in free\tline %d in %s : block %p<=======\n",
          line,
          file,
          p);
    }
    else
    {
      fprintf(stderr,
          "=======> ERROR in free of %s\tline %d in %s : block %p<=======\n",
          varName,
          line,
          file,
          p);
    }
  }
#else
  free(p);
#endif
}





//This function checks if all memories allocated have been freed
void CPLM_checkMemDesallocation()
{

#ifdef MEMCHECKCONSUMPTION
  //Just to reset the printing indent
  CPLM_initStack();

  #ifdef PRINTMEMSTATE
  printf(
       "=============================\n"
       "Checking Memory desallocation\n"
       "=============================\n"
        );
  #endif

  //Current element pointer
  CPLM_MemBlock_t *q     = NULL;
  //Output file descriptor
  FILE *ofd         = NULL;
  //Temporary pointer to the next element
  void *tmp         = NULL;
  //Counter to know how many blocks are not desallocated
  int cpt           = 0.0;

  //Maximum size of 25. This is arbitrary and implies if MPI_size is greater 
  // than $(( 25 - `wc -c "mem_usage_.data"` )) then there will be a problem
  char filename[25];
  //MPI rank if defined, otherwise there is at least 1 process
  int rank  = 0;


  #ifdef MPIACTIVATE
    MPI_Comm_rank(MPI_COMM_WORLD,&rank);
  #endif
  snprintf(filename,sizeof(filename),"mem_usage_%d.data",rank);

  //Open in write mod
  if((ofd = fopen(filename,"w"))==NULL)
  {
    fprintf(stderr,"Error during fopen of %s\n",filename);
    exit(2);
  }

  for(q = memAllocated; q != NULL; )
  {
    if(q->p != NULL)
    {
      printMemBlock(q);
      free(q->p);
      cpt++;
    }

  #ifdef STACKTRACE
    fprintf(ofd,"%f %ld %f %ld %s:%d alloc:%zu %s\n",
      q->time,
      q->total_size,
      q->time_free,
      q->total_size_free,
      q->file,
      q->line,
      q->size,
      q->stackCurState);
  #else
    fprintf(ofd,"%f %zu %f %zu %s:%d alloc:%zu\n",
      q->time,
      q->total_size,
      q->time_free,
      q->total_size_free,
      q->file,
      q->line,
      q->size);
  #endif

  #ifdef STACKTRACE
    free(q->stackCurState);
  #endif
    tmp = q;
    q   = q->next;

    free(tmp);
  }

  fclose(ofd);

  printf( "RESUME :"
          "\n\t\t\tnblock not freed      : %d\n"
            "\t\t\tAmount of memory leak : %zu bytes\n",
          cpt,
          total_size);
#endif

}





void CPLM_getCurrentMemState()
{

  CPLM_MemBlock_t *q = NULL;

  printf( "\n\n\tMEMCHECKPOINT\n"
          "\tTotal current memory usage: %zu bytes\n"
          "Details:\n",
          total_size);
  for(q = memAllocated; q != NULL; )
  {
    if(q->p != NULL)
    {
      printPartialMemBlockInfo(q);
    }

    q   = q->next;
  }
  fprintf(stderr,"\n");

}
