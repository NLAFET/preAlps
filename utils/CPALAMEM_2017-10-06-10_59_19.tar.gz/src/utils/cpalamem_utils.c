/*
* This file contains functions used as tools
*
* Authors : Sebastien Cayrols
* Email   : sebastien.cayrols@[(gmail.com) | (inria.fr)]
*/
/**
 * \file cpalamem_utils.c
 * \brief Some functions used to develop and debug some codes
 * \author Sebastien Cayrols
 * \version 0.1
 * \date 21 june 2013
 *
 *
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <libgen.h>
#ifdef MPIACTIVATE
  #include <mpi.h>
#else
  #include <time.h>
#endif
#include <cpalamem_handler.h>
#include <cpalamem_utils.h>
#include <cpalamem_macro.h>

#ifdef MPIACTIVATE
double top(double t1, const char info[], int rank)
{
  double t2 = 0.0;
  t2 = MPI_Wtime();
  CPLM_myprintf("%s %.14f",info,t2-t1);
  return t2;
}
#else
time_t top(time_t t1, const char info[], int rank)
{
  time_t t2;
  time(&t2);
  CPLM_myprintf("%s %.14f",info,difftime(t2,t1));
  return t2;
}
#endif





void CPLM_myfprintf(FILE* fd, const char * format, ...)
{
  int rank = 0;
  char msg[1024];
  va_list v;
  va_start(v, format);
#ifdef MPIACTIVATE
  MPI_Comm_rank(MPI_COMM_WORLD,&rank);
#endif
  snprintf(msg, sizeof(msg), "[Proc: %u] " "%s\n",
      rank,
      format);
  vfprintf(fd, msg, v);
  va_end(v);
}




void CPLM_extendName(char *fullFileName,
                char *pre_extension,
                char *post_extension,
                char **newName)
{

  char *base = NULL;
  int length = 1;

  CPLM_ASSERT(newName  != NULL);
  CPLM_ASSERT(*newName != NULL);

  //Add size of pre_extension
  if(pre_extension)
    length  +=  strlen(pre_extension);

  //Add size of post_extension
  if(post_extension)
    length  +=  strlen(post_extension);

  //Get basename and add size of it
  base  = basename(fullFileName);
  length  +=  strlen(base);

  //Allocation of the new name
  *newName  = (char*)calloc(length, sizeof(char));
  CPLM_ASSERT(*newName != NULL);

  //Concat
  if(pre_extension)
  {
    memcpy(*newName, pre_extension, strlen(pre_extension));
    strcat(*newName, base);
  }
  else
    memcpy(*newName, base, strlen(base));

  if(post_extension)
    strcat(*newName, post_extension);

}
