/*
* This file contains functions used to manage the library : initialization, finalization
*
* Authors : Sebastien Cayrols
* Email   : sebastien.cayrols@[(gmail.com) | (inria.fr)]
*/
/**
 * \file cpalamem_instrumentation.c
 * \brief Some functions used to develop and debug some codes
 * \author Sebastien Cayrols
 * \version 0.1
 * \date 21 june 2013
 *
 *
 */
#include <stdio.h>
#include <stdlib.h>
#ifdef MPIACTIVATE
  #include <mpi.h>
#else
  #include <time.h>
#endif
#ifdef PETSCACTIVATE
  #include <petscsys.h>
#endif
#include <cpalamem_instrumentation.h>
#include "cpalamem_macro.h"

/**************************************************************
*
*   GLOBAL VARIABLES
*
***************************************************************/
char CPLM_banner[CPLM_BANNERSIZE];

/**************************************************************
*
*                     CPALAMEM ENVIRONMENT MANAGEMENT
*
***************************************************************/
void CPLM_SetEnv()
{
#if defined(TIMERACTIVATE) && defined(MPIACTIVATE)
  CPLM_initTimer();
#endif
  CPLM_initStack();
}





void CPLM_GetEnv()
{
  CPLM_getCurrentMemState();
#if defined(TIMERACTIVATE) && defined(MPIACTIVATE)
  CPLM_printTimer(NULL);
#endif
}





void CPLM_ResetTimer()
{
  CPLM_resetTimer();
}




void CPLM_PrintTimer(const char* filename)
{
#if defined(TIMERACTIVATE) && defined(MPIACTIVATE)
  CPLM_printTimer(filename);
#endif
}





void CPLM_Init(int *argc, char ***argv)
{
  int size = 1;
  int rank = 0;
#ifdef PETSCACTIVATE
  PetscInitialize(argc,argv,0,0);
  MPI_Comm_size(MPI_COMM_WORLD, &size);
  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
#elif defined(MPIACTIVATE)
  MPI_Init(argc, argv);
  MPI_Comm_size(MPI_COMM_WORLD, &size);
  MPI_Comm_rank(MPI_COMM_WORLD, &rank);
#endif
  if (!rank)
  {
    int nval = 0;
    char data[CPLM_BUFSIZE];

    for (int i = 0; i < *argc; ++i)
    {
      nval += snprintf(data + nval, sizeof(data) - nval,"%s ",(*argv)[i]);
      if(nval > CPLM_BUFSIZE)
      {
        CPLM_Abort("Error on getting the parameter %d\n"
            "\t%s overflows the buffer\n",
            i,
            (*argv[i]));
      }
    }
    nval = snprintf(CPLM_banner,
        sizeof(CPLM_banner),
        "%s Initialize:\t-np %d\nParams: \t%s\n",
        CPLM_LIBNAME,
        size,
        data);
    printf("%s", CPLM_banner);
  }
  CPLM_SetEnv();
}




void CPLM_PrintBanner(FILE* fd) {
  fprintf(fd, "%s\n", CPLM_banner);
}





void CPLM_Finalize()
{
  CPLM_checkMemDesallocation();
#if defined(TIMERACTIVATE) && defined(MPIACTIVATE)
  CPLM_printTimer(NULL);
#endif
#ifdef PETSCACTIVATE
  PetscFinalize();
#elif defined(MPIACTIVATE)
  MPI_Finalize();
#endif
}
