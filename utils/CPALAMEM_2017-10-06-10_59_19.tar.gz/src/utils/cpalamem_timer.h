/*
* This file contains functions used for timing functions and bock of code
*
* Authors : Sebastien Cayrols
* Email   : sebastien.cayrols@[(gmail.com) | (inria.fr)]
*/
#ifndef CPALAMEM_TIMER_H
#define CPALAMEM_TIMER_H

#ifndef MPIACTIVATE
  #include <time.h>
#endif

/*
 *  Maximum number of steps allowed in a function including the function itself
 */
#define CPLM_NSTEP 30

/*
 * Number of times stored corresponding to sum, min, max for a step
 */
#define CPLM_NTIME 3 
#define CPLM_TIMERSIZE CPLM_NTIME * ( CPLM_NSTEP + 1 )
#define CPLM_NSPACETIMING 30

enum {
  step1 = 1,
  step2,
  step3,
  step4,
  step5,
  step6,
  step7,
  step8,
  step9,
  step10,
  step11,
  step12,
  step13,
  step14,
  step15,
  step16,
  step17,
  step18,
  step19,
  step20,
  step21,
  step22,
  step23,
  step24,
  step25,
  step26,
  step27,
  step28,
  step29,
  step30
};




#define CPALAMEM_OPEN_TIMER static CPLM_Timer_t localTimer = { \
                                                          .funName = __FUNCTION__,\
                                                          .ncall  = {0},\
                                                          .localTime = {0.0},\
                                                          .stepName = {NULL}};\
                            double CPALAMEM_start[CPLM_NSTEP + 1]  = {0.0};\
                            double CPALAMEM_swap              = 0.0;\
                            if(!localTimer.ncall[0]) \
                              {CPLM_addTimer(&localTimer);}\
                            CPALAMEM_start[0] = MPI_Wtime();

#define CPALAMEM_TIC(_stepId, _stepName) \
                                          CPALAMEM_start[(_stepId)]       = MPI_Wtime();\
                                          localTimer.stepName[(_stepId) * CPLM_NTIME]  = (_stepName);

#define CPALAMEM_TAC(_stepId)   CPALAMEM_swap = MPI_Wtime();\
                                CPALAMEM_start[(_stepId)] = CPALAMEM_swap - CPALAMEM_start[(_stepId)];\
                                localTimer.localTime[(_stepId) * CPLM_NTIME] += CPALAMEM_start[(_stepId)];\
                                if(localTimer.ncall[(_stepId) * CPLM_NTIME]){\
                                  localTimer.localTime[(_stepId) * CPLM_NTIME + 1] = CPLM_MIN(localTimer.localTime[(_stepId) * CPLM_NTIME + 1], CPALAMEM_start[(_stepId)]);\
                                  localTimer.localTime[(_stepId) * CPLM_NTIME + 2] = CPLM_MAX(localTimer.localTime[(_stepId) * CPLM_NTIME + 2], CPALAMEM_start[(_stepId)]);\
                                }else{\
                                  localTimer.localTime[(_stepId) * CPLM_NTIME + 1] = CPALAMEM_start[(_stepId)];\
                                  localTimer.localTime[(_stepId) * CPLM_NTIME + 2] = CPALAMEM_start[(_stepId)];\
                                }\
                                localTimer.ncall[(_stepId) * CPLM_NTIME] ++;\
                                CPALAMEM_start[(_stepId)] = CPALAMEM_swap;

#define CPALAMEM_CLOSE_TIMER  CPALAMEM_start[0] = MPI_Wtime() - CPALAMEM_start[0];\
                              localTimer.localTime[0] += CPALAMEM_start[0];\
                              if(localTimer.ncall[0]){\
                                localTimer.localTime[1] = CPLM_MIN(localTimer.localTime[1], CPALAMEM_start[0]);\
                                localTimer.localTime[2] = CPLM_MAX(localTimer.localTime[2], CPALAMEM_start[0]);\
                              }else{\
                                localTimer.localTime[1] = CPALAMEM_start[0];\
                                localTimer.localTime[2] = CPALAMEM_start[0];\
                              }\
                              localTimer.ncall[0]++;

/*Replace basic commands by timers*/
#ifdef ALL_TIMER

    #define CPLM_OPEN_TIMER
    #define CPLM_CLOSE_TIMER

    #define CPLM_BEGIN_TIME                CPALAMEM_OPEN_TIMER
    #define CPLM_TIC(_stepId, _stepName)   CPALAMEM_TIC((_stepId), (_stepName))
    #define CPLM_TAC(_stepId)              CPALAMEM_TAC((_stepId))
    #define CPLM_END_TIME                  CPALAMEM_CLOSE_TIMER

#else

  #define CPLM_BEGIN_TIME
  #define CPLM_END_TIME

  #ifdef TIMERACTIVATE
    #define CPLM_OPEN_TIMER                CPALAMEM_OPEN_TIMER
    #define CPLM_TIC(_stepId, _stepName)   CPALAMEM_TIC((_stepId), (_stepName))
    #define CPLM_TAC(_stepId)              CPALAMEM_TAC((_stepId))
    #define CPLM_CLOSE_TIMER               CPALAMEM_CLOSE_TIMER
  #else
    #define CPLM_OPEN_TIMER
    #define CPLM_TIC(_stepId, _stepName)
    #define CPLM_TAC(_stepId)
    #define CPLM_CLOSE_TIMER
  #endif
#endif




typedef struct timer{
  const char    *funName;
  int           ncall[CPLM_TIMERSIZE];
  double        localTime[CPLM_TIMERSIZE];
  char          *stepName[CPLM_TIMERSIZE];
} CPLM_Timer_t;





typedef struct timers{
  CPLM_Timer_t **timer;
  int ntimer;
  int ntimerMax;
} CPLM_TimerList_t;



void CPLM_initTimer();
void CPLM_resetTimer();
void CPLM_addTimer(CPLM_Timer_t *t);
void CPLM_printTimer(const char* filename);
void CPLM_printTime(CPLM_Timer_t *t, FILE* fd);
#endif /*CPALAMEM_TIMER_H*/
