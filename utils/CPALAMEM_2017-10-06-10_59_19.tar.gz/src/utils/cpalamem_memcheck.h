/*
* This file contains functions used for tracking memory leaks
*
* Authors : Sebastien Cayrols
* Email   : sebastien.cayrols@[(gmail.com) | (inria.fr)]
*/
#ifndef CPALAMEM_MEMCHECK_H
#define CPALAMEM_MEMCHECK_H

#ifndef MPIACTIVATE
  #include <time.h>
#endif

#ifdef MEMCHECK
#   define free(_p) CPLM_free((_p), (__FILE__), (__LINE__), NULL) /* not indexed */
#   define malloc(_n)         CPLM_malloc((_n), (__FILE__), (__LINE__), NULL) /* not indexed */
#   define realloc(_p, _n)    CPLM_realloc((_p), (_n), (__FILE__), (__LINE__), NULL) /* not indexed */
#   define calloc(_n, _size)  CPLM_calloc((_n), (_size), (__FILE__), (__LINE__), NULL) /* not indexed */
#endif


typedef struct memBlock{
  char *p;                //Pointer to the memory allocated
  const char *varName;    //Name of the variable or NULL
  const char *file;       //File name from where the function call the allocation
  int line;               //Line in the file where the memory function has been called
  size_t size;            //Size in bytes of the current allocation
  struct memBlock *next;
#ifdef MPIACTIVATE
  double time;            //Current time when the memory allocation is called
  double time_free;       //Current time when the memory free is called
#else
  time_t time;            //Current time when the memory allocation is called
  time_t time_free;       //Current time when the memory free is called
#endif
  size_t total_size;      //Total memory size in bytes allocated
  size_t total_size_free; //Total memory size in bytes allocated
  char *stackCurState;    //The current stack trace state
} CPLM_MemBlock_t;


extern void* CPLM_malloc(size_t n, char const *file, int line, const char *varName);

extern void* CPLM_realloc(void *p, size_t n, char const *file, int line, const char *varName);

extern void* CPLM_calloc (size_t n, size_t size, char const *file, int line, const char *varName);

extern void  CPLM_free(void *p, char const *file, int line, const char *varName);

extern void CPLM_checkMemDesallocation(void);

extern void CPLM_getCurrentMemState(void);
#endif /*CPALAMEM_MEMCHECK_H*/
