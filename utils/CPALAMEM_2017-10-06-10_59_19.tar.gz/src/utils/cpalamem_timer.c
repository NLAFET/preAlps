/*
* This file contains functions used for timing functions and bock of code
*
* Authors : Sebastien Cayrols
* Email   : sebastien.cayrols@[(gmail.com) | (inria.fr)]
*/
/**
 * \file cpalamem_instrumentation.c
 * \brief Some functions used to develop and debug some codes
 * \author Sebastien Cayrols
 * \version 0.1
 * \date 21 june 2013
 *
 *
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#ifdef MPIACTIVATE
  #include <mpi.h>
#else
  #include <time.h>
#endif

#include <cpalamem_timer.h>
#include <cpalamem_utils.h>
#include <cpalamem_handler.h>
#include <cpalamem_instrumentation.h>
#include <cpalamem_macro.h>

/**************************************************************
*
*   GLOBAL VARIABLES
*
***************************************************************/
CPLM_TimerList_t timers = { .timer=NULL, .ntimer=0, .ntimerMax=0 };

/**************************************************************************
*
*                               SECTION : Print (Part 1)
*
***************************************************************************/


/**************************************************************
*
*           TIMER STRUCTURE MANAGEMENT
*
***************************************************************/
//This function sets the number of timers to 10 and allocate the memory space for it
void CPLM_initTimer()
{
  timers.ntimerMax = 10; //Allocate first 10 timer space
  timers.timer = (CPLM_Timer_t**) malloc(
      timers.ntimerMax * sizeof(CPLM_Timer_t*));
}





void CPLM_resetTimer()
{
  //Assume that the main function is timed with OPEN_TIMER and CLOSE TIMER
  for(int i = 1; i < timers.ntimer; i++)
  {
    memset(timers.timer[i]->ncall,      0, CPLM_TIMERSIZE * sizeof(int));
    memset(timers.timer[i]->localTime,  0, CPLM_TIMERSIZE * sizeof(double));
  }
  timers.ntimer = 1;

}





/*
 * This function add a timer to the list of timer "timers".
 * Moreover, if the limit "ntimerMax" is reached,
 * a realloc is performed to add the new one by doubling the limit
 */
void CPLM_addTimer(CPLM_Timer_t *t)
{
  if(timers.ntimer == timers.ntimerMax)
  {
    timers.ntimerMax *=  2;
    timers.timer      = (CPLM_Timer_t**) realloc(
        timers.timer,
        timers.ntimerMax * sizeof(CPLM_Timer_t*));
  }
  timers.timer[timers.ntimer] = t;
  timers.ntimer++;
}





void CPLM_printTime(CPLM_Timer_t *t, FILE* fd)
{
  int nval      = 0;
  int lnval     = 0;
  const int dataSize  = CPLM_TIMERSIZE * (CPLM_NSPACETIMING + 10 + 30) * 2; // 30 space for message + 10 for typo + 30 for float AND this value is twice
  char data[dataSize];
  char buf[1024];
  int nStep     = 0;

  data[0] = '\0';

    for(int i = 3; (i < CPLM_TIMERSIZE && nval < dataSize); i+=3)
    {
      if(t->stepName[i])
      {
        if(t->ncall[i] > 1)
        {
          lnval = snprintf(buf, sizeof(buf), "\t\t\t%-*s: %f s\t[ %f , %f ]\t(ncall %d)\n",
              CPLM_NSPACETIMING,
              t->stepName[i],
              t->localTime[i],
              t->localTime[i+1],
              t->localTime[i+2],
              t->ncall[i]);
        }
        else
        {
          lnval = snprintf(buf, sizeof(buf), "\t\t\t%-*s: %f s\n",
              CPLM_NSPACETIMING,
              t->stepName[i],
              t->localTime[i]);
        }
        if(lnval + nval > dataSize)
        {
          CPLM_Abort("the quantity of memory is too small "
              "to contain all timing");
        }
        nval += snprintf(data + nval, sizeof(data) - nval, "%s", buf); // Could be buffer overflow
      }
    }

  if(t->ncall[0] > 1)
  {
    CPLM_myfprintf(fd, "\t%s: %f s\t[%f,%f]\t(ncall %d)\n"
        "%s",
        t->funName,
        t->localTime[0],
        t->localTime[1],
        t->localTime[2],
        t->ncall[0],
        data);
  }
  else
  {
    CPLM_myfprintf(fd, "\t%s: %f s\t(ncall %d)\n"
        "%s",
        t->funName,
        t->localTime[0],
        t->ncall[0],
        data);
  }
}





void CPLM_printTimer(const char* filename)
{
  FILE* fd = NULL;

  if(filename != NULL)
  {
    fd = fopen(filename, "a");
    CPLM_PrintBanner(fd);
  }
  else
  {
    fd = stdout;
  }
  fprintf(fd,
    "=============================\n"
    "            TIMER            \n"
    "=============================\n"
    );

  if(timers.ntimer)
  {
    for(int i = 0; i < timers.ntimer; i++)
    {
      CPLM_printTime(timers.timer[i], fd);
    }
  }
  else
  {
    fprintf(fd, "TIMER : no timer set\n");
  }

  if(filename != NULL)
  {
    fclose(fd);
  }
}
