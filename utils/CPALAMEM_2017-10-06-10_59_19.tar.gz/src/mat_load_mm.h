/*
* This file contains functions used to load a matrix market file
*
* Authors : Sebastien Cayrols
*         : Remi Lacroix
* Email   : sebastien.cayrols@[(gmail.com) | (inria.fr)]
*/
#ifndef MAT_LOAD_MM_H
#define MAT_LOAD_MM_H

#ifdef MPIACTIVATE
  #include "mpi.h"
#endif
#include "mat_csr.h"

#define MM_MAX_LINE_LENGTH  1025
#define MM_MAX_TOKEN_LENGTH 64
#define COMMENT_SYMBOL '%'

#define ROW_LAYOUT 'R'
#define COL_LAYOUT 'C'

#define MM_MATRIXMARKET_STR "%%MatrixMarket"
#define MM_MATRIX_STR       "matrix"
#define MM_DENSE_STR        "array"
#define MM_SPARSE_STR       "coordinate"
#define MM_COMPLEX_STR      "complex"
#define MM_REAL_STR         "real"
#define MM_INT_STR          "integer"
#define MM_GENERAL_STR      "general"
#define MM_SYMM_STR         "symmetric"
#define MM_HERM_STR         "hermitian"
#define MM_SKEW_STR         "skew-symmetric"
#define MM_PATTERN_STR      "pattern"

#ifdef MPIACTIVATE
int CPLM_LoadMatrixMM(MPI_Comm comm,
                 const char* filename,
                 CPLM_Mat_CSR_t* mat);

int CPLM_LoadBlockMatrixMM(MPI_Comm comm,
                      const char* filename,
                      int blockSize,
                      CPLM_Mat_CSR_t* mat);

int CPLM_LoadBlockMatrixMMEx(MPI_Comm comm,
                        const char* filename,
                        int blockSize,
                        CPLM_Mat_CSR_format_t format,
                        CPLM_Mat_CSR_t* mat);

int CPLM_LoadMatrixMM1D(const char *filename,
                   CPLM_Mat_CSR_t  *A,
                   const char distribLayout, //either 'R' for row_layout or 'C' for col_layout
                   MPI_Comm   comm);

int CPLM_LoadMatrixMM2D(const char *filename,
                   CPLM_Mat_CSR_t  *A,
                   int        pr,
                   int        pc,
                   MPI_Comm   comm,
                   MPI_Comm   *rComm,
                   MPI_Comm   *cComm);

#endif
                        
//Function added october, 28th 2013 by Sebastien Cayrols
int CPLM_LoadMatrixMarket( const char* filename, CPLM_Mat_CSR_t* mat);

#endif /* MAT_LOAD_MM_H */
