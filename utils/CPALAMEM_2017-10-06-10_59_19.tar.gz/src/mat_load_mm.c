/*
* This file contains functions used to load a matrix market file
*
* Authors : Sebastien Cayrols
*         : Remi Lacroix
* Email   : sebastien.cayrols@[(gmail.com) | (inria.fr)]
*/
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <strings.h>

#include "cpalamem_macro.h"
#include "ijval.h"
#include "mat_load_mm.h"
#include "MPIutils.h"
#include "cpalamem_instrumentation.h"

#define ROW_PANEL 1
#define COL_PANEL 2

/*
 * Load a matrix from a file using MatrixMarket format.
 * 
 * TODO: full support of the MatrixMarket format?
 */
#ifdef MPIACTIVATE
int CPLM_LoadMatrixMM(MPI_Comm comm,
                 const char* filename,
                 CPLM_Mat_CSR_t* mat)
{
  return CPLM_LoadBlockMatrixMM(comm, filename, 1, mat);
}
#endif

/*
 * Load a matrix from a file using MatrixMarket format
 * using the specified block size.
 * 
 * TODO: full support of the MatrixMarket format?
 */
#ifdef MPIACTIVATE
int CPLM_LoadBlockMatrixMM(MPI_Comm comm,
                      const char* filename,
                      int blockSize,
                      CPLM_Mat_CSR_t* mat)
{
  return CPLM_LoadBlockMatrixMMEx(comm, filename, blockSize, (blockSize > 1) ? FORMAT_BCSR : FORMAT_CSR, mat);
}
#endif

/*
 * Load a matrix from a file using MatrixMarket format
 * using the specified block size.
 * 
 * TODO: full support of the MatrixMarket format?
 */
#ifdef MPIACTIVATE
int CPLM_LoadBlockMatrixMMEx(MPI_Comm comm,
                        const char* filename,
                        int blockSize,
                        CPLM_Mat_CSR_format_t format,
                        CPLM_Mat_CSR_t* mat)
{
  int size                = 0;
  int rank                = 0;
  int i                   = 0;
  int n                   = 0;
  int proc                = 0;
  int nbBlocksRow         = 0;
  int nbBlocksCol         = 0;
  int localSizeBase       = 0;
  int localSize           = 0;
  int errorCode           = 0;
  int distribution        = COL_PANEL;
  int nbProcWithExtraSize = 0;
  int localStart          = 0;
  int localEnd            = 0;
  int nread               = 0;
  CPLM_IJVal_t *ijvals           = NULL;
  CPLM_IJVal_t *ijvals2          = NULL;
  CPLM_IJVal_t *ijvalStart       = NULL;
  CPLM_IJVal_t *ijvalStartLocal  = NULL;
  int *sendSizes = NULL;
  int *recvSizes = NULL;
  MPI_Request *sendRequests = NULL;
  MPI_Status status;
  MPI_Datatype MPI_CPLM_IJVal_t;
  char *ptr = NULL;

  //Avoid warning of unused nread in compilation
  nread++;
  ptr++;

  CPLM_RegisterIJValStruct(&MPI_CPLM_IJVal_t);

  MPI_Comm_size(comm, &size);
  MPI_Comm_rank(comm, &rank);

  if (rank == 0) { // Master process: read the file and dispatch the matrix
    FILE *fd;
    char buf[MM_MAX_LINE_LENGTH];
    char banner[MM_MAX_TOKEN_LENGTH];
    char matrix[MM_MAX_TOKEN_LENGTH];
    char coord[MM_MAX_TOKEN_LENGTH];
    char dataType[MM_MAX_TOKEN_LENGTH];
    char storageScheme[MM_MAX_TOKEN_LENGTH];
    CPLM_IJVal_t *ijvalsTmp;

    fd = fopen(filename, "r");
    if (!fd) {
      printf("[LoadMatrixMM] Error: Impossible to open the file %s.\n",filename);
      return 0;
    }

    // Get the header line
    ptr = fgets(buf, MM_MAX_LINE_LENGTH, fd);
    sscanf(buf, "%s %s %s %s %s", banner, matrix, coord, dataType, storageScheme);
    if (strcasecmp(banner, MM_MATRIXMARKET_STR)
          || strcasecmp(matrix, MM_MATRIX_STR)
          || strcasecmp(coord, MM_SPARSE_STR)
          || strcasecmp(dataType, MM_REAL_STR)
          || strcasecmp(storageScheme, MM_GENERAL_STR)) {
      printf("[LoadMatrixMM] Error: Only sparse real matrix are currently supported.\n");
      fclose(fd);
      return 0;
    }

    // Skip comment lines
    do {
      ptr = fgets(buf, MM_MAX_LINE_LENGTH, fd);
    } while (!feof(fd) && buf[0] == '%');

    // Get matrix size
    sscanf(buf, "%d%d%d", &mat->info.M, &mat->info.N, &mat->info.nnz);

    if (mat->info.M < 1 || mat->info.N < 1 || mat->info.nnz < 1 || mat->info.nnz > (long long int)mat->info.M * mat->info.N) {
      printf("[LoadMatrixMM] Error: Invalid matrix dimensions.\n");
      fclose(fd);
      return 0;
    }
    if (mat->info.M % blockSize || mat->info.N % blockSize) {
      printf("[LoadMatrixMM] Error: invalid system block size.\n");
      fclose(fd);
      return 0;
    }

    MPI_Bcast(&mat->info.M, 1, MPI_INT, 0, comm);
    MPI_Bcast(&mat->info.N, 1, MPI_INT, 0, comm);
    MPI_Bcast(&mat->info.nnz, 1, MPI_INT, 0, comm);

    nbProcWithExtraSize = mat->info.nnz % size;
    localSize = mat->info.nnz / size + (nbProcWithExtraSize > 0);
    ijvalsTmp = (CPLM_IJVal_t*)malloc(localSize * sizeof(CPLM_IJVal_t));

    for (proc = 0; proc < size; proc++) {
      for (n = 0; n < localSize; n++) {
        nread = fscanf(fd, "%d%d%lf", &ijvalsTmp[n].i, &ijvalsTmp[n].j, &ijvalsTmp[n].val); // TODO error checking

        // Use 0-based indexing
        ijvalsTmp[n].i--;
        ijvalsTmp[n].j--;
      }

      // Send data
      if (proc == rank) { // to local process
        localSizeBase = localSize;
        ijvals = ijvalsTmp;
        ijvalsTmp = (CPLM_IJVal_t*)malloc(localSize * sizeof(CPLM_IJVal_t));
      } else { // to slave process
        errorCode=MPI_Send(&localSize, 1, MPI_INT, proc, 0, comm);
        errorCode=MPI_Send(ijvalsTmp, localSize, MPI_CPLM_IJVal_t, proc, 0, comm); 
      }

      // Prepare for next chunk
      if (proc + 1 == nbProcWithExtraSize) {
        localSize--;
      }
    }

    // Memory clean-up
    free(ijvalsTmp);

    fclose(fd);
  } else { // Slave process: get its chunk from the master
    MPI_Status stat;

    MPI_Bcast(&mat->info.M, 1, MPI_INT, 0, comm);
    MPI_Bcast(&mat->info.N, 1, MPI_INT, 0, comm);
    MPI_Bcast(&mat->info.nnz, 1, MPI_INT, 0, comm);

    errorCode=MPI_Recv(&localSizeBase, 1, MPI_INT, 0, 0, comm, &stat);
    ijvals = (CPLM_IJVal_t*)malloc(localSizeBase * sizeof(CPLM_IJVal_t));
    errorCode=MPI_Recv(ijvals, localSizeBase, MPI_CPLM_IJVal_t, 0, 0, comm, &stat);
  }

  // Sort the local chunk
  if(distribution == ROW_PANEL)
    qsort(ijvals, localSizeBase, sizeof(CPLM_IJVal_t), CPLM_CompareIJVal);
  else
    qsort(ijvals, localSizeBase, sizeof(CPLM_IJVal_t), CPLM_CompareIJValCol);

  if(distribution == ROW_PANEL){
    // Init the local matrix size
    nbBlocksRow = mat->info.M / blockSize;
    localSize = nbBlocksRow / size;
    nbProcWithExtraSize = nbBlocksRow % size;
    mat->info.m = (localSize + (nbProcWithExtraSize > rank)) * blockSize;
    mat->info.n = mat->info.N;
    mat->info.blockSize = blockSize;
    mat->info.format = format;
    mat->info.structure = UNSYMMETRIC;
  }else{
    // Init the local matrix size
    nbBlocksCol = mat->info.N / blockSize;
    localSize = nbBlocksCol / size;
    nbProcWithExtraSize = nbBlocksCol % size;
    mat->info.m = mat->info.M;
    mat->info.n = (localSize + (nbProcWithExtraSize > rank)) * blockSize;
    mat->info.blockSize = blockSize;
    mat->info.format = format;
    mat->info.structure = UNSYMMETRIC;
  }

  if (nbProcWithExtraSize > 0) {
    localSize++;
  }
  localSize *= blockSize;

  // Send the non-local elements
  sendSizes = (int*)calloc(size, sizeof(int));
  recvSizes = (int*)calloc(size, sizeof(int));
  sendRequests = (MPI_Request*)malloc((size - 1) * sizeof(MPI_Request));

  for (n = 0, proc = 0, localEnd = localSize, ijvalStart = ijvals; n < localSizeBase; n++) {
    if(distribution == ROW_PANEL){
      while (ijvals[n].i >= localEnd) {
        if (proc == rank) {
          localStart = localEnd - localSize;
          ijvalStartLocal = ijvalStart;
        } else {
          errorCode=MPI_Isend(&sendSizes[proc], 1, MPI_INT, proc, 0, comm, &sendRequests[proc - (proc > rank)]);
          if (sendSizes[proc] > 0) {
            errorCode=MPI_Request_free(&sendRequests[proc - (proc > rank)]);
            errorCode=MPI_Isend(ijvalStart, sendSizes[proc], MPI_CPLM_IJVal_t, proc, 0, comm, &sendRequests[proc - (proc > rank)]);
          }
        }

        proc++;
        if (proc == nbProcWithExtraSize) {
          localSize -= blockSize;
        }
        localEnd += localSize;
        ijvalStart = &ijvals[n];
      }
    }else{
      while (ijvals[n].j >= localEnd) {
        if (proc == rank) {
          localStart = localEnd - localSize;
          ijvalStartLocal = ijvalStart;
        } else {
          errorCode=MPI_Isend(&sendSizes[proc], 1, MPI_INT, proc, 0, comm, &sendRequests[proc - (proc > rank)]);
          if (sendSizes[proc] > 0) {
            errorCode=MPI_Request_free(&sendRequests[proc - (proc > rank)]);
            errorCode=MPI_Isend(ijvalStart, sendSizes[proc], MPI_CPLM_IJVal_t, proc, 0, comm, &sendRequests[proc - (proc > rank)]);
          }
        }

        proc++;
        if (proc == nbProcWithExtraSize) {
          localSize -= blockSize;
        }
        localEnd += localSize;
        ijvalStart = &ijvals[n];
      }
    }
    sendSizes[proc]++;
  }

  // Last non-local chunks
  while (proc < size) {
    if (proc == rank) {
      localStart = localEnd - localSize;
      ijvalStartLocal = ijvalStart;
    } else {
      errorCode=MPI_Isend(&sendSizes[proc], 1, MPI_INT, proc, 0, comm, &sendRequests[proc - (proc > rank)]);
      if (sendSizes[proc] > 0) {
        MPI_Request_free(&sendRequests[proc - (proc > rank)]);
        errorCode=MPI_Isend(ijvalStart, sendSizes[proc], MPI_CPLM_IJVal_t, proc, 0, comm, &sendRequests[proc - (proc > rank)]);
      }
    }

    proc++;
    if (proc == nbProcWithExtraSize) {
      localSize -= blockSize;
    }
    localEnd += localSize;
    ijvalStart = &ijvals[n];
  }

  // Receive the chunks
  for (proc = 0, localSize = 0; proc < size; proc++) {
    if (proc != rank) {
      errorCode=MPI_Recv(&recvSizes[proc], 1, MPI_INT, proc, 0, comm, &status);
    } else {
      recvSizes[proc] = sendSizes[proc];
    }
    localSize += recvSizes[proc];
  }

  ijvalStart = ijvals2 = (CPLM_IJVal_t*)malloc(localSize * sizeof(CPLM_IJVal_t));

  for (proc = 0; proc < size; proc++) {
    if (recvSizes[proc] > 0) {
      if (proc != rank) {
        errorCode=MPI_Recv(ijvalStart, recvSizes[proc], MPI_CPLM_IJVal_t, proc, 0, comm, &status);
      } else {
        memcpy(ijvalStart, ijvalStartLocal, recvSizes[proc] * sizeof(CPLM_IJVal_t));
      }
      ijvalStart += recvSizes[proc];
    }
  }

  // Memory clean-up
  free(recvSizes);

  // Sort local elements
  qsort(ijvals2, localSize, sizeof(CPLM_IJVal_t), CPLM_CompareIJVal);
  // Convert to CSR
  mat->info.lnnz = localSize;
  mat->rowPtr = (int*)malloc((mat->info.m + 1) * sizeof(int));
  mat->colInd = (int*)malloc(localSize * sizeof(int));
  mat->val = (double*)malloc(localSize * sizeof(double));

  mat->rowPtr[0] = 0;
  for (n = i = 0; n < localSize; n++) {
    //printf("(%d,%d)\t%f\t->\t(%d,%d)\n",ijvals2[n].i,ijvals2[n].j,ijvals2[n].val,ijvals2[n].i,ijvals2[n].j-localStart);
    // Local indexing
    if(distribution == ROW_PANEL)
      ijvals2[n].i -= localStart;
    /*else
      ijvals2[n].i -= localStart;*/

    while (ijvals2[n].i > i) {
      i++;
      mat->rowPtr[i] = n;
    }

    if(distribution == ROW_PANEL)
      mat->colInd[n] = ijvals2[n].j;
    else
      mat->colInd[n] = ijvals2[n].j-localStart;/*This modification coming from Sebastien Cayrols : date 10/14/2015*/
    mat->val[n] = ijvals2[n].val;
  }
  while (mat->info.m > i) {
    i++;
    mat->rowPtr[i] = n;
  }

  // Wait for all chunks to be received
  errorCode=MPI_Waitall(size - 1, sendRequests, MPI_STATUSES_IGNORE);

  // Memory clean-up
  free(sendSizes);
  free(sendRequests);
  free(ijvals);
  free(ijvals2);

  MPI_Type_free(&MPI_CPLM_IJVal_t);
  
  //just for avoid compilation warning
	errorCode++;
	
  return 1;
}
#endif

/*
 * Load a matrix from a file using MatrixMarket format
 * 
 * TODO: full support of the MatrixMarket format?
 */
int CPLM_LoadMatrixMarket( const char* filename, CPLM_Mat_CSR_t* mat)
{
CPLM_PUSH
CPLM_BEGIN_TIME
#ifndef SILENCE
	printf("Load of %s ...\n",filename);
#endif

  int i         = 0;
  int n         = 0;
  int errorCode = 0;
  int nread     = 0;
  FILE *fd  = NULL;
  char buf[MM_MAX_LINE_LENGTH];
  char banner[MM_MAX_TOKEN_LENGTH];
  char matrix[MM_MAX_TOKEN_LENGTH];
  char coord[MM_MAX_TOKEN_LENGTH];
  char dataType[MM_MAX_TOKEN_LENGTH];
  char storageScheme[MM_MAX_TOKEN_LENGTH];
  CPLM_IJVal_t *ijvalsTmp  = NULL;
  char *ptr = NULL;
  //Avoiding warning of unused nread during compilation
  nread++;
  ptr++;

  //open the file
  fd = fopen(filename, "r");
  if (!fd) 
  {
    CPLM_Abort("Impossible to open the file %s",filename);
  }

  // Get the header line
  ptr = fgets(buf, MM_MAX_LINE_LENGTH, fd);
  sscanf(buf, "%s %s %s %s %s", banner, matrix, coord, dataType, storageScheme);
  if (strcasecmp(banner, MM_MATRIXMARKET_STR)
        || strcasecmp(matrix, MM_MATRIX_STR)
        || strcasecmp(coord, MM_SPARSE_STR)
        || strcasecmp(dataType, MM_REAL_STR)
        || (strcasecmp(storageScheme, MM_GENERAL_STR) && strcasecmp(storageScheme, MM_SYMM_STR))) 
        {
    fclose(fd);
    CPLM_Abort("Only sparse real < symmetric | general > matrix are currently supported.\nHere is %s",storageScheme);
  }

  // Skip comment lines
  do {
    ptr = fgets(buf, MM_MAX_LINE_LENGTH, fd);
  } while (!feof(fd) && buf[0] == '%');

  // Get matrix size
  sscanf(buf, "%d%d%d", &mat->info.M, &mat->info.N, &mat->info.nnz);
  if (mat->info.M < 1 || mat->info.N < 1 || mat->info.nnz < 1 || mat->info.nnz > (long long int)mat->info.M * mat->info.N) {
    fprintf(stderr,"[LoadMatrixMarket] Error: Invalid matrix dimensions.\n");
    fclose(fd);
#ifdef MPIACTIVATE
    MPI_Abort(MPI_COMM_WORLD,1);
#else
    exit(1);
#endif
  }
  
  mat->info.m = mat->info.M;
  mat->info.n = mat->info.N;
  mat->info.lnnz = mat->info.nnz;
  mat->info.blockSize = 1;
  mat->info.format = FORMAT_CSR;
  if(!strcasecmp(storageScheme, MM_SYMM_STR))
    mat->info.structure = SYMMETRIC;
  else
    mat->info.structure = UNSYMMETRIC;

  ijvalsTmp = (CPLM_IJVal_t*)malloc(mat->info.nnz * sizeof(CPLM_IJVal_t));

  int base0=0;
  nread = fscanf(fd, "%d%d%lf", &ijvalsTmp[0].i, &ijvalsTmp[0].j, &ijvalsTmp[0].val); // TODO error checking
  if(ijvalsTmp[0].i==0 || ijvalsTmp[0].j==0){
    printf("0-based detected\n");
    base0=1;
  }else{
    ijvalsTmp[0].i--;
    ijvalsTmp[0].j--;
  }
  if(base0){
    for (n = 1; n < mat->info.nnz; n++) 
      nread = fscanf(fd, "%d%d%lf", &ijvalsTmp[n].i, &ijvalsTmp[n].j, &ijvalsTmp[n].val); // TODO error checking
  
  }else{
    for (n = 1; n < mat->info.nnz; n++) {
      nread = fscanf(fd, "%d%d%lf", &ijvalsTmp[n].i, &ijvalsTmp[n].j, &ijvalsTmp[n].val); // TODO error checking

      // Use 0-based indexing
      ijvalsTmp[n].i--;
      ijvalsTmp[n].j--;
    }
  }
  fclose(fd);

  // Sort the local chunk
  qsort(ijvalsTmp, mat->info.nnz, sizeof(CPLM_IJVal_t), CPLM_CompareIJVal);

  // Convert to CSR
  mat->rowPtr = (int*)malloc((mat->info.M + 1) * sizeof(int));
  mat->colInd = (int*)malloc(mat->info.nnz * sizeof(int));
  mat->val = (double*)malloc(mat->info.nnz * sizeof(double));

  mat->rowPtr[0] = 0;
  for (n = i = 0; n < mat->info.nnz; n++) {
    while (ijvalsTmp[n].i > i) {
      i++;
      mat->rowPtr[i] = n;
    }

    mat->colInd[n] = ijvalsTmp[n].j;
    mat->val[n] = ijvalsTmp[n].val;
  }
  while (mat->info.M > i) {
    i++;
    mat->rowPtr[i] = n;
  }

  // Memory clean-up
  free(ijvalsTmp);
  
  if(mat->info.structure==SYMMETRIC)
  {
    CPLM_Mat_CSR_t tmp = CPLM_MatCSRNULL();
    
    //symmetrizeMatrix(mat,&tmp);
    errorCode = CPLM_MatCSRUnsymStruct(mat, &tmp);CPLM_CHKERR(errorCode);
    
    if(!CPLM_MatCSRIsSym(&tmp))
    {
      CPLM_Abort("The matrix is not symmetric as specified in the structure");
    }
    CPLM_MatCSRFree(mat);
    *mat = tmp;
  }
  
  if(CPLM_MatCSRChkDiag(mat))
  {
    CPLM_Abort("Diagonal is not set correctly");
  }
  
CPLM_END_TIME
CPLM_POP
  return 0;
}





int CPLM_LoadMatrixMM1D(const char *filename,
                   CPLM_Mat_CSR_t  *A,
                   char       distribLayout,
                   MPI_Comm   comm)
{
CPLM_PUSH
CPLM_BEGIN_TIME
  int size                = 0;
  int rank                = 0;
  int i                   = 0;
  int n                   = 0;
  int proc                = 0;
  int nbBlocksRow         = 0;
  int nbBlocksCol         = 0;
  int localSizeBase       = 0;
  int localSize           = 0;
  int nbProcWithExtraSize = 0;
  int localStart          = 0;
  int localEnd            = 0;
  int nread               = 0;
  int ierr                = 0;
  CPLM_IJVal_t *ijvals           = NULL;
  CPLM_IJVal_t *ijvals2          = NULL;
  CPLM_IJVal_t *ijvalStart       = NULL;
  CPLM_IJVal_t *ijvalStartLocal  = NULL;
  int *sendSizes = NULL;
  int *recvSizes = NULL;
  MPI_Request *sendRequests = NULL;
  MPI_Status status;
  MPI_Datatype MPI_CPLM_IJVal_t;
  char *ptr = NULL;

  CPLM_RegisterIJValStruct(&MPI_CPLM_IJVal_t);

  MPI_Comm_size(comm, &size);
  MPI_Comm_rank(comm, &rank);

  if (rank == 0) // Master process: read the file and dispatch the matrix
  { 
    FILE *fd = NULL;
    char buf[MM_MAX_LINE_LENGTH];
    char banner[MM_MAX_TOKEN_LENGTH];
    char matrix[MM_MAX_TOKEN_LENGTH];
    char coord[MM_MAX_TOKEN_LENGTH];
    char dataType[MM_MAX_TOKEN_LENGTH];
    char storageScheme[MM_MAX_TOKEN_LENGTH];
    CPLM_IJVal_t *ijvalsTmp = NULL;

    fd = fopen(filename, "r");
    if (!fd) 
    {
      CPLM_Abort("Impossible to open the file %s.\n",filename);
    }

    // Get the header line
    ptr = fgets(buf, MM_MAX_LINE_LENGTH, fd);
    sscanf(buf, "%s %s %s %s %s",
        banner, matrix, coord, dataType, storageScheme);
    if (strcasecmp(banner, MM_MATRIXMARKET_STR)
          || strcasecmp(matrix, MM_MATRIX_STR)
          || strcasecmp(coord, MM_SPARSE_STR)
          || strcasecmp(dataType, MM_REAL_STR)
          || strcasecmp(storageScheme, MM_GENERAL_STR)) 
    {
      fclose(fd);
      CPLM_Abort("Only sparse real matrix are currently supported.\n");
    }

    // Skip comment lines
    do 
    {
      ptr = fgets(buf, MM_MAX_LINE_LENGTH, fd);
    } while (!feof(fd) && buf[0] == COMMENT_SYMBOL);

    // Get matrix size
    sscanf(buf, "%d%d%d", &A->info.M, &A->info.N, &A->info.nnz);

    if (A->info.M < 1 ||
        A->info.N < 1 ||
        A->info.nnz < 1 ||
        A->info.nnz > (long long int)A->info.M * A->info.N) 
    {
      fclose(fd);
      CPLM_Abort("Invalid matrix dimensions.\n");
    }

    ierr = MPI_Bcast(&A->info.M, 1, MPI_INT, 0, comm);
    CPLM_checkMPIERR(ierr, " bcast M");
    ierr = MPI_Bcast(&A->info.N, 1, MPI_INT, 0, comm);
    CPLM_checkMPIERR(ierr, " bcast N");
    ierr = MPI_Bcast(&A->info.nnz, 1, MPI_INT, 0, comm);
    CPLM_checkMPIERR(ierr, " bcast nnz");

    nbProcWithExtraSize = A->info.nnz % size;
    localSize           = A->info.nnz / size + (nbProcWithExtraSize > 0);
    ijvalsTmp           = (CPLM_IJVal_t*)malloc(localSize * sizeof(CPLM_IJVal_t));
    CPLM_ASSERT(ijvalsTmp != NULL);

    CPLM_debug("nbProc %d/%d with extraSize %d\n",
        nbProcWithExtraSize, size, localSize);

    for (proc = 0; proc < size; proc++) 
    {
      //Read i,j,val line by line until reach localSize
      for (n = 0; n < localSize; n++) 
      {
        nread = fscanf(fd, "%d%d%lf",
            &ijvalsTmp[n].i, &ijvalsTmp[n].j, &ijvalsTmp[n].val);

        // Use 0-based indexing
        ijvalsTmp[n].i--;
        ijvalsTmp[n].j--;
      }

      // Send data
      if (proc == rank) // to local process
      { 
        localSizeBase = localSize;
        ijvals        = ijvalsTmp;
        ijvalsTmp     = (CPLM_IJVal_t*)malloc(localSize * sizeof(CPLM_IJVal_t));
        CPLM_ASSERT(ijvalsTmp != NULL);

      }
      else// to slave process
      { 
        ierr = MPI_Send(&localSize, 1, MPI_INT, proc, 0, comm);
        CPLM_checkMPIERR(ierr, "send localSize");
        ierr = MPI_Send(ijvalsTmp, localSize, MPI_CPLM_IJVal_t, proc, 0, comm);
        CPLM_checkMPIERR(ierr, "send ijvals");
      }

      // Prepare for next chunk
      if (proc + 1 == nbProcWithExtraSize)
      {
        localSize--;
      }
    }

    // Memory clean-up
    free(ijvalsTmp);

    fclose(fd);
  }
  else // Slave process: get its chunk from the master
  { 
    MPI_Status status;

    ierr = MPI_Bcast(&A->info.M, 1, MPI_INT, 0, comm);
    CPLM_checkMPIERR(ierr, " bcast M");
    ierr = MPI_Bcast(&A->info.N, 1, MPI_INT, 0, comm);
    CPLM_checkMPIERR(ierr, " bcast N");
    ierr = MPI_Bcast(&A->info.nnz, 1, MPI_INT, 0, comm);
    CPLM_checkMPIERR(ierr, " bcast nnz");

    ierr = MPI_Recv(&localSizeBase, 1, MPI_INT, 0, 0, comm, &status);
    CPLM_checkMPIERR(ierr, " Recv localSize");
    
    ijvals = (CPLM_IJVal_t*)malloc(localSizeBase * sizeof(CPLM_IJVal_t));
    CPLM_ASSERT(ijvals != NULL);

    ierr = MPI_Recv(ijvals, localSizeBase, MPI_CPLM_IJVal_t, 0, 0, comm, &status);
    CPLM_checkMPIERR(ierr, " Recv ijvals");
  }

  // Sort the local chunk
  if(distribLayout == ROW_LAYOUT)
  {
    qsort(ijvals, localSizeBase, sizeof(CPLM_IJVal_t), CPLM_CompareIJVal);
  }
  else
  {
    qsort(ijvals, localSizeBase, sizeof(CPLM_IJVal_t), CPLM_CompareIJValCol);
  }

  if(distribLayout == ROW_LAYOUT)
  {
    // Init the local matrix size
    nbBlocksRow = A->info.M;
    localSize = nbBlocksRow / size;
    nbProcWithExtraSize = nbBlocksRow % size;
    A->info.m = (localSize + (nbProcWithExtraSize > rank));
    A->info.n = A->info.N;
  }
  else
  {
    // Init the local matrix size
    nbBlocksCol = A->info.N;
    localSize = nbBlocksCol / size;
    nbProcWithExtraSize = nbBlocksCol % size;
    A->info.m = A->info.M;
    A->info.n = (localSize + (nbProcWithExtraSize > rank));
  }
  A->info.blockSize = 1;
  A->info.format    = FORMAT_CSR;
  A->info.structure = UNSYMMETRIC;
  
  CPLM_MatCSRPrintfInfo("A", A);

  if (nbProcWithExtraSize > 0) 
  {
    localSize++;
  }

  // Send the non-local elements
  sendSizes = (int*)calloc(size, sizeof(int));
  recvSizes = (int*)calloc(size, sizeof(int));
  sendRequests = (MPI_Request*)malloc((size - 1) * sizeof(MPI_Request));

  CPLM_ASSERT(sendSizes    != NULL);
  CPLM_ASSERT(recvSizes    != NULL);
  CPLM_ASSERT(sendRequests != NULL);

  void *ptr_ijval = NULL;

  ptr_ijval = (distribLayout == ROW_LAYOUT) ? &(ijvals[0].i) : &(ijvals[0].j);
  //CPLM_debug("Verif ref:%d =?= %d\n", ijvals[0].i, *ptr_ijval);

  for (n = 0, proc = 0, localEnd = localSize, ijvalStart = ijvals;
      n < localSizeBase;
      n++) 
  {
    //CPLM_debug("BEFORE while %d [ref %d] >= %d\n", *ptr_ijval, ijvals[n].i, localEnd);
    while (*((int*)ptr_ijval) >= localEnd)
    //while (ijvals[n].i >= localEnd)
    {
      //CPLM_debug("INNER while %d [ref %d] >= %d\n", *ptr_ijval, ijvals[n].i, localEnd);
      if (proc == rank) 
      {
        localStart = localEnd - localSize;
        ijvalStartLocal = ijvalStart;
      }
      else 
      {
        ierr = MPI_Isend(sendSizes + proc,
            1,
            MPI_INT,
            proc,
            0,
            comm,
            &sendRequests[proc - (proc > rank)]);
        CPLM_checkMPIERR(ierr, "isend size");

        if (sendSizes[proc] > 0)
        {
          ierr = MPI_Request_free(&sendRequests[proc - (proc > rank)]);
          ierr = MPI_Isend(ijvalStart,
              sendSizes[proc],
              MPI_CPLM_IJVal_t,
              proc,
              0,
              comm,
              &sendRequests[proc - (proc > rank)]);
          CPLM_checkMPIERR(ierr, "isend data");
        }
      }

      proc++;
      if (proc == nbProcWithExtraSize) 
      {
        localSize --;
      }
      localEnd += localSize;
      ijvalStart = &ijvals[n];
    }
    ptr_ijval = ptr_ijval + sizeof(CPLM_IJVal_t);
    sendSizes[proc]++;
  }

  // Last non-local chunks
  while (proc < size) 
  {
    if (proc == rank) 
    {
      localStart = localEnd - localSize;
      ijvalStartLocal = ijvalStart;
    } 
    else
    {
      ierr = MPI_Isend(sendSizes + proc,
          1,
          MPI_INT,
          proc,
          0,
          comm,
          &sendRequests[proc - (proc > rank)]);
      CPLM_checkMPIERR(ierr, "send localSize");

      if (sendSizes[proc] > 0) 
      {
        MPI_Request_free(&sendRequests[proc - (proc > rank)]);
        ierr = MPI_Isend(ijvalStart,
            sendSizes[proc],
            MPI_CPLM_IJVal_t,
            proc,
            0,
            comm,
            &sendRequests[proc - (proc > rank)]);
        CPLM_checkMPIERR(ierr, "isend ijvals");
      }
    }

    proc++;
    if (proc == nbProcWithExtraSize) 
    {
      localSize--;
    }
    localEnd += localSize;
    ijvalStart = &ijvals[n];
  }

  // Receive the chunks
  for (proc = 0, localSize = 0; proc < size; proc++) 
  {
    if (proc != rank) 
    {
      ierr = MPI_Recv(&recvSizes[proc],
          1,
          MPI_INT,
          proc,
          0,
          comm,
          &status);
      CPLM_checkMPIERR(ierr, "recv localSize");
      CPLM_debug("recv %d elements\n", recvSizes[proc]);
    }
    else
    {
      recvSizes[proc] = sendSizes[proc];
    }
    localSize += recvSizes[proc];
  }

  CPLM_debug("LocalSize = %d\n", localSize);

  ijvalStart = ijvals2 = (CPLM_IJVal_t*)malloc(localSize * sizeof(CPLM_IJVal_t));
  CPLM_ASSERT( ijvals2 != NULL);

  for (proc = 0; proc < size; proc++) 
  {
    if (recvSizes[proc] > 0) 
    {
      if (proc != rank) 
      {
        ierr = MPI_Recv(ijvalStart,
            recvSizes[proc],
            MPI_CPLM_IJVal_t,
            proc,
            0,
            comm,
            &status);
        CPLM_checkMPIERR(ierr, "recv ijvals");
      }
      else
      {
        memcpy(ijvalStart, ijvalStartLocal, recvSizes[proc] * sizeof(CPLM_IJVal_t));
      }
      ijvalStart += recvSizes[proc];
    }
  }

  // Memory clean-up
  free(recvSizes);

  // Sort local elements
  qsort(ijvals2, localSize, sizeof(CPLM_IJVal_t), CPLM_CompareIJVal);

  // Convert to CSR
  A->info.lnnz = localSize;
  A->rowPtr = (int*)    malloc((A->info.m + 1)  * sizeof(int));
  A->colInd = (int*)    malloc(localSize          * sizeof(int));
  A->val    = (double*) malloc(localSize          * sizeof(double));

  CPLM_ASSERT(A->rowPtr  != NULL);
  CPLM_ASSERT(A->colInd  != NULL);
  CPLM_ASSERT(A->val     != NULL);

  A->rowPtr[0] = 0;
  for (n = i = 0; n < localSize; n++) 
  {
    //printf("(%d,%d)\t%f\t->\t(%d,%d)\n",ijvals2[n].i,ijvals2[n].j,ijvals2[n].val,ijvals2[n].i,ijvals2[n].j-localStart);
    // Local indexing
    if(distribLayout == ROW_LAYOUT)
    {
      ijvals2[n].i -= localStart;
    }

    while (ijvals2[n].i > i) 
    {
      i++;
      A->rowPtr[i] = n;
    }

    if(distribLayout == ROW_LAYOUT)
    {
      A->colInd[n] = ijvals2[n].j;
    }
    else
    {
      A->colInd[n] = ijvals2[n].j - localStart;
    }
    A->val[n] = ijvals2[n].val;
  }

  while (A->info.m > i) 
  {
    i++;
    A->rowPtr[i] = n;
  }

  // Wait for all chunks to be received
  ierr = MPI_Waitall(size - 1, sendRequests, MPI_STATUSES_IGNORE);

  // Memory clean-up
  free(sendSizes);
  free(sendRequests);
  free(ijvals);
  free(ijvals2);

  MPI_Type_free(&MPI_CPLM_IJVal_t);
CPLM_END_TIME
CPLM_POP
  return ierr;
}





int CPLM_LoadMatrixMM2D(const char *filename,
                   CPLM_Mat_CSR_t  *A,
                   int        pr,
                   int        pc,
                   MPI_Comm   comm,
                   MPI_Comm   *rComm,
                   MPI_Comm   *cComm)
{
CPLM_PUSH
  int ierr = 0;
  int gRank = 0;  //Global rank related to the comm given in param
  int gSize = 1;  //Global size related to the comm given in param
  int rRank = 0;  //Row rank related to the comm given in param
  int rSize = 1;  //Row size related to the comm given in param
  int cRank = 0;  //Column rank related to the comm given in param
  int cSize = 1;  //Column size related to the comm given in param
  int color = 0;
  CPLM_Mat_CSR_t Acol = CPLM_MatCSRNULL();

  MPI_Comm_rank(comm, &gRank);
  MPI_Comm_size(comm, &gSize);

  //Row case
  CPLM_debug("%s\tpr = %d\tpc = %d\n", __FUNCTION__, pr, pc);
  color = gRank / pr;

  MPI_Comm_split(comm, color, gRank, rComm);

  MPI_Comm_rank(*rComm, &rRank);
  MPI_Comm_size(*rComm, &rSize);
  CPLM_debug("Global RANK/SIZE: %d/%d \t ROW RANK/SIZE: %d/%d\tColor %d\n",
          gRank, gSize, rRank, rSize, color);

  //Column case
  color = rRank;

  MPI_Comm_split(comm, color, gRank, cComm);

  MPI_Comm_rank(*cComm, &cRank);
  MPI_Comm_size(*cComm, &cSize);
  CPLM_debug("Global RANK/SIZE: %d/%d \t COL RANK/SIZE: %d/%d\tColor %d\n",
          gRank, gSize, cRank, cSize, color);

  //Load the matrix in 1D column layout i.e. in col panel
  if(!cRank)
  {
    ierr = CPLM_LoadMatrixMM1D(filename, 
        &Acol,
        'C',
        *rComm);CPLM_CHKERR(ierr);
  }

  //Then distribute in row panel
  if(!cRank)
  {

    CPLM_Mat_CSR_t rowPanel  = CPLM_MatCSRNULL();
    CPLM_IVector_t posB    = CPLM_IVectorNULL();
    int blockSize     = 0;
    int remain        = 0;

    blockSize     = Acol.info.m / cSize;
    remain        = Acol.info.m % cSize;

    //Row panel splitting
    ierr = CPLM_IVectorMalloc(&posB, cSize + 1);CPLM_CHKERR(ierr);
    posB.val[0]=0;

    for(int i = 0; i < remain; i++)
      posB.val[i+1] = posB.val[i] + blockSize + 1;

    for(int i = remain; i < cSize; i++)
      posB.val[i+1] = posB.val[i] + blockSize;

    //CPLM_IVectorPrintf("Starting row number of each block",&posB);

    //Send submatrices
    for(int dest = 1; dest < cSize; dest++)
    {
      ierr = CPLM_MatCSRGetRowPanel(&Acol, &rowPanel, &posB, dest);CPLM_CHKERR(ierr);
      ierr = CPLM_MatCSRSend(&rowPanel, dest, *cComm);
      CPLM_checkMPIERR(ierr,"Send row panel");
    }

    ierr = CPLM_MatCSRGetRowPanel(&Acol, A, &posB, cRank);CPLM_CHKERR(ierr);

    CPLM_MatCSRFree(&rowPanel);
    CPLM_IVectorFree(&posB);

  }
  else//other MPI processes received their own submatrix
  {
    ierr = CPLM_MatCSRRecv(A, 0, *cComm);CPLM_checkMPIERR(ierr,"Recv row panel");
  }

  // Final State of matCSR variable
//CPLM_MatCSRPrintInfo(A);
//CPLM_MatCSRPrintf("local matrix", A);
//CPLM_MatCSRPrintf2D("local matrix", A);
  
  if(!cRank)
  {
    CPLM_MatCSRFree(&Acol);
  }
CPLM_POP
  return ierr;
}
