#!/usr/bin/python

################################################################################
# Author     : Olivier Tissot                                                  #
# Date       : 2017/01/30                                                      #
# Description: Plot a bar graph with steps' time of a function                 #
################################################################################

################################################################################
#                                 IMPORT                                       #
################################################################################

import numpy as np
import matplotlib.pyplot as plt
from matplotlib import cm, rcParams
import argparse
from cpalamem_utils import cpalamem_output_parser as cop
#import cpalamem_output_parser as cop

################################################################################
#                                   CODE                                       #
################################################################################

# Define the argument of the script and the help message
parser = argparse.ArgumentParser(description="Plot a bar graph with steps' time.")
# The output file
parser.add_argument("-f", "--file", help="output file", required=True)
# The function name
parser.add_argument("-n", "--name", help="name of the function", required=True)
# Parse the arguments given by the user
args = parser.parse_args()
filename = args.file
function = args.name

# Parse the output file
out = cop.cpalamem_output(filename)
info = out.getMaxTimeInfo(function)

# Extract only the steps and the total time
subkeys = out.getSteps(function)
print(subkeys)
width = 0.8
dataVal = [info[k] for k in subkeys]
dataSum = sum(dataVal)
print(dataVal)
if dataSum < 1:
    dataVal=dataVal/dataSum

# Plot a pie chart
cs = cm.Paired(np.arange(len(subkeys))/float(len(subkeys)))
rcParams['font.size'] = 16
patches, texts, autotexts = plt.pie(dataVal,colors=cs,\
    autopct='%1.1f%%',pctdistance=1.1, labels=subkeys, labeldistance=1.2)
#plt.legend(patches, dat.keys(), loc="best")
plt.axis('equal')

plt.show()
