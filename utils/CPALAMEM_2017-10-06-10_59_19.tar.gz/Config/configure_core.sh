#######################################
#title            : configure_core.sh
#description      : This file checks if the dependencies of the library are correct
#authors          : Sebastien Cayrols
#email            : sebastien.cayrols@[\(gmail.com\)|\(inria.fr\)]
#date             : 12/29/2016
#version          : 0.1
#usage            : source configure_core.sh in another file
#notes            :
#######################################

#-----------------------------------
#     Check if PGK variables are set
#-----------------------------------
pkgOutput="\n#Package variable environment:\n"
for pkg in ${PKG_DATA[@]}; do
  data="${pkg}[@]"
  data=("${!data}")
 #echo "DATA: ${#data[@]} ${data[@]}"
  pkgname=${data[$PKGNAME]}
  echo "PKG name : $pkgname"
  LIB_ID=${pkgname}_ID
  LIB_ID=${!LIB_ID}
  if [ "${REQ[$LIB_ID]}" -eq 1 ];then
    DEFINE+=" -D${pkgname}ACTIVATE"
    if [ "${SETUP[$LIB_ID]}" -eq 0 ];then
      header=${data[$PKGHEADERFILE]}
      lib=${data[$PKGLIBFILE]}
      incPath=${data[$PKGINCPATH]}
      libPath=${data[$PKGLIBPATH]}

      checkDep $pkgname $header $lib $incPath $libPath
     #echo "RTN:: INC $RTN_INC LIB $RTN_LIB"

      pkg_inc=$RTN_INC
      pkg_lib=$RTN_LIB
      pkgOutput+="${pkgname}_INC=${pkg_inc}\n${pkgname}_LIB=${pkg_lib}\n"

      if [ ${#data[@]} -gt $PKGHEADERFILE2 ];then
        header=${data[$PKGHEADERFILE2]}
        lib=${data[$PKGLIBFILE2]}
        checkDep $pkgname $header $lib $incPath $libPath
        pkg_inc=$RTN_INC
        pkg_lib=$RTN_LIB
        pkgOutput+="${pkgname}_INC2=${pkg_inc}\n${pkgname}_LIB2=${pkg_lib}\n"
      fi
    else
      searchEnv $pkgname
      pkgOutput+="${pkgname}_INC=${RTN_INC}\n${pkgname}_LIB=${RTN_LIB}\n"
      if [ ! -z "$RTN_INC2" -a ! -z "$RTN_LIB2" ];then
        pkgOutput+="${pkgname}_INC2=${RTN_INC2}\n${pkgname}_LIB2=${RTN_LIB2}\n"
      fi
    fi
  else
    echo "Ignored"
  fi
done
