#######################################
#title            : configure_handleParam.sh
#description      : This file handles the log file to search environment of the previous call + parse the param given to the configure
#authors          : Sebastien Cayrols
#email            : sebastien.cayrols@[\(gmail.com\)|\(inria.fr\)]
#date             : 12/29/2016
#version          : 0.1
#usage            : source configure_handleParam.sh in another file
#notes            :
#######################################
#This function searches if the NAME_INC and NAME_LIB are in the log file
function searchEnv(){
    #Name of the library
    local NAME=$1
    local incPath=""
    local libPath=""
    
    RTN_INC=`grep -w "${NAME}_INC" $LOGFILE | cut -d '=' -f 2`
    echo "RTN_INC = ${RTN_INC}"

    RTN_LIB=`grep -w "${NAME}_LIB" $LOGFILE | cut -d '=' -f 2`
    echo "RTN_LIB = ${RTN_LIB}"

    if [ ! -z ${RTN_INC} -a ! -z ${RTN_LIB} ]; then
      echo -e "[INFO] ${NAME} RESET with $RTN_INC and $RTN_LIB"
    fi

    RTN_INC2=`grep "${NAME}_INC2" $LOGFILE | cut -d '=' -f 2`
    RTN_LIB2=`grep "${NAME}_LIB2" $LOGFILE | cut -d '=' -f 2`
    if [ ! -z "${RTN_INC2}" -a ! -z "${RTN_LIB2}" ]; then
      echo -e "\t\t AND with $RTN_INC2 and $RTN_LIB2"
    fi
}


#Check if the param is in the list
#PARAM
# $# list of param to check
function getOldParam(){
  local paramChecked=""

  echo "Param of getOldParam : $@"
  while [ $# -gt 0 ]; do
    case $1 in
      --with-*)
        local libName=${1#--with-}
        libName=`echo ${libName} | awk '{ print toupper($0)}'`
        local LIB_ID=${libName}_ID
        echo "With : $libName(${!LIB_ID})"

        REQ[${!LIB_ID}]=1
        SETUP[${!LIB_ID}]=1

        paramChecked+=" $1"
        shift
        ;;

      --without-*)
        local libName=${1#--without-}
        echo "Without : $libName(${!LIB_ID})"

        REQ[${!LIB_ID}]=0
        SETUP[${!LIB_ID}]=1

        paramChecked+=" $1"
        shift
        ;;

      -O|--optimize)
        OPTIM=0
        echo "[WARNING] Benchmark mode ignored"
        shift
        ;;

      -d|--debug)
        DEBUG=0
        echo "[WARNING] Debug mode ignored"
        shift
        ;;

      --cc)
        paramChecked+=" $1 $2"
        shift
        exists $1
        lCC=`which $1`
        echo "[INFO] ${CC} compiler is reset"
        shift
        ;;

      *)
        error "$1 old argument ignored" 
        shift
        ;;
    esac
  done
  RETURN_CHECKEDOLDPARAM=${paramChecked}
}



#Check if the param is in the list
#PARAM
# $# list of param to check
function checkParam(){
  local paramChecked=${RETURN_CHECKEDOLDPARAM}

  while [ $# -gt 0 ]; do
    case $1 in
      --with-*)
        local libName=${1#--with-}
        libName=`echo ${libName} | awk '{ print toupper($0)}'`
        local LIB_ID=${libName}_ID
        echo "With : $libName(${!LIB_ID})"
        REQ[${!LIB_ID}]=1

        paramChecked+=" $1"
        shift
        ;;

      --without-*)
        local libName=${1#--without-}
        libName=`echo ${libName} | awk '{ print toupper($0)}'`
        local LIB_ID=${libName}_ID
        echo "Without : $libName(${!LIB_ID})"
        REQ[${!LIB_ID}]=0

        paramChecked+=" $1"
        shift
        ;;

      -O|--optimize)
        OPTIM=1
        echo "[INFO] Benchmark mode used"
        paramChecked=${paramChecked/-O/}
        paramChecked=${paramChecked/--optimize/}
        paramChecked=${paramChecked/-d/}
        paramChecked=${paramChecked/--debug/}
        paramChecked+=" $1"
        shift
        ;;

      -d|--debug)
        DEBUG=1
        echo "[INFO] Debug ON"
        paramChecked=${paramChecked/-O/}
        paramChecked=${paramChecked/--optimize/}
        paramChecked=${paramChecked/-d/}
        paramChecked=${paramChecked/--debug/}
        paramChecked+=" $1"
        shift
        ;;

      --cc)
        paramChecked=`echo ${paramChecked} | sed 's/--cc [a-z]\+//gI'`
        paramChecked+=" $1 $2"
        shift
        exists $1
        lCC=`which $1`
        echo "[INFO] ${lCC} compiler is set"
        shift
        ;;

      #Ignore this param
      --reset)
        shift
        ;;

      *)
        error "$1 bad argument" 1
        ;;
    esac
  done
  RETURN_CHECKEDPARAM=${paramChecked}
}

#--------------------------
# CHECK if the logfile already exists
#--------------------------
#manage parameters
if [ -e $LOGFILE ] && [ ${RESET} -eq 0 ];then
  #Get old parameters
  old_param=`grep "Configure parameters" $LOGFILE | cut -d ':' -f 2`
 #estim_param=`sed -n 's/^\([a-zA-Z]*\)=1/--with-\L\1/p' $LOGFILE`
 #estim_param=`echo ${estim_param}| tr -d '\n'`
 #echo "Estimated previous parameters : $estim_param"

  #Remove parameters already in old parameter list
 #for param_i in $old_param; do
 #  estim_param=${estim_param/$param_i/}
 #done
 ##Concatenate old parameters and estimated ones
 #old_param="$old_param $estim_param"

  echo "[RAW] parameters given to the configure : $@"
  echo "Old parameters : $old_param"
  
  echo "Handle old param"
  #Get back informations about old parameters
  getOldParam $old_param
else
  echo "[RAW] parameters given to the configure : $@" 
fi

#Check all new parameters
checkParam "$@"

echo "Configure parameters : $RETURN_CHECKEDPARAM" 

#CHECK if CC compiler exists
exists $lCC
if [ "$?" -eq 1 ]; then error "${lCC} : Unknown compiler" 1 ;fi

if [ ${DEBUG:=0} -eq 1 ]; then
  lOPTFLAGS=""
  lCFLAGSDEBUG+=" $lCFLAGS"
fi
